/**
 * BongoType — www/ Build Script
 * --------------------------------------------------------------------------
 * Assembles www/ — the directory Capacitor packages into the native app
 * (see capacitor.config.json's webDir) — from the real project source at
 * the repo root (index.html, components/, scripts/, data/, styles/,
 * assets/, manifest.webmanifest).
 *
 * WHY A SEPARATE BUILD STEP RATHER THAN POINTING CAPACITOR AT THE REPO
 * ROOT DIRECTLY: the repo root also holds this build script,
 * build-fallback.js, README.md, and (once `npx cap add android` has been
 * run) the native android/ project — none of which belong inside the
 * packaged app. Keeping a real webDir separate from the source keeps
 * "what ships" and "what's dev tooling" unambiguous, the same reasoning
 * that already justifies bundle.js being generated rather than hand-kept
 * in sync (see build-fallback.js's own comment header).
 *
 * www/ is GENERATED — never edit files inside it directly, edits will be
 * overwritten the next time this runs. Edit the real source at the repo
 * root, then re-run this script.
 *
 * USAGE: node build-www.js
 * (Run from the project root. Run build-fallback.js first if you've
 * changed component/script/data source, so bundle.js is current before
 * it gets copied.)
 */

const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const WWW = path.join(ROOT, 'www');

const DIRS_TO_COPY = ['components', 'scripts', 'data', 'styles', 'assets'];
const FILES_TO_COPY = ['index.html', 'manifest.webmanifest'];

function copyDirRecursive(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDirRecursive(s, d);
    else fs.copyFileSync(s, d);
  }
}

function main() {
  if (fs.existsSync(WWW)) fs.rmSync(WWW, { recursive: true, force: true });
  fs.mkdirSync(WWW, { recursive: true });

  for (const dir of DIRS_TO_COPY) {
    copyDirRecursive(path.join(ROOT, dir), path.join(WWW, dir));
  }
  for (const file of FILES_TO_COPY) {
    fs.copyFileSync(path.join(ROOT, file), path.join(WWW, file));
  }

  console.log(`Built www/ from source (${DIRS_TO_COPY.length} dirs, ${FILES_TO_COPY.length} files).`);
  console.log('Next: npx cap sync android');
}

main();
