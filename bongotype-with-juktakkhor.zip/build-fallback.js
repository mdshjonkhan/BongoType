/**
 * BongoType — Fallback Bundle Builder
 * --------------------------------------------------------------------------
 * Produces bundle.js: every ES module in this project concatenated into ONE
 * plain classic script, with all `import`/`export` statements mechanically
 * stripped and replaced with reads/writes on a single global namespace
 * object (window.BongoType). A classic script has no module resolution
 * step at all, so it cannot suffer the class of error this exists to guard
 * against ("does not provide an export named ...") — there is nothing to
 * resolve, since everything is concatenated into one file the browser
 * parses top to bottom.
 *
 * WHY GENERATE RATHER THAN HAND-WRITE THE FALLBACK:
 * A hand-maintained second copy of the app would silently drift from the
 * real source the first time someone edits one and forgets the other. This
 * script derives the bundle FROM the real ES module source by parsing the
 * actual import graph, computing a topological build order, and stripping
 * syntax — so the fallback is mechanically guaranteed to match whatever the
 * modular source currently says. Re-run this script after any source edit
 * to regenerate bundle.js.
 *
 * USAGE: node build-fallback.js
 * (Run from the project root — paths below are relative to it.)
 */

const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const OUTPUT_PATH = path.join(ROOT, 'scripts', 'bundle.js');

// Every JS source file in the project, in no particular order yet — real
// order is computed below from the import graph, not assumed.
const ALL_FILES = [
  'data/layouts/bijoy.js',
  'data/layouts/jatiya.js',
  'data/layouts/probhat.js',
  'data/layouts/finger-map.js',
  'data/layouts/index.js',
  'data/lessons/module-0.js',
  'data/lessons/module-1.js',
  'data/lessons/module-2.js',
  'data/lessons/module-3.js',
  'data/lessons/index.js',
  'data/achievements.js',
  'scripts/store.js',
  'scripts/input-mode.js',
  'scripts/levels.js',
  'scripts/achievements.js',
  'scripts/router.js',
  'scripts/sound.js',
  'scripts/haptics.js',
  'scripts/confetti.js',
  'scripts/icons.js',
  'scripts/keynav.js',
  'scripts/world-map.js',
  'scripts/scoring.js',
  'scripts/keyboard-engine.js',
  'scripts/hand-visualization.js',
  'scripts/lesson-engine.js',
  'scripts/type-flappy.js',
  'components/game-flappy.js',
  'components/home.js',
  'components/layout-select.js',
  'components/module.js',
  'components/practice.js',
  'components/lesson.js',
  'components/badges.js',
  'components/world-map-screen.js',
  'scripts/app.js'
];

function readSource(relPath) {
  return fs.readFileSync(path.join(ROOT, relPath), 'utf8');
}

/**
 * Strip /* block comments and // line comments before scanning for real
 * code constructs.
 *
 * ORDER MATTERS: line comments are stripped FIRST. A // comment can
 * legitimately contain text that LOOKS like the start of a block comment
 * — e.g. a path such as `data/layouts/*.js` contains the literal two-char
 * sequence `/*`. If the block-comment regex runs first across the whole
 * file, it treats that as a real opener and then non-greedily searches
 * forward for the next `*\/` ANYWHERE later in the file — which might be
 * the close of a totally unrelated, legitimate JSDoc comment much further
 * down, silently swallowing every real line of code in between. Stripping
 * `//...` lines first removes that text before the block-comment regex
 * ever sees it, eliminating the false match entirely.
 */
function stripComments(content) {
  return content
    .replace(/\/\/.*$/gm, '')
    .replace(/\/\*[\s\S]*?\*\//g, '');
}

/** Extract { name1, name2 } from './relative/path.js' import lines. */
function getImports(content) {
  const codeOnly = stripComments(content);
  return [...codeOnly.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"](\.[^'"]+)['"]/g)].map((m) => ({
    names: m[1].split(',').map((s) => s.trim()),
    spec: m[2]
  }));
}

/** Resolve an import spec relative to the importing file into one of our known relative paths. */
function resolveSpec(fromRelPath, spec) {
  const fromDir = path.dirname(fromRelPath);
  const resolved = path.normalize(path.join(fromDir, spec)).replace(/\\/g, '/');
  return resolved;
}

/** Topologically order ALL_FILES so every file appears after everything it imports. */
function computeBuildOrder(files) {
  const fileSet = new Set(files);
  const sourceByFile = {};
  files.forEach((f) => { sourceByFile[f] = readSource(f); });

  const visited = new Set();
  const order = [];

  function visit(file, stack) {
    if (visited.has(file)) return;
    if (stack.has(file)) {
      throw new Error(`Circular import detected involving ${file} (chain: ${[...stack, file].join(' -> ')})`);
    }
    stack.add(file);
    const deps = getImports(sourceByFile[file]).map((imp) => resolveSpec(file, imp.spec));
    deps.forEach((dep) => {
      if (!fileSet.has(dep)) {
        throw new Error(`${file} imports '${dep}' which is not in ALL_FILES — add it to the list above.`);
      }
      visit(dep, stack);
    });
    stack.delete(file);
    visited.add(file);
    order.push(file);
  }

  files.forEach((f) => visit(f, new Set()));
  return order;
}

/**
 * Strip import/export syntax from one file's source, rewriting it to read
 * named values from `NS` (the shared namespace object) instead of `import`,
 * and to assign exported names onto `NS` instead of `export`.
 *
 * Comments are stripped FIRST, before any transformation — this isn't just
 * for output cleanliness. Without it, text that merely LOOKS like an
 * import/export statement inside a comment (e.g. a JSDoc usage example)
 * gets rewritten by the same regex that handles real code, since regex
 * has no concept of "this text is documentation." Stripping comments
 * first removes that entire class of bug rather than trying to make the
 * regexes comment-aware.
 */
function transform(relPath, content) {
  let out = stripComments(content);

  // import { a, b as c } from '...';  ->  const { a, b: c } = NS;
  out = out.replace(/import\s*\{([^}]+)\}\s*from\s*['"](\.[^'"]+)['"]\s*;?/g, (full, names) => {
    const destructured = names
      .split(',')
      .map((n) => n.trim())
      .map((n) => {
        const asMatch = n.match(/^(\w+)\s+as\s+(\w+)$/);
        return asMatch ? `${asMatch[1]}: ${asMatch[2]}` : n;
      })
      .join(', ');
    return `const { ${destructured} } = NS;`;
  });

  // export const NAME = ...   ->  NS.NAME = ...   (keep a local const too, for
  // any same-file references further down that were written assuming a
  // bare identifier, e.g. helper functions calling LEVELS internally).
  out = out.replace(/export\s+const\s+(\w+)\s*=/g, 'const $1 = NS.$1 =');
  out = out.replace(/export\s+function\s+(\w+)/g, 'function $1');
  out = out.replace(/export\s+class\s+(\w+)/g, 'class $1');

  // app.js registers its own boot listener directly:
  //   document.addEventListener('DOMContentLoaded', init);
  // That assumes the DOM is still loading at script-execution time, which
  // is true for a normal page-load <script> but FALSE for this bundle's
  // realistic use case (injected dynamically, well after DOMContentLoaded
  // already fired, by the fallback mechanism in index.html). Replace it
  // with an NS.__init export instead; the bundle's shared footer (see
  // `footer` below in this build script) decides at load time whether to
  // wait for DOMContentLoaded or call init() immediately.
  out = out.replace(
    /document\.addEventListener\(\s*['"]DOMContentLoaded['"]\s*,\s*(\w+)\s*\)\s*;?/,
    'NS.__init = $1;'
  );

  // Any bare `export function NAME` / `export class NAME` declarations need
  // a trailing NS.NAME = NAME; assignment, since declarations aren't
  // expressions we can prefix the way we did for const above. Names are
  // pulled from the ORIGINAL content (comments included is fine here,
  // since we only need the name list, not the surrounding text) to keep
  // this lookup independent of the stripped copy's exact formatting.
  const fnExportNames = [...content.matchAll(/export\s+function\s+(\w+)/g)].map((m) => m[1]);
  const classExportNames = [...content.matchAll(/export\s+class\s+(\w+)/g)].map((m) => m[1]);
  const trailingAssigns = [...fnExportNames, ...classExportNames]
    .map((name) => `NS.${name} = ${name};`)
    .join('\n');

  return `\n/* ---- ${relPath} ---- */\n(function () {\n${out}\n${trailingAssigns}\n})();\n`;
}

function build() {
  const order = computeBuildOrder(ALL_FILES);
  console.log('Computed build order:');
  order.forEach((f, i) => console.log(`  ${i + 1}. ${f}`));

  const pieces = order.map((relPath) => transform(relPath, readSource(relPath)));

  const banner = `/**
 * BongoType — Fallback Bundle (AUTO-GENERATED, do not edit by hand)
 * --------------------------------------------------------------------------
 * Generated by build-fallback.js from the modular ES source. This file is
 * a plain classic script (no import/export) so it loads with zero module
 * resolution — used as the automatic fallback in index.html if the primary
 * modular <script type="module"> fails to load for any reason (stale
 * cache, incorrect MIME type from a misconfigured server, file:// protocol
 * restrictions, etc). Regenerate with: node build-fallback.js
 * Generated: ${new Date().toISOString()}
 */
(function () {
  'use strict';
  const NS = {}; // shared namespace standing in for ES module exports

`;

  const footer = `
  // Boot trigger: handles being loaded as a normal page script (DOM not
  // ready yet) AND being injected dynamically by the fallback mechanism
  // in index.html well after DOMContentLoaded already fired — the latter
  // is actually the realistic case for this file, since it only loads at
  // all when the primary modular script failed, which is detected via a
  // timer running AFTER the page's initial load sequence completes.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', NS.__init || function(){});
  } else if (NS.__init) {
    NS.__init();
  }
})();
`;

  const result = banner + pieces.join('\n') + footer;
  fs.writeFileSync(OUTPUT_PATH, result, 'utf8');
  console.log(`\nWrote ${OUTPUT_PATH} (${(result.length / 1024).toFixed(1)} KB)`);
}

build();
