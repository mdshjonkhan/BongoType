/**
 * BongoType — Icon & Ornament System
 * --------------------------------------------------------------------------
 * Replaces every emoji in the app with hand-drawn-feeling inline SVG, built
 * from three Bengali folk-art references instead of generic icon-font shapes:
 *
 *   - Terracotta temple plaques  → the circular "medallion" frame every
 *     badge/nav icon sits in: a notched clay-tablet edge, warm relief tones.
 *   - Alpona (rice-paste floor art) → the dot-and-petal rosette scattered
 *     around medallions, and the wavy vine used as a section divider.
 *   - Rickshaw-panel painting → the bold flat-color flower/leaf strip used
 *     on celebration banners (level-up, badge unlock).
 *
 * Everything here is generated as small SVG strings, not static asset files,
 * so a single source of truth drives icon + illustration + animation.
 */

// ── Functional glyphs (24×24 viewBox, currentColor stroke) ─────────────────
// Used inline at small sizes: nav bar, buttons, inline status marks.
const GLYPHS = {
  home: `<path d="M4 11.5 12 4l8 7.5" fill="none"/><path d="M6 10v9h5v-5.5h2V19h5v-9" fill="none"/><path d="M9.5 6.7V4.6h2V6.4" fill="none"/>`,
  keys: `<rect x="3.5" y="8" width="17" height="10" rx="2.2" fill="none"/><path d="M7 12h.01M11 12h.01M15 12h.01M17.5 12h.01M7 15.2h10" fill="none"/>`,
  medal: `<circle cx="12" cy="14.5" r="6" fill="none"/><path d="M12 11v2.6l1.8 1.4" fill="none"/><path d="M9 4.5 12 9l3-4.5" fill="none"/>`,
  person: `<circle cx="12" cy="8.3" r="3.6" fill="none"/><path d="M4.8 20c1-3.8 4-5.6 7.2-5.6s6.2 1.8 7.2 5.6" fill="none"/>`,
  flame: `<path d="M12 3.5c1.4 2.4-.4 3.6-.9 5-1 2.4.1 3.7 1.2 4.4.2-1.4.9-2 1.6-2.6.6 1.7.4 2.9-.3 4.1a5 5 0 1 1-6.6-7c.6 1 1.4 1.2 2.1 1 -.6-1.9-.3-3.4 2.9-4.9Z" fill="none"/>`,
  tap: `<path d="M9.5 12.2V6.6a1.5 1.5 0 0 1 3 0v4.7M12.5 11V5.4a1.5 1.5 0 0 1 3 0v6M15.5 11.4v-2a1.5 1.5 0 0 1 3 0v5.4c0 3.6-2.2 6.7-6 6.7-2.6 0-4-1-5.4-2.9l-2.4-3.6c-.5-.9-.1-1.9.8-2.2.7-.2 1.3 0 1.8.6l1.2 1.5" fill="none"/>`,
  check: `<path d="M4.5 12.5 9 17l10.5-11" fill="none"/>`,
  lock: `<rect x="5.5" y="10.5" width="13" height="9.5" rx="2" fill="none"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" fill="none"/><circle cx="12" cy="15" r="1.4" fill="currentColor" stroke="none"/>`,
  close: `<path d="M6 6l12 12M18 6 6 18" fill="none"/>`,
  arrowRight: `<path d="M5 12h13.5M13 6.5 18.5 12 13 17.5" fill="none"/>`,
  arrowLeft: `<path d="M19 12H5.5M11 17.5 5.5 12 11 6.5" fill="none"/>`,
  muteOn: `<path d="M4 10v4h3.3L12 17.5V6.5L7.3 10H4Z" fill="none"/><path d="M15.5 9.5a3.6 3.6 0 0 1 0 5" fill="none"/><path d="M17.8 7.3a7 7 0 0 1 0 9.4" fill="none"/>`,
  muteOff: `<path d="M4 10v4h3.3L12 17.5V6.5L7.3 10H4Z" fill="none"/><path d="M15.7 9.7l4 4M19.7 9.7l-4 4" fill="none"/>`,
  star: `<path d="M12 4.2 14.2 9l5.3.6-4 3.6 1.1 5.2L12 15.8 7.4 18.4l1.1-5.2-4-3.6L9.8 9Z" fill="none"/>`,
  trophy: `<path d="M8 5h8v4.2a4 4 0 0 1-8 0Z" fill="none"/><path d="M8 6H5.5a1 1 0 0 0-1 1.2c.4 2 1.6 3.2 3.6 3.4M16 6h2.5a1 1 0 0 1 1 1.2c-.4 2-1.6 3.2-3.6 3.4" fill="none"/><path d="M12 13.2v3M9 19.5h6l-.6-2.6H9.6Z" fill="none"/>`,
  crown: `<path d="M4.5 17.5 3.5 9l4.3 3 4.2-5.5 4.2 5.5 4.3-3-1 8.5Z" fill="none"/><path d="M4.5 17.5h15" fill="none"/>`,
  sprout: `<path d="M12 20v-7" fill="none"/><path d="M12 13c0-3.4-2.4-5.6-5.8-5.8C6.4 10.8 8.6 13 12 13Z" fill="none"/><path d="M12 10.2c0-3 2.1-5 5.2-5.3.2 3-2 5.3-5.2 5.3Z" fill="none"/>`,
  bookStack: `<rect x="5" y="6" width="14" height="3.4" rx="1" fill="none"/><rect x="5" y="10.3" width="14" height="3.4" rx="1" fill="none"/><rect x="5" y="14.6" width="10" height="3.4" rx="1" fill="none"/>`,
  folder: `<path d="M4 7.5a1.5 1.5 0 0 1 1.5-1.5h4l1.6 2H18.5A1.5 1.5 0 0 1 20 9.5v8A1.5 1.5 0 0 1 18.5 19h-13A1.5 1.5 0 0 1 4 17.5Z" fill="none"/>`,
  target: `<circle cx="12" cy="12" r="7.2" fill="none"/><circle cx="12" cy="12" r="4" fill="none"/><circle cx="12" cy="12" r="0.9" fill="currentColor" stroke="none"/>`,
  handOpen: `<path d="M8.5 12.5V6.3a1.3 1.3 0 0 1 2.6 0v5M11.1 11.3V5a1.3 1.3 0 0 1 2.6 0v6.3M13.7 11.6V6.4a1.3 1.3 0 0 1 2.6 0v7.2" fill="none"/><path d="M16.3 12.4V9.7a1.3 1.3 0 0 1 2.6 0v5.4c0 3.4-2.1 6.4-5.9 6.4-2.6 0-4.2-1.1-5.4-2.8L5.4 15c-.5-.8-.2-1.7.6-2.1.7-.3 1.4-.1 1.9.6l1.6 2" fill="none"/>`,
  rocket: `<path d="M12 3.5c2.6 1.7 4 4.6 4 8.2 0 2-.5 3.6-1.2 5H9.2c-.7-1.4-1.2-3-1.2-5 0-3.6 1.4-6.5 4-8.2Z" fill="none"/><circle cx="12" cy="10.5" r="1.4" fill="none"/><path d="M9.2 16.7 7 19M14.8 16.7 17 19M10.2 20h3.6" fill="none"/>`,
  percentBadge: `<circle cx="12" cy="12" r="8" fill="none"/><path d="M9 15 15 9M9.4 9.4h.01M14.6 14.6h.01" fill="none"/>`,
  bolt: `<path d="M13 3.5 6.5 13.2h4.2L10 20.5l7.5-10.3h-4.4Z" fill="none"/>`,
  wind: `<path d="M4 8.5h11a2.3 2.3 0 1 0-2.2-3" fill="none"/><path d="M4 12.5h13.5a2.3 2.3 0 1 1-2.2 3" fill="none"/><path d="M4 16.5h8.5" fill="none"/>`,
  meteor: `<path d="M14.5 4 7 13h4l-2.2 7L18 10.5h-4.4Z" fill="none"/><path d="M6 7.2h2M4.7 10.6h1.6" fill="none"/>`,
  mountain: `<path d="M3 18 9 7l3.4 5.4L14.5 9 21 18Z" fill="none"/><path d="M9 7l1.6 2.6" fill="none"/>`,
  compass: `<circle cx="12" cy="12" r="8" fill="none"/><path d="M15 9l-2 5-4 1 2-5Z" fill="none"/>`
};

/** Inline glyph as small standalone SVG (buttons, nav, inline marks). */
export function icon(name, { size = 20, className = '' } = {}) {
  const body = GLYPHS[name] || GLYPHS.star;
  return `<svg class="icon-svg ${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}

// ── Alpona rosette ring (dot-and-petal border, terracotta-plaque style) ────
function rosetteRing(petals, r1, r2, cls) {
  let out = '';
  for (let i = 0; i < petals; i++) {
    const a = (Math.PI * 2 * i) / petals;
    const x1 = 32 + Math.cos(a) * r1, y1 = 32 + Math.sin(a) * r1;
    const x2 = 32 + Math.cos(a) * r2, y2 = 32 + Math.sin(a) * r2;
    out += `<circle class="${cls}" cx="${x2.toFixed(2)}" cy="${y2.toFixed(2)}" r="${i % 3 === 0 ? 1.9 : 1.15}" />`;
    out += `<line class="${cls}" x1="${x1.toFixed(2)}" y1="${y1.toFixed(2)}" x2="${(32 + Math.cos(a) * (r1 + 2.4)).toFixed(2)}" y2="${(32 + Math.sin(a) * (r1 + 2.4)).toFixed(2)}" />`;
  }
  return out;
}

/**
 * A terracotta-plaque medallion: notched clay disc + alpona dot ring +
 * a functional glyph at the center. Used for nav icons, badge tiles, and
 * the brand mark. `state` drives the palette: locked | current | done.
 */
export function medallion(name, { state = 'done', size = 44, spin = false } = {}) {
  const glyphBody = GLYPHS[name] || GLYPHS.star;
  const stateClass = `medallion--${state}`;
  return `
  <svg class="medallion ${stateClass} ${spin ? 'medallion--spin-in' : ''}" width="${size}" height="${size}" viewBox="0 0 64 64" fill="none" aria-hidden="true">
    <circle class="medallion__plaque" cx="32" cy="32" r="26"/>
    <circle class="medallion__rim" cx="32" cy="32" r="26"/>
    <g class="medallion__rosette">${rosetteRing(12, 20.5, 24.5, 'medallion__petal')}</g>
    <g class="medallion__glyph" transform="translate(19,19) scale(1.08)" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${glyphBody}</g>
  </svg>`;
}

/** Small inline star used for ratings — outline by default, fill via .is-filled */
export function starGlyph(size = 18) {
  return icon('star', { size, className: 'star-glyph' });
}

// ── Alpona vine divider — a wavy line with leaf/petal marks, used under
//    section headings instead of a plain <hr>. ─────────────────────────────
export function alponaDivider(width = 280) {
  const segs = Math.max(4, Math.round(width / 40));
  let path = `M0 12 `;
  for (let i = 1; i <= segs; i++) {
    const x = (width / segs) * i;
    const y = i % 2 === 0 ? 4 : 20;
    path += `Q ${(x - width / segs / 2).toFixed(1)} ${y} ${x.toFixed(1)} 12 `;
  }
  let leaves = '';
  for (let i = 0; i < segs; i++) {
    const x = (width / segs) * (i + 0.5);
    const up = i % 2 === 0;
    leaves += `<path class="alpona-divider__leaf" d="M${x.toFixed(1)} 12 q ${up ? '-4 -8 0 -10' : '4 8 0 10'} q ${up ? '4 2 0 10' : '-4 -2 0 -10'}"/>`;
  }
  return `
  <svg class="alpona-divider" width="100%" height="24" viewBox="0 0 ${width} 24" preserveAspectRatio="none" aria-hidden="true">
    <path class="alpona-divider__vine" d="${path}" fill="none"/>
    ${leaves}
  </svg>`;
}

// ── Rickshaw-panel flower strip — bold flat-color repeating motif used on
//    celebration banners (level-up / badge unlock), echoing Dhaka rickshaw
//    back-panel floral painting. ──────────────────────────────────────────
export function rickshawStrip(id = 'a', count = 9) {
  const petalColors = ['#E0392F', '#C9A227', '#FBF7EE'];
  let flowers = '';
  const spacing = 30;
  for (let i = 0; i < count; i++) {
    const cx = spacing / 2 + i * spacing;
    const color = petalColors[i % petalColors.length];
    flowers += `
      <g transform="translate(${cx},14)">
        <path d="M0-6 C3-6 3-1 0 0 C-3-1 -3-6 0-6Z" fill="${color}" opacity="0.9"/>
        <path d="M0-6 C3-6 3-1 0 0 C-3-1 -3-6 0-6Z" fill="${color}" opacity="0.9" transform="rotate(72)"/>
        <path d="M0-6 C3-6 3-1 0 0 C-3-1 -3-6 0-6Z" fill="${color}" opacity="0.9" transform="rotate(144)"/>
        <path d="M0-6 C3-6 3-1 0 0 C-3-1 -3-6 0-6Z" fill="${color}" opacity="0.9" transform="rotate(216)"/>
        <path d="M0-6 C3-6 3-1 0 0 C-3-1 -3-6 0-6Z" fill="${color}" opacity="0.9" transform="rotate(288)"/>
        <circle r="1.6" fill="#00543C"/>
      </g>`;
  }
  return `<svg class="rickshaw-strip" data-strip="${id}" width="100%" height="24" viewBox="0 0 ${count * spacing} 24" preserveAspectRatio="none" aria-hidden="true">${flowers}</svg>`;
}

// ── Brand medallion — terracotta plaque with the ব glyph for the home
//    hero / splash contexts. ────────────────────────────────────────────────
export function brandMedallion(size = 72) {
  return `
  <svg class="brand-medallion" width="${size}" height="${size}" viewBox="0 0 64 64" aria-hidden="true">
    <circle class="medallion__plaque" cx="32" cy="32" r="27"/>
    <circle class="medallion__rim" cx="32" cy="32" r="27"/>
    <g class="medallion__rosette">${rosetteRing(16, 21.5, 25.5, 'medallion__petal')}</g>
    <text x="32" y="41" text-anchor="middle" class="brand-medallion__glyph">ব</text>
  </svg>`;
}
