/**
 * BongoType — Achievements Engine
 * --------------------------------------------------------------------------
 * Pure functions over `data/achievements.js`'s badge list. No state lives
 * here — the store still owns `unlockedBadges`; this module only decides
 * WHICH badges a given state/result combination newly qualifies for, so
 * lesson.js can persist that decision and show a celebration.
 */

import { ACHIEVEMENTS } from '../data/achievements.js';
import { MODULES } from '../data/lessons/index.js';
import { levelForXp } from './levels.js';

function moduleDone(moduleId, completedLessons) {
  const mod = MODULES.find((m) => m.id === moduleId);
  if (!mod) return false;
  return mod.lessons.every((l) => completedLessons.includes(l.id));
}

function allModulesDone(completedLessons) {
  return MODULES.every((mod) => mod.lessons.every((l) => completedLessons.includes(l.id)));
}

/**
 * @param {object} state - store.get() snapshot, AFTER the current attempt's
 *   xp/completedLessons/streak patch has already been applied
 * @param {object|null} lastResult - the just-finished attempt's score record
 *   (accuracy, wpm, maxCombo, stars), or null outside a lesson context
 * @returns {Array} newly-qualifying achievement objects (not yet in state.unlockedBadges)
 */
export function checkNewlyUnlocked(state, lastResult = null) {
  const ctx = {
    moduleDone: (id) => moduleDone(id, state.completedLessons),
    allModulesDone: allModulesDone(state.completedLessons),
    level: levelForXp(state.xp),
    lastResult
  };
  return ACHIEVEMENTS.filter((a) => !state.unlockedBadges.includes(a.id) && a.check(state, ctx));
}

export function badgeById(id) {
  return ACHIEVEMENTS.find((a) => a.id === id) || null;
}
