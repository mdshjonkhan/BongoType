/**
 * BongoType — Keyboard Engine
 * --------------------------------------------------------------------------
 * Responsibilities:
 *   1. Render a virtual keyboard for whichever layout is active.
 *   2. Accept input via EITHER real physical keydown/keyup events OR
 *      taps/clicks directly on the rendered virtual keys — both paths feed
 *      the SAME correctness-checking logic (_processKeyEvent), so there is
 *      exactly one place that decides "was this the right key," no matter
 *      which input method produced it.
 *   3. Compare the pressed key against an "expected" target key and report
 *      correct/incorrect via a callback — lesson logic decides WHAT the
 *      expected key is; this engine only handles HOW input is captured.
 *
 * Deliberately NOT in this file: lesson sequencing, scoring, XP. Keeping
 * this engine dumb (just "layout in, keypress events out") is what lets
 * the lesson engine and free-practice mode both reuse it without
 * duplicating keyboard logic.
 *
 * Physical key identification uses event.code (e.g. "KeyF"), NOT event.key,
 * because event.key reflects the CURRENT OS keyboard layout (which may be
 * English, Avro, anything) while event.code is the physical key position —
 * exactly what we need since BongoType teaches physical muscle memory
 * independent of whatever IME the OS happens to have active.
 *
 * VIRTUAL TAP INPUT: a tap has no real Shift modifier the way a physical
 * keydown event does (event.shiftKey). Instead, tapping a Shift key toggles
 * an internal "virtual shift is held" state that applies to the NEXT
 * character tap, then clears — mirroring how real mobile keyboard apps
 * handle Shift (tap Shift, then tap a letter, capitalization applies once).
 */

import { fingerForKey } from '../data/layouts/finger-map.js';
import { sound } from './sound.js';
import { haptics } from './haptics.js';

// Physical keyboard rows, defined by event.code, used to render the vkeyboard
// in correct geometric order. This is intentionally separate from the
// per-layout character data — geometry is the same no matter which layout
// is loaded; only the characters drawn on each key change.
//
// Includes every standard key a learner would see on a real keyboard, not
// just the character keys: Backspace, Tab, Caps Lock, both Shift keys,
// Enter, and Space all appear in their real physical positions, even
// though most of them don't type a Bengali character (see the `special`
// flag on these entries in data/layouts/*.js).
const ROWS = [
  ['Digit1','Digit2','Digit3','Digit4','Digit5','Digit6','Digit7','Digit8','Digit9','Digit0','Minus','Equal','Backspace'],
  ['Tab','KeyQ','KeyW','KeyE','KeyR','KeyT','KeyY','KeyU','KeyI','KeyO','KeyP','BracketLeft','BracketRight','Backslash'],
  ['CapsLock','KeyA','KeyS','KeyD','KeyF','KeyG','KeyH','KeyJ','KeyK','KeyL','Semicolon','Quote','Enter'],
  ['ShiftLeft','KeyZ','KeyX','KeyC','KeyV','KeyB','KeyN','KeyM','Comma','Period','Slash','ShiftRight'],
  ['Space']
];

// Keys that should render wider than a standard letter key, matching their
// real proportions on a physical keyboard. Multipliers are relative to one
// standard key width (handled in CSS via a `--span` custom property).
const KEY_SPAN = {
  Backspace: 2,
  Tab: 1.5,
  CapsLock: 1.75,
  Enter: 2.25,
  ShiftLeft: 2.25,
  ShiftRight: 2.25,
  Space: 10
};

const SHIFT_CODES = new Set(['ShiftLeft', 'ShiftRight']);

export class KeyboardEngine {
  /**
   * @param {Object} layout - a layout object from data/layouts (e.g. bijoyLayout)
   * @param {HTMLElement} mountEl - container to render the virtual keyboard into
   * @param {Object} [options]
   * @param {boolean} [options.tapEnabled=false] - if true, rendered keys accept tap/click input in addition to physical keydown. Pass true for virtual/portrait mode; physical/landscape mode leaves this off so accidental taps on the visual keyboard don't register as input when a real keyboard is expected.
   */
  constructor(layout, mountEl, options = {}) {
    this.layout = layout;
    this.mountEl = mountEl;
    this.tapEnabled = options.tapEnabled || false;
    this.expectedCode = null;   // physical key code the learner should press next
    this.onResult = null;       // callback(isCorrect, { code, expectedCode, char })
    this._keyEls = new Map();   // code -> DOM element, for fast highlight updates
    this._virtualShiftActive = false; // tap-mode only: true after tapping Shift, until the next character tap consumes it

    this._handleKeyDown = this._handleKeyDown.bind(this);
    this._handleKeyUp = this._handleKeyUp.bind(this);
  }

  /** Build the virtual keyboard DOM once. Call after construction. */
  render() {
    this.mountEl.innerHTML = '';
    const wrapper = document.createElement('div');
    wrapper.className = 'vkeyboard';

    ROWS.forEach((rowCodes) => {
      const rowEl = document.createElement('div');
      rowEl.className = 'vkeyboard__row';
      rowCodes.forEach((code) => {
        const keyData = this.layout.keys[code];
        if (!keyData) return; // layout doesn't define this physical key — skip
        const keyEl = document.createElement('div');
        keyEl.dataset.code = code;

        const span = KEY_SPAN[code] || 1;
        keyEl.style.setProperty('--span', span);

        if (keyData.special) {
          // Modifier/special key: English label, no shifted-character
          // sub-label (it doesn't have one), distinct wider styling.
          keyEl.className = 'vkey vkey--special';
          keyEl.innerHTML = `<span class="vkey__label">${keyData.label}</span>`;
        } else {
          keyEl.className = 'vkey';
          keyEl.innerHTML = `
            <span>${keyData.unshifted}</span>
            <span class="vkey__shifted">${keyData.shifted}</span>
          `;
        }

        if (this.tapEnabled) {
          keyEl.classList.add('vkey--tappable');
          // pointerdown/up (not click) so the press-down visual feedback is
          // immediate rather than waiting for the full click sequence to
          // resolve, matching how a real keyboard app feels responsive.
          keyEl.addEventListener('pointerdown', (e) => {
            e.preventDefault(); // stop touch from also firing a synthetic mouse click/focus
            this._processKeyEvent(code, { fromTap: true });
          });
          keyEl.addEventListener('pointerup', () => this._clearPressVisual(code));
          keyEl.addEventListener('pointerleave', () => this._clearPressVisual(code));
        }

        rowEl.appendChild(keyEl);
        this._keyEls.set(code, keyEl);
      });
      wrapper.appendChild(rowEl);
    });

    this.mountEl.appendChild(wrapper);
  }

  /** Start listening for real physical keyboard input (always active, regardless of tapEnabled — a physical keyboard can be attached even in virtual/portrait mode). */
  start() {
    window.addEventListener('keydown', this._handleKeyDown);
    window.addEventListener('keyup', this._handleKeyUp);
  }

  /** Stop listening — call when leaving the practice screen to avoid leaks. */
  stop() {
    window.removeEventListener('keydown', this._handleKeyDown);
    window.removeEventListener('keyup', this._handleKeyUp);
  }

  /**
   * Set which physical key the learner should press next, and highlight it.
   * Special-cased for Shift: passing 'ShiftEither' highlights BOTH shift
   * keys and accepts either one as correct, matching the product decision
   * to not enforce correct-side Shift discipline for beginners.
   */
  setExpectedKey(code) {
    if (this.expectedCode) {
      this._clearExpectedHighlight(this.expectedCode);
    }
    this.expectedCode = code;
    this._applyExpectedHighlight(code);
  }

  _applyExpectedHighlight(code) {
    if (code === 'ShiftEither') {
      ['ShiftLeft', 'ShiftRight'].forEach((c) => {
        const el = this._keyEls.get(c);
        if (el) el.classList.add('is-next');
      });
      return;
    }
    const el = this._keyEls.get(code);
    if (el) el.classList.add('is-next');
  }

  _clearExpectedHighlight(code) {
    if (code === 'ShiftEither') {
      ['ShiftLeft', 'ShiftRight'].forEach((c) => {
        const el = this._keyEls.get(c);
        if (el) el.classList.remove('is-next');
      });
      return;
    }
    const el = this._keyEls.get(code);
    if (el) el.classList.remove('is-next');
  }

  /**
   * Finger info for whatever key is currently expected — the hand viz
   * reads this. 'ShiftEither' has no single finger (it's deliberately
   * ambiguous), so this returns null for it; callers should treat null as
   * "no specific finger highlight for this target."
   */
  getExpectedFinger() {
    if (!this.expectedCode || this.expectedCode === 'ShiftEither') return null;
    return fingerForKey(this.expectedCode);
  }

  _handleKeyDown(event) {
    // Ignore key-repeat from holding a key down — each physical press should
    // only register once.
    if (event.repeat) return;
    this._processKeyEvent(event.code, { fromTap: false });
  }

  _handleKeyUp(event) {
    sound.keyUp();
    this._clearPressVisual(event.code);
  }

  _clearPressVisual(code) {
    const keyEl = this._keyEls.get(code);
    if (keyEl) {
      keyEl.classList.remove('is-pressed', 'is-correct-flash', 'is-wrong-flash');
    }
  }

  /**
   * Single shared path for "a key was pressed," regardless of whether it
   * came from a physical keydown or a virtual tap. This is what makes the
   * two input methods produce IDENTICAL lesson/scoring behavior — neither
   * the lesson engine nor any caller of onResult can tell which one fired.
   */
  _processKeyEvent(code, { fromTap }) {
    const keyEl = this._keyEls.get(code);
    if (keyEl) keyEl.classList.add('is-pressed');
    sound.keyDown();
    // Haptic feedback only for taps — a physical keyboard already gives
    // real tactile feedback per keystroke, so buzzing on top of that would
    // be redundant and annoying. Tap/virtual-keyboard mode has no physical
    // click at all, so this is where haptics actually earn their keep.
    if (fromTap) haptics.tap();

    // Virtual Shift handling: tapping Shift itself just arms the "next tap
    // is shifted" state and stops here — it doesn't count as a keystroke
    // toward the expected target, matching how Shift behaves physically
    // (pressing it alone doesn't "complete" anything).
    if (fromTap && SHIFT_CODES.has(code)) {
      // Shifted-values drills expect 'ShiftEither' as their own sequence
      // step — a tap on either Shift key must be able to satisfy that step
      // (report a result) in addition to arming virtual-shift for the tap
      // that follows, otherwise portrait/tap users could never advance past
      // the Shift step of a shift+key drill.
      if (this.expectedCode === 'ShiftEither') {
        this._virtualShiftActive = true;
        keyEl?.classList.add('is-shift-armed', 'is-correct-flash');
        sound.correct();
        if (fromTap) haptics.correct();
        if (this.onResult) this.onResult(true, { code, expectedCode: this.expectedCode, fromTap });
        setTimeout(() => this._clearPressVisual(code), 150);
        return;
      }
      this._virtualShiftActive = !this._virtualShiftActive;
      keyEl?.classList.toggle('is-shift-armed', this._virtualShiftActive);
      return;
    }

    const consumedVirtualShift = fromTap && this._virtualShiftActive;
    if (consumedVirtualShift) {
      this._virtualShiftActive = false;
      ['ShiftLeft', 'ShiftRight'].forEach((c) => {
        this._keyEls.get(c)?.classList.remove('is-shift-armed');
      });
    }

    if (!this.expectedCode) return; // no active target — engine is idle

    const isCorrect = this.expectedCode === 'ShiftEither'
      ? (code === 'ShiftLeft' || code === 'ShiftRight')
      : code === this.expectedCode;

    if (keyEl) {
      keyEl.classList.add(isCorrect ? 'is-correct-flash' : 'is-wrong-flash');
    }
    isCorrect ? sound.correct() : sound.wrong();
    // Error haptics fire regardless of input method — a wrong keystroke is
    // worth a buzz even when typing on a physical keyboard, since it's a
    // signal easy to miss if sound is off. Success haptics stay tap-only
    // (see note above) so physical typing doesn't buzz on every correct key.
    if (!isCorrect) haptics.wrong();
    else if (fromTap) haptics.correct();

    if (this.onResult) {
      this.onResult(isCorrect, { code, expectedCode: this.expectedCode, fromTap });
    }

    // Taps don't get a separate "key up" event the way physical keys do
    // (pointerup just clears the press visual, it doesn't re-fire logic),
    // so clear the flash/pressed state on a short delay instead of waiting
    // for a keyup that will never come for this code via this path.
    if (fromTap) {
      setTimeout(() => this._clearPressVisual(code), 150);
    }
  }
}
