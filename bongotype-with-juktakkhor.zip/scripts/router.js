/**
 * BongoType — Router
 * --------------------------------------------------------------------------
 * Why a router at all, and why this simple: the app has a small number of
 * full-screen views (home, lesson list, lesson runner, profile). A router
 * gives each one a stable URL (so back/forward and refresh behave sanely on
 * mobile) without pulling in a framework. Hash-based routing was chosen
 * because the app will later be wrapped in a WebView for the APK build,
 * where hash routes work with zero server configuration.
 *
 * A "screen" module is just an object: { render(container, params) }.
 * render() is responsible for clearing and rebuilding its own DOM —
 * screens own their subtree, nothing more.
 */

const routes = new Map(); // path -> screen module

export const router = {
  register(path, screenModule) {
    routes.set(path, screenModule);
  },

  start(containerEl) {
    this.container = containerEl;
    window.addEventListener('hashchange', () => this._handle());
    this._handle();
  },

  navigate(path) {
    window.location.hash = path;
  },

  _handle() {
    const hash = window.location.hash.replace('#', '') || '/';
    const [rawPath, queryString] = hash.split('?');
    const path = rawPath.startsWith('/') ? rawPath : `/${rawPath}`;
    const params = Object.fromEntries(new URLSearchParams(queryString || ''));

    const screen = routes.get(path) || routes.get('/');
    if (!screen) {
      console.error(`BongoType router: no screen registered for "${path}" and no fallback "/".`);
      return;
    }

    // Screen-transition fade: purely presentational, layered on top of the
    // synchronous DOM swap rather than gating it — render() below still
    // runs immediately, so screens that start timers/engines/listeners as
    // part of render() see no change in timing. A hard instant cut between
    // full-screen views (no transition at all) is one of the more obvious
    // "this is a webpage" tells; native Android view transitions always
    // animate the outgoing/incoming screen even when brief.
    this.container.classList.remove('screen-enter');
    this.container.innerHTML = '';
    screen.render(this.container, params);
    this.container.scrollTop = 0;
    // Reflow before adding the class so the transition actually plays
    // instead of the browser coalescing the remove+add into one no-op frame.
    void this.container.offsetWidth;
    this.container.classList.add('screen-enter');
  }
};
