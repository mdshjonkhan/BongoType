/**
 * BongoType — Levels & XP
 * --------------------------------------------------------------------------
 * Design: levels are defined as a sparse list of named milestones
 * (1, 10, 25, 50 per the product spec), and XP thresholds between them are
 * generated with a smooth curve rather than hand-typing 50 numbers. This
 * keeps the progression tunable from one place — change the curve, every
 * level's threshold updates.
 *
 * Curve choice: a mild power curve (threshold = base * level^1.5) so early
 * levels come fast (motivating for total beginners) and later levels take
 * meaningfully longer (so "BongoType Master" feels earned, not handed out).
 */

const NAMED_MILESTONES = {
  1: 'Beginner',
  10: 'Keyboard Explorer',
  25: 'Fast Typist',
  50: 'BongoType Master'
};

const MAX_LEVEL = 50;
// Tuned against realistic earning: a finished lesson awards roughly 15-30 XP
// (see scoring.js, Phase 5). At that rate this curve targets:
//   Level 10 (Keyboard Explorer) ~= 15-20 lessons in
//   Level 25 (Fast Typist)       ~= 90-110 lessons in
//   Level 50 (BongoType Master)  ~= 350-450 lessons in — a real achievement,
//   not a grind measured in thousands of repetitions.
const BASE_XP = 12;

/** XP required to REACH a given level (level 1 = 0 XP). */
function xpThresholdForLevel(level) {
  if (level <= 1) return 0;
  return Math.round(BASE_XP * Math.pow(level - 1, 1.5));
}

/** Human-facing name for a level, falling back to the nearest milestone below it. */
function nameForLevel(level) {
  if (NAMED_MILESTONES[level]) return NAMED_MILESTONES[level];
  const milestoneLevels = Object.keys(NAMED_MILESTONES).map(Number).sort((a, b) => b - a);
  const nearestBelow = milestoneLevels.find((m) => m <= level) || 1;
  return NAMED_MILESTONES[nearestBelow];
}

/** Precompute thresholds once — cheap, and avoids recomputation on every call. */
export const LEVELS = Array.from({ length: MAX_LEVEL }, (_, i) => {
  const level = i + 1;
  return {
    number: level,
    name: nameForLevel(level),
    xpRequired: xpThresholdForLevel(level)
  };
});

/** Given total XP, return the current level object plus a label for the next milestone. */
export function levelForXp(xp) {
  let current = LEVELS[0];
  for (const lvl of LEVELS) {
    if (xp >= lvl.xpRequired) current = lvl;
    else break;
  }
  const next = LEVELS.find((l) => l.number === current.number + 1);
  if (!next) {
    return { ...current, nextName: null, nextXp: null };
  }
  // Only show a milestone NAME if the next level actually introduces one;
  // otherwise label it plainly by number so we're not echoing the current
  // title back at the user as if it were a new achievement.
  const nextLabel = NAMED_MILESTONES[next.number] || `Level ${next.number}`;
  return { ...current, nextName: nextLabel, nextXp: next.xpRequired };
}

/** Progress (0-100%) toward the next level, plus XP remaining. */
export function xpProgressInLevel(xp) {
  const current = levelForXp(xp);
  if (!current.nextXp) {
    return { percent: 100, remaining: 0 };
  }
  const prevThreshold = LEVELS.find((l) => l.number === current.number).xpRequired;
  const span = current.nextXp - prevThreshold;
  const into = xp - prevThreshold;
  const percent = Math.min(100, Math.max(0, (into / span) * 100));
  return { percent, remaining: Math.max(0, current.nextXp - xp) };
}
