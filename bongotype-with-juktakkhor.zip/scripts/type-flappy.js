/**
 * BongoType — Type Flappy Bird Engine
 * --------------------------------------------------------------------------
 * A typing-reflex mini-game layered on the flappy-bird formula: the bird
 * only rises when the learner presses the PHYSICAL key that produces the
 * Bengali character painted on the current gap's pipe. Wrong key = bird
 * just keeps falling (no penalty beyond gravity); right key = a flap.
 * Passing through a gap without ever needing a flap (bird was already
 * gliding through) still requires the correct key to have been the last
 * one pressed, so the game can't be "beaten" by mashing.
 *
 * Deliberately NOT in this file: canvas drawing, DOM, sound/haptics
 * triggering. This is pure simulation state + a step() function, exactly
 * mirroring the separation of concerns keyboard-engine.js already
 * establishes elsewhere in the app (engine emits events, screen owns
 * rendering). A component wraps this in a requestAnimationFrame loop and
 * draws whatever `getState()` returns.
 *
 * Key lookup uses UNSHIFTED characters only, one per physical key, from
 * the active layout — no Shift juggling. A reflex game needs a single,
 * unambiguous keystroke per target; that's a deliberate simplification
 * from the full lesson engine (which does teach shifted values), not an
 * oversight.
 */

const GRAVITY = 1100;         // px/s^2 — gentle enough that a beat's worth of reaction time doesn't mean a floor collision
const FLAP_VELOCITY = -360;   // px/s, instant upward velocity on correct key
const BIRD_X_FRACTION = 0.28; // bird's horizontal position as a fraction of playfield width, fixed
const BIRD_RADIUS = 16;
const PIPE_WIDTH = 56;
const GAP_HEIGHT_START = 260;
const GAP_HEIGHT_MIN = 190;
const PIPE_SPEED_START = 110;  // px/s
const PIPE_SPEED_MAX = 190;
const SPAWN_INTERVAL_START = 2600; // ms between pipes
const SPAWN_INTERVAL_MIN = 2000;
const RAMP_DURATION_MS = 90000; // difficulty reaches max after 90s

// Minimum on-screen gap (in px) between the trailing edge of one pipe and
// the leading edge of the next, ON TOP OF whatever the spawn-interval*speed
// math already produces. This exists because spawn interval and pipe speed
// both ramp independently with difficulty — without an explicit floor, a
// fast-speed + short-interval combination late in a run could spawn a
// pipe before the previous one has fully cleared the bird's x-position,
// letting the player collide with "the wrong pipe" while reacting to a
// new target. One pipe within reach of the bird at a time, always.
const MIN_PIPE_GAP_PX = 200;

/** Build a pool of {code, char} pairs from a layout's unshifted values, excluding special/modifier keys and non-printing chars. */
function buildCharPool(layout) {
  const pool = [];
  for (const [code, data] of Object.entries(layout.keys)) {
    if (data.special) continue;
    const ch = data.unshifted;
    if (!ch || ch === ' ' || ch === '\u200C') continue;
    pool.push({ code, char: ch });
  }
  return pool;
}

export class TypeFlappyGame {
  /**
   * @param {Object} layout - active keyboard layout (from data/layouts)
   * @param {Object} [options]
   * @param {number} [options.width=360] playfield width in px
   * @param {number} [options.height=560] playfield height in px
   */
  constructor(layout, options = {}) {
    this.width = options.width || 360;
    this.height = options.height || 560;
    this.charPool = buildCharPool(layout);

    this.reset();
  }

  reset() {
    this.startedAt = null;
    this.elapsedMs = 0;
    this.running = false;
    this.gameOver = false;

    this.birdY = this.height / 2;
    this.birdVelocity = 0;
    this.birdRotation = 0;

    this.pipes = []; // { x, gapY, gapHeight, char, code, scored, id }
    this._nextPipeId = 1;
    this._msSinceLastSpawn = 0;

    this.score = 0;
    this.combo = 0;
    this.bestCombo = 0;
    this.correctHits = 0;
    this.wrongHits = 0;

    this.lastResult = null; // { correct, char } — most recent keystroke result, for UI flash
  }

  start() {
    this.running = true;
    this.gameOver = false;
    this.startedAt = performance.now();
    this._spawnPipe();
  }

  /** Difficulty ramps smoothly from 0 (start) to 1 (max) over RAMP_DURATION_MS. */
  _difficulty() {
    return Math.min(1, this.elapsedMs / RAMP_DURATION_MS);
  }

  _currentPipeSpeed() {
    const d = this._difficulty();
    return PIPE_SPEED_START + (PIPE_SPEED_MAX - PIPE_SPEED_START) * d;
  }

  _currentGapHeight() {
    const d = this._difficulty();
    return GAP_HEIGHT_START - (GAP_HEIGHT_START - GAP_HEIGHT_MIN) * d;
  }

  _currentSpawnInterval() {
    const d = this._difficulty();
    return SPAWN_INTERVAL_START - (SPAWN_INTERVAL_START - SPAWN_INTERVAL_MIN) * d;
  }

  _spawnPipe() {
    const gapHeight = this._currentGapHeight();
    const margin = 60; // keep the gap away from the very top/bottom edges
    const gapY = margin + Math.random() * (this.height - gapHeight - margin * 2);
    const target = this.charPool[Math.floor(Math.random() * this.charPool.length)];
    this.pipes.push({
      id: this._nextPipeId++,
      x: this.width + PIPE_WIDTH,
      gapY,
      gapHeight,
      char: target.char,
      code: target.code,
      scored: false
    });
  }

  /** Which pipe the bird is currently approaching / passing through — the "active target." */
  _activePipe() {
    const birdX = this.width * BIRD_X_FRACTION;
    // The nearest pipe whose right edge hasn't passed the bird yet.
    let candidate = null;
    for (const pipe of this.pipes) {
      if (pipe.x + PIPE_WIDTH < birdX) continue; // already fully passed
      if (!candidate || pipe.x < candidate.x) candidate = pipe;
    }
    return candidate;
  }

  /**
   * Called by the component on every physical keydown with event.code.
   * Correct key (matches the active pipe's target) => flap + advances
   * combo + scores when the pipe is passed. Wrong key => breaks combo,
   * no flap, bird keeps falling under gravity.
   */
  handleKey(code) {
    if (!this.running || this.gameOver) return;
    const pipe = this._activePipe();
    if (!pipe) return;

    if (code === pipe.code) {
      this.birdVelocity = FLAP_VELOCITY;
      this.combo += 1;
      this.bestCombo = Math.max(this.bestCombo, this.combo);
      this.correctHits += 1;
      this.lastResult = { correct: true, char: pipe.char };
    } else {
      this.combo = 0;
      this.wrongHits += 1;
      this.lastResult = { correct: false, char: pipe.char };
    }
  }

  /** Advance simulation by dtMs milliseconds. Returns nothing; read state via getState(). */
  step(dtMs) {
    if (!this.running || this.gameOver) return;
    const dt = dtMs / 1000;
    this.elapsedMs += dtMs;

    // Bird physics
    this.birdVelocity += GRAVITY * dt;
    this.birdY += this.birdVelocity * dt;
    // Rotation purely cosmetic: nose up while rising, nose down while falling.
    this.birdRotation = Math.max(-0.5, Math.min(1.2, this.birdVelocity / 500));

    // Pipes move left
    const speed = this._currentPipeSpeed();
    const birdX = this.width * BIRD_X_FRACTION;
    for (const pipe of this.pipes) {
      pipe.x -= speed * dt;

      // Scoring: once the bird's x has passed the pipe's x, and it happened
      // without a collision (checked below), award a point.
      if (!pipe.scored && pipe.x + PIPE_WIDTH < birdX) {
        pipe.scored = true;
        this.score += 1;
      }
    }
    // Drop pipes that are fully off-screen to the left.
    this.pipes = this.pipes.filter((p) => p.x > -PIPE_WIDTH);

    // Spawn new pipes on interval, but never closer together on-screen
    // than MIN_PIPE_GAP_PX — see that constant's comment for why a pure
    // timer isn't sufficient on its own once speed/interval have ramped.
    this._msSinceLastSpawn += dtMs;
    const lastPipe = this.pipes[this.pipes.length - 1];
    const roomAvailable = !lastPipe || (this.width - lastPipe.x) >= MIN_PIPE_GAP_PX;
    if (this._msSinceLastSpawn >= this._currentSpawnInterval() && roomAvailable) {
      this._msSinceLastSpawn = 0;
      this._spawnPipe();
    }

    // Collision: floor, ceiling, or pipe body (outside its gap while overlapping its x-range)
    if (this.birdY - BIRD_RADIUS <= 0 || this.birdY + BIRD_RADIUS >= this.height) {
      this._end();
      return;
    }
    for (const pipe of this.pipes) {
      const overlapsX = birdX + BIRD_RADIUS > pipe.x && birdX - BIRD_RADIUS < pipe.x + PIPE_WIDTH;
      if (!overlapsX) continue;
      const inGap = this.birdY - BIRD_RADIUS > pipe.gapY && this.birdY + BIRD_RADIUS < pipe.gapY + pipe.gapHeight;
      if (!inGap) {
        this._end();
        return;
      }
    }
  }

  _end() {
    this.running = false;
    this.gameOver = true;
  }

  getState() {
    return {
      width: this.width,
      height: this.height,
      birdX: this.width * BIRD_X_FRACTION,
      birdY: this.birdY,
      birdRotation: this.birdRotation,
      pipeWidth: PIPE_WIDTH,
      pipes: this.pipes,
      score: this.score,
      combo: this.combo,
      bestCombo: this.bestCombo,
      correctHits: this.correctHits,
      wrongHits: this.wrongHits,
      accuracy: this.correctHits + this.wrongHits > 0
        ? Math.round((this.correctHits / (this.correctHits + this.wrongHits)) * 100)
        : 100,
      elapsedMs: this.elapsedMs,
      running: this.running,
      gameOver: this.gameOver,
      lastResult: this.lastResult,
      activeTarget: this._activePipe()
    };
  }
}
