/**
 * BongoType — App Shell
 * --------------------------------------------------------------------------
 * This is wrapped in a native Android WebView, so the app owns none of the
 * system chrome — no OS header bar, no OS tab bar. The app supplies its
 * own instead, sized for landscape hand-holding: top-level destinations
 * (World map / Practice / Badges / Profile) live in a slide-out menu
 * sidebar opened from home (see home.js), plus a small floating back
 * control for going one level deeper than home, plus a global
 * Escape-to-back shortcut. Everything else — the letter you're typing, the
 * level path you're walking — is still the star of the screen; the app's
 * own chrome is deliberately thin and quiet.
 */

import { router } from './router.js';
import { store } from './store.js';
import { detectLikelyInputMode } from './input-mode.js';
import { homeScreen } from '../components/home.js';
import { layoutSelectScreen } from '../components/layout-select.js';
import { moduleScreen } from '../components/module.js';
import { practiceScreen } from '../components/practice.js';
import { lessonScreen } from '../components/lesson.js';
import { badgesScreen } from '../components/badges.js';
import { worldMapScreen } from '../components/world-map-screen.js';
import { gameFlappyScreen } from '../components/game-flappy.js';
import { sound } from './sound.js';
import { haptics } from './haptics.js';
import { icon, brandMedallion } from './icons.js';

function currentPath() {
  const hash = window.location.hash.replace('#', '') || '/';
  const raw = hash.split('?')[0];
  return raw.startsWith('/') ? raw : `/${raw}`;
}

// ── Input mode ──────────────────────────────────────────────────────────
function applyInputModeClass() {
  const mode = store.get().inputMode;
  document.body.classList.toggle('input-mode-virtual', mode === 'virtual');
}

function setInputMode(mode) {
  store.set({ inputMode: mode });
  applyInputModeClass();
}

// ── Floating back control ────────────────────────────────────────────────
// Not a header — a single small corner control, present only where a person
// actually needs a way out (everything but home). Backed by real browser
// history so the Android hardware/gesture back button (which the native
// wrapper maps to webView.goBack()) does the same thing for free.
let backBtn = null;
function ensureBackButton() {
  if (backBtn) return backBtn;
  backBtn = document.createElement('button');
  backBtn.id = 'global-back';
  backBtn.className = 'global-back';
  backBtn.setAttribute('aria-label', 'Back');
  backBtn.innerHTML = icon('arrowLeft', { size: 18 });
  backBtn.addEventListener('click', goBack);
  document.getElementById('app').appendChild(backBtn);
  return backBtn;
}

function goBack() {
  sound.tap();
  haptics.tap();
  if (window.history.length > 1) window.history.back();
  else router.navigate('/');
}

function updateChromeDensity() {
  const onHome = currentPath() === '/';
  ensureBackButton().classList.toggle('is-hidden', onHome);
}

// ── Full keyboard control ────────────────────────────────────────────────
// Escape always backs out one level, from anywhere, without needing a
// visible button focused first — matches a typing-app-first, keyboard-first
// interaction model rather than a tap-to-navigate one.
function bindGlobalKeys() {
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && currentPath() !== '/') {
      e.preventDefault();
      goBack();
    }
  });
}

// ── Register screens ────────────────────────────────────────────────────
function registerScreens() {
  router.register('/', homeScreen);
  router.register('/layout-select', layoutSelectScreen);
  router.register('/map', worldMapScreen);
  router.register('/module', moduleScreen);
  router.register('/practice', practiceScreen);
  router.register('/lesson', lessonScreen);
  router.register('/badges', badgesScreen);
  router.register('/game/flappy', gameFlappyScreen);

  router.register('/profile', {
    render(container) {
      const state = store.get();
      const history = state.stats.lessonHistory;
      const avgAccuracy = history.length
        ? Math.round(history.reduce((s, h) => s + h.accuracy, 0) / history.length)
        : null;
      const weakKeys = Object.entries(state.stats.mistakesByKey).sort((a,b) => b[1]-a[1]).slice(0,5);
      const mode = state.inputMode || 'physical';

      container.innerHTML = `
        <h1 style="margin-bottom:var(--space-5);">Profile</h1>

        <div class="card" style="margin-bottom:var(--space-4);">
          <p class="text-muted" style="font-size:var(--text-sm);margin-bottom:var(--space-3);">Typing input</p>
          <div class="input-mode-toggle">
            <button class="input-mode-toggle__option ${mode==='physical'?'is-active':''}" data-mode="physical">${icon('keys',{size:15})} Physical keyboard</button>
            <button class="input-mode-toggle__option ${mode==='virtual'?'is-active':''}" data-mode="virtual">${icon('tap',{size:15})} Tap keyboard</button>
          </div>
          <p class="text-muted" style="font-size:var(--text-xs);margin-top:var(--space-2);">
            ${mode==='physical'
              ? 'Landscape mode. Use a connected keyboard.'
              : 'Portrait mode. Tap keys on screen.'}
          </p>
        </div>

        <div class="card" style="margin-bottom:var(--space-4);">
          <p class="text-muted" style="font-size:var(--text-sm);">Total XP</p>
          <p class="text-mono" style="font-size:var(--text-2xl);">${state.xp}</p>
        </div>

        <div class="card" style="margin-bottom:var(--space-4);display:flex;justify-content:space-between;">
          <div>
            <p class="text-muted" style="font-size:var(--text-sm);">Lessons</p>
            <p class="text-mono" style="font-size:var(--text-xl);">${state.completedLessons.length}</p>
          </div>
          <div>
            <p class="text-muted" style="font-size:var(--text-sm);">Avg. accuracy</p>
            <p class="text-mono" style="font-size:var(--text-xl);">${avgAccuracy !== null ? avgAccuracy + '%' : '—'}</p>
          </div>
          <div>
            <p class="text-muted" style="font-size:var(--text-sm);">Streak</p>
            <p class="text-mono" style="font-size:var(--text-xl);">${icon('flame',{size:16})} ${state.streakCount}</p>
          </div>
        </div>

        ${weakKeys.length ? `
          <div class="card">
            <p class="text-muted" style="font-size:var(--text-sm);margin-bottom:var(--space-3);">Keys to watch</p>
            <div style="display:flex;gap:var(--space-3);flex-wrap:wrap;">
              ${weakKeys.map(([char, count]) => `
                <div style="text-align:center;">
                  <div class="text-bengali" style="font-size:var(--text-xl);color:var(--signal-red);">${char}</div>
                  <div class="text-mono text-muted" style="font-size:var(--text-xs);">${count}×</div>
                </div>`).join('')}
            </div>
          </div>` : ''}`;

      container.querySelectorAll('.input-mode-toggle__option').forEach(btn => {
        btn.addEventListener('click', () => {
          sound.tap();
          haptics.tap();
          setInputMode(btn.dataset.mode);
          this.render(container);
        });
      });
    }
  });
}

// ── Native plugin bootstrap ─────────────────────────────────────────────
// No-ops in a plain browser tab (window.Capacitor is undefined there) —
// only does anything once the app is actually running inside the
// Capacitor-wrapped native shell.
async function initNativeChrome() {
  const plugins = window.Capacitor?.Plugins;
  if (!plugins) return;

  // Status bar: dark icons over the app's light paper background, and
  // let the WebView draw edge-to-edge underneath it — matches the
  // safe-area-inset handling already built into base.css's #app rules,
  // rather than reserving a separate OS-drawn status bar strip on top.
  try {
    await plugins.StatusBar?.setOverlaysWebView({ overlay: true });
    await plugins.StatusBar?.setStyle({ style: 'DARK' });
  } catch (err) { /* StatusBar plugin not installed — no-op */ }

  // Splash screen: hidden once the first real screen has rendered rather
  // than after a fixed delay, so a slow first paint (cold start, low-end
  // device) never shows unstyled/blank content peeking out from under it.
  try {
    await plugins.SplashScreen?.hide();
  } catch (err) { /* SplashScreen plugin not installed — no-op */ }
}

// ── Boot ─────────────────────────────────────────────────────────────────
function init() {
  const state = store.get();

  if (!state.inputMode) {
    store.set({ inputMode: detectLikelyInputMode() });
  }
  applyInputModeClass();

  if (!state.selectedLayout && !window.location.hash) {
    window.location.hash = '/layout-select';
  }

  ensureBackButton();
  updateChromeDensity();
  bindGlobalKeys();
  registerScreens();
  router.start(document.getElementById('screen'));
  initNativeChrome();

  window.addEventListener('hashchange', updateChromeDensity);
}

document.addEventListener('DOMContentLoaded', init);
