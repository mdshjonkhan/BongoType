/**
 * BongoType — Store
 * --------------------------------------------------------------------------
 * Single source of truth for all app state. Why this exists:
 *
 * 1. Every screen (home, lesson list, lesson runner, profile) needs to read
 *    and sometimes write the same data (XP, current lesson, selected layout).
 *    If each screen kept its own copy, they'd drift out of sync.
 * 2. Persistence (localStorage today, a real backend later) only has to be
 *    wired up in ONE place. Swapping storage later won't touch UI code.
 * 3. Keeping state as a plain object (not scattered across the DOM) makes
 *    it trivial to compute derived things like "accuracy this week" or
    *    "weakest key" later, since the raw data already lives in one shape.
 *
 * Usage:
 *   import { store } from './store.js'
 *   store.get()              -> current state (read-only intent)
 *   store.set(patch)         -> shallow-merge patch into state, persist, notify
 *   store.subscribe(fn)      -> fn called on every change
 */

const STORAGE_KEY = 'bongotype_state_v1';

const defaultState = {
  // -- user identity / preferences --
  selectedLayout: null, // 'bijoy' | 'jatiya' | 'probhat' — null until chosen
  inputMode: null,       // 'physical' | 'virtual' — null until auto-detected or chosen; physical keeps the landscape requirement, virtual switches to a portrait tap-to-type layout
  soundMuted: false,     // persisted mute state — shared across Practice and Lesson screens

  // -- progression --
  xp: 0,
  level: 1,
  currentModuleId: null,
  currentLessonId: null,
  completedLessons: [], // array of lesson ids

  // -- streak / habit tracking --
  streakCount: 0,
  lastPracticeDate: null, // ISO date string 'YYYY-MM-DD'

  // -- gamification: badges & per-lesson best scores --
  unlockedBadges: [], // array of achievement ids, see data/achievements.js
  bestScores: {},      // { [lessonId]: { stars, accuracy, wpm } } — best attempt per lesson

  // -- performance tracking (Phase 5 will populate/consume these) --
  stats: {
    totalPracticeSeconds: 0,
    totalCharsTyped: 0,
    totalCorrectChars: 0,
    mistakesByKey: {}, // { "ক": 3, "খ": 1, ... } — feeds "weak keys" later
    lessonHistory: []  // [{ lessonId, wpm, accuracy, date }]
  }
};

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(defaultState);
    const parsed = JSON.parse(raw);
    // shallow-merge with defaults so new fields added later don't break
    // existing saved state for returning users
    return {
      ...structuredClone(defaultState),
      ...parsed,
      stats: { ...structuredClone(defaultState.stats), ...(parsed.stats || {}) }
    };
  } catch (err) {
    console.error('BongoType store: failed to load saved state, resetting.', err);
    return structuredClone(defaultState);
  }
}

function saveState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('BongoType store: failed to persist state.', err);
  }
}

let state = loadState();
const subscribers = new Set();

export const store = {
  get() {
    return state;
  },

  /** Shallow-merge a patch into state, persist it, notify subscribers. */
  set(patch) {
    state = { ...state, ...patch };
    saveState(state);
    subscribers.forEach((fn) => fn(state));
  },

  /** Merge into the nested `stats` object specifically. */
  setStats(statsPatch) {
    state = { ...state, stats: { ...state.stats, ...statsPatch } };
    saveState(state);
    subscribers.forEach((fn) => fn(state));
  },

  subscribe(fn) {
    subscribers.add(fn);
    return () => subscribers.delete(fn); // unsubscribe handle
  },

  /** Escape hatch for development/testing — wipes all progress. */
  reset() {
    state = structuredClone(defaultState);
    saveState(state);
    subscribers.forEach((fn) => fn(state));
  }
};
