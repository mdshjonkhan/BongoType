/**
 * BongoType — Hand Visualization
 * --------------------------------------------------------------------------
 * Design choice: flat geometric SVG, not a realistic illustration. A
 * schematic hand reads instantly at a glance (which finger is highlighted)
 * the way a diagram in a typing textbook does; a detailed illustration
 * would compete for attention with the thing that actually matters here,
 * which is WHICH FINGER lights up.
 *
 * Each hand is a rounded palm silhouette (narrower at the wrist, wider at
 * the knuckles, drawn as a single path) with five individually-rounded
 * fingers layered on top, each sinking slightly into the palm so there's
 * no visible seam. Fingers stay separate elements (rather than fused into
 * one outline) because each one needs to be independently highlighted.
 * A slight arch across the knuckle line (middle tallest, thumb lowest)
 * keeps the silhouette from reading as a flat row of bars.
 *
 * This module is a pure renderer + small update API. It owns no app state —
 * the caller (practice.js) tells it which hand/finger to highlight, and
 * when to play the press animation.
 *
 * Finger order (left to right, anatomically, for EACH hand independently):
 *   pinky, ring, middle, index, thumb
 * The two hands are mirror images of each other — thumbs always face
 * inward toward the keyboard's center.
 */

const FINGER_ORDER = ['pinky', 'ring', 'middle', 'index', 'thumb'];

// Relative finger lengths (visual only) — index/middle longest, pinky
// shortest, matching real hand proportions closely enough to read clearly
// without needing anatomical precision.
const FINGER_LENGTH = { pinky: 34, ring: 46, middle: 52, index: 44, thumb: 30 };
// Per-finger width — middle/ring slightly wider than pinky, reads more
// natural than five identical-width bars.
const FINGER_WIDTH  = { pinky: 15, ring: 17, middle: 18, index: 17, thumb: 20 };
// Vertical offset applied to each finger's base so the knuckle line arches
// (middle highest, pinky/thumb lower) instead of sitting dead flat.
const FINGER_ARCH    = { pinky: 5, ring: 1, middle: 0, index: 2, thumb: 20 };

/**
 * Build the SVG markup for one hand: a rounded palm silhouette with each
 * finger drawn as its own rounded shape, bases overlapping into the palm
 * by a fixed amount so there's no visible seam between finger and palm —
 * while keeping each finger an independent, individually-colorable element
 * (needed for per-finger highlighting).
 *
 * @param {'L'|'R'} side
 */
function buildHandSvg(side) {
  const isLeft = side === 'L';
  // Drawing order left->right on screen. Thumb sits on the inward side
  // (toward the keyboard's center): right side of the left hand, left
  // side of the right hand.
  const drawOrder = isLeft
    ? ['pinky', 'ring', 'middle', 'index', 'thumb']
    : ['thumb', 'index', 'middle', 'ring', 'pinky'];

  const gap = 3;
  const overlap = 16; // how far each finger's base sinks into the palm
  const palmTopY = 78;
  const palmBottomY = 152;
  const palmHeight = palmBottomY - palmTopY;

  // Compute finger x-centers left to right.
  let x = 16;
  const fingers = drawOrder.map((name) => {
    const w = FINGER_WIDTH[name];
    const cx = x + w / 2;
    x += w + gap;
    return { name, cx, w };
  });
  const palmLeft = fingers[0].cx - fingers[0].w / 2;
  const lastF = fingers[fingers.length - 1];
  const palmRight = lastF.cx + lastF.w / 2;
  const viewW = palmRight + 16;
  const viewH = palmBottomY + 6;

  // Palm silhouette: rounded trapezoid, narrower at the wrist (opposite the
  // thumb side) and wider at the knuckle line.
  const thumbOnRight = !isLeft; // right hand: thumb drawn on the left
  const wristInset = 18;
  const knuckleY = palmTopY + overlap * 0.5;

  const leftTopX  = thumbOnRight ? palmLeft + wristInset * 0.4 : palmLeft - 4;
  const rightTopX = thumbOnRight ? palmRight + 4 : palmRight - wristInset * 0.4;
  const leftBotX  = thumbOnRight ? palmLeft + wristInset : palmLeft + 6;
  const rightBotX = thumbOnRight ? palmRight - 6 : palmRight - wristInset;

  const palmPath = `
    M ${leftBotX} ${palmBottomY}
    Q ${palmLeft - 6} ${palmBottomY} ${leftTopX} ${knuckleY + 14}
    Q ${palmLeft - 2} ${knuckleY} ${palmLeft + 14} ${knuckleY}
    L ${palmRight - 14} ${knuckleY}
    Q ${palmRight + 2} ${knuckleY} ${palmRight + 2} ${knuckleY + 14}
    Q ${palmRight + 6} ${palmBottomY - 10} ${rightBotX} ${palmBottomY}
    Z
  `;

  const fingerShapes = fingers.map((f) => {
    const length = FINGER_LENGTH[f.name];
    const arch = FINGER_ARCH[f.name] || 0;
    const y = palmTopY - length + arch;
    const height = length + overlap - arch;
    return `
      <rect
        class="hand-finger"
        data-finger="${f.name}"
        x="${f.cx - f.w / 2}" y="${y}"
        width="${f.w}" height="${height}"
        rx="${f.w / 2}"
      />
    `;
  }).join('');

  return `
    <svg
      class="hand-svg hand-svg--${side}"
      viewBox="0 0 ${viewW} ${viewH}"
      data-side="${side}"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path class="hand-palm" d="${palmPath}" stroke-linejoin="round" />
      ${fingerShapes}
    </svg>
  `;
}

export class HandVisualization {
  /** @param {HTMLElement} mountEl - container to render both hands into */
  constructor(mountEl) {
    this.mountEl = mountEl;
    this.activeFingerEl = null;
  }

  render() {
    this.mountEl.innerHTML = `
      <div class="hands-row">
        <div class="hand-wrap" data-side="L">${buildHandSvg('L')}</div>
        <div class="hand-wrap" data-side="R">${buildHandSvg('R')}</div>
      </div>
    `;
  }

  /**
   * Highlight the finger responsible for the current target key.
   * @param {{hand: 'L'|'R', finger: string}|null} fingerInfo
   */
  setActiveFinger(fingerInfo) {
    if (this.activeFingerEl) {
      this.activeFingerEl.classList.remove('is-active-finger');
      this.activeFingerEl = null;
    }
    if (!fingerInfo) return;

    const handEl = this.mountEl.querySelector(`.hand-svg--${fingerInfo.hand}`);
    if (!handEl) return;
    const fingerEl = handEl.querySelector(`[data-finger="${fingerInfo.finger}"]`);
    if (!fingerEl) return;

    fingerEl.classList.add('is-active-finger');
    this.activeFingerEl = fingerEl;
  }

  /** Brief "press" pulse on the currently active finger — call on correct keypress. */
  pulseActiveFinger() {
    if (!this.activeFingerEl) return;
    this.activeFingerEl.classList.remove('is-pressing'); // restart animation if mid-flight
    // Force reflow so re-adding the class restarts the CSS animation even
    // if the finger was just pulsed a moment ago.
    void this.activeFingerEl.offsetWidth;
    this.activeFingerEl.classList.add('is-pressing');
  }
}
