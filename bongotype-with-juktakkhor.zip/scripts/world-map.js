/**
 * BongoType — World Map
 * --------------------------------------------------------------------------
 * Replaces the old vertical "ledger" list with a horizontal, winding level
 * path — hugely inspired by TypingLand's world map: numbered stops strung
 * along a hand-drawn trail, alternating high/low, each one a little scene
 * rather than a row of text. This is the landscape shell's centerpiece:
 * a wide format that a portrait list wastes, a horizontal path uses fully.
 *
 * Consumers (home.js for modules-as-worlds, module.js for lessons-as-levels
 * within a world) just hand this a flat list of nodes — it owns layout,
 * the connecting path, scroll-to-current, and click wiring.
 */

import { medallion, starGlyph } from './icons.js';
import { initArrowNav } from './keynav.js';

function starsHtml(stars) {
  return Array.from({ length: 3 }, (_, i) =>
    `<span class="star star--tiny ${i < stars ? 'is-filled' : ''}">${starGlyph(12)}</span>`
  ).join('');
}

/**
 * @param {HTMLElement} container
 * @param {Array<{id:string, title:string, sub?:string, state:'done'|'current'|'locked', glyph?:string, stars?:number|null}>} nodes
 * @param {{ onSelect?: (node:object) => void, scrollToCurrent?: boolean, animateIn?: boolean }} opts
 *   animateIn: when true, nodes and the connecting path reveal stop-by-stop
 *   instead of all at once — used by the standalone map page.
 * @returns {() => void} cleanup function — call when the screen showing this
 *   map is torn down, to remove the resize listener this function attaches.
 *   Without this, every render (every visit to home/module screens) would
 *   leave behind a listener referencing detached DOM from the previous
 *   render, accumulating indefinitely over a session.
 */
export function renderWorldMap(container, nodes, opts = {}) {
  container.innerHTML = '';
  container.classList.add('world-map', 'full-bleed');
  if (opts.animateIn) container.classList.add('world-map--animate-in');

  const scroller = document.createElement('div');
  scroller.className = 'world-map__scroller';
  container.appendChild(scroller);

  const track = document.createElement('div');
  track.className = 'world-map__track';
  track.innerHTML = '<svg class="world-map__path"></svg>';
  scroller.appendChild(track);

  const svg = track.querySelector('.world-map__path');

  if (!nodes.length) {
    const empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.style.padding = 'var(--space-4)';
    empty.textContent = 'Nothing here yet.';
    track.appendChild(empty);
    return () => {};
  }

  const nodeEls = nodes.map((node, i) => {
    const btn = document.createElement('button');
    const rung = i % 3 === 0 ? 'mid' : i % 3 === 1 ? 'high' : 'low';
    btn.className = `world-node world-node--${node.state} world-node--${rung}`;
    btn.type = 'button';
    btn.disabled = node.state === 'locked';
    btn.tabIndex = -1; // reachable via arrow-key roving focus (initArrowNav below), not native Tab order
    btn.style.setProperty('--stagger', i);
    const medallionState = node.state === 'done' ? 'done' : node.state === 'current' ? 'current' : 'locked';
    btn.innerHTML = `
      <span class="world-node__index">${i + 1}</span>
      <span class="world-node__medal">${medallion(node.glyph || 'star', { state: medallionState, size: node.state === 'current' ? 58 : 50, spin: false })}</span>
      ${node.stars != null ? `<span class="world-node__stars">${starsHtml(node.stars)}</span>` : ''}
      <span class="world-node__label">${node.title}</span>
      ${node.sub ? `<span class="world-node__sub">${node.sub}</span>` : ''}
    `;
    if (node.state !== 'locked') {
      btn.addEventListener('click', () => opts.onSelect && opts.onSelect(node));
    }
    track.appendChild(btn);
    return btn;
  });

  // Arrow-key path walking: Right/Left move along the trail in stop order
  // (matches the connecting path visually), Up/Down hop toward whichever
  // neighboring rung (high/mid/low) is closest — same "walk the map, one
  // stop at a time" feel as tapping, but from the keyboard, and independent
  // of the browser's native Tab order (every node is tabIndex -1 above).
  const RUNG_Y = { high: 0, mid: 1, low: 2 };
  const navItems = nodes.map((node, i) => ({
    el: nodeEls[i],
    x: i,
    y: RUNG_Y[i % 3 === 0 ? 'mid' : i % 3 === 1 ? 'high' : 'low'],
    disabled: node.state === 'locked'
  }));
  const currentIdx = nodes.findIndex((n) => n.state === 'current');
  const nav = initArrowNav(navItems, {
    initialIndex: currentIdx !== -1 ? currentIdx : 0,
    axis: 'both',
    onActivate: (item, i) => opts.onSelect && opts.onSelect(nodes[i])
  });

  const draw = () => {
    const trackRect = track.getBoundingClientRect();
    const w = track.scrollWidth;
    const h = track.scrollHeight;
    svg.setAttribute('width', w);
    svg.setAttribute('height', h);
    svg.setAttribute('viewBox', `0 0 ${w} ${h}`);

    let solidD = '';
    let dashD = '';
    nodeEls.forEach((el, i) => {
      const r = el.querySelector('.world-node__medal').getBoundingClientRect();
      const x = r.left - trackRect.left + r.width / 2;
      const y = r.top - trackRect.top + r.height / 2;
      if (i > 0) {
        const prevEl = nodeEls[i - 1];
        const pr = prevEl.querySelector('.world-node__medal').getBoundingClientRect();
        const px = pr.left - trackRect.left + pr.width / 2;
        const py = pr.top - trackRect.top + pr.height / 2;
        const mx = (px + x) / 2;
        const seg = ` M ${px} ${py} Q ${mx} ${py} ${mx} ${(py + y) / 2} Q ${mx} ${y} ${x} ${y}`;
        // Segment is "walked" (solid) once the earlier node is done.
        if (nodes[i - 1].state === 'done') solidD += seg;
        else dashD += seg;
      }
    });
    svg.innerHTML = `
      <path d="${dashD}" class="world-map__path-line world-map__path-line--dash" fill="none"/>
      <path d="${solidD}" class="world-map__path-line world-map__path-line--solid" fill="none"/>
    `;

    // Trace-in: draw the solid "walked" path stroke-first rather than have
    // it just appear, echoing a finger tracing a route on a paper map.
    if (opts.animateIn) {
      const solidPath = svg.querySelector('.world-map__path-line--solid');
      if (solidPath) {
        const len = solidPath.getTotalLength();
        solidPath.style.strokeDasharray = `${len}`;
        solidPath.style.strokeDashoffset = `${len}`;
        solidPath.getBoundingClientRect(); // force layout before transition starts
        solidPath.style.transition = 'stroke-dashoffset 1.1s cubic-bezier(0.22,1,0.36,1)';
        requestAnimationFrame(() => { solidPath.style.strokeDashoffset = '0'; });
      }
    }
  };

  requestAnimationFrame(() => {
    draw();
    if (opts.scrollToCurrent !== false) {
      const idx = nodes.findIndex((n) => n.state === 'current');
      const targetEl = nodeEls[idx !== -1 ? idx : nodeEls.length - 1];
      if (targetEl) {
        scroller.scrollLeft = Math.max(0, targetEl.offsetLeft - scroller.clientWidth / 2 + targetEl.clientWidth / 2);
      }
    }
  });

  window.addEventListener('resize', draw, { passive: true });
  return () => {
    window.removeEventListener('resize', draw);
    nav.destroy();
  };
}
