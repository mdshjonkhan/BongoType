/**
 * BongoType — Haptics Engine
 * --------------------------------------------------------------------------
 * Deliberately mirrors sound.js's API 1:1 (tap/correct/wrong/keyDown/...)
 * so every existing `sound.x()` call site in the app can grow a matching
 * `haptics.x()` call next to it, instead of scattering raw
 * navigator.vibrate() calls (and their inevitable divergent tuning) across
 * components.
 *
 * Two backends, tried in order:
 *   1. Capacitor Haptics plugin, if the app has been wrapped natively
 *      (`window.Capacitor?.Plugins?.Haptics`) — real Taptic/vibration-motor
 *      feedback with proper impact styles, not just a millisecond buzz.
 *   2. Web Vibration API (`navigator.vibrate`) — the fallback for a plain
 *      mobile browser tab. Widely supported on Android Chrome/WebView,
 *      unsupported on iOS Safari (calls become harmless no-ops there).
 *
 * Respects store.hapticsEnabled the same way sound respects soundMuted,
 * and silently no-ops on any device/browser without support — every call
 * site can fire-and-forget without feature-checking itself.
 */

import { store } from './store.js';

let enabled = store.get().hapticsEnabled !== false; // default on

function capacitorHaptics() {
  return window.Capacitor?.Plugins?.Haptics || null;
}

// Pure Web Vibration API fallback — only ever reached from impact()/
// notification() after they've already tried and returned on the
// Capacitor path, so this never needs its own Capacitor check.
function vibrate(pattern) {
  if (!enabled || !navigator.vibrate) return;
  try { navigator.vibrate(pattern); } catch (err) { /* unsupported — no-op */ }
}

async function impact(style) {
  if (!enabled) return;
  const cap = capacitorHaptics();
  if (cap) {
    try { await cap.impact({ style }); } catch (err) { /* no-op */ }
    return;
  }
  // Web fallback tuning, roughly matched to native impact weights.
  const ms = style === 'heavy' ? 25 : style === 'medium' ? 15 : 8;
  vibrate(ms);
}

async function notification(type) {
  if (!enabled) return;
  const cap = capacitorHaptics();
  if (cap) {
    try { await cap.notification({ type }); } catch (err) { /* no-op */ }
    return;
  }
  const pattern = type === 'success' ? [10, 40, 10] : type === 'error' ? [20, 30, 20, 30, 20] : 12;
  vibrate(pattern);
}

export const haptics = {
  /** Light tick — key press, UI tap, nav */
  tap:      () => impact('light'),
  keyDown:  () => impact('light'),
  keyUp:    () => {},
  /** Correct keystroke — very light, shouldn't compete with the sound cue */
  correct:  () => impact('light'),
  /** Wrong keystroke — short sharp double-buzz, distinct from correct */
  wrong:    () => notification('error'),
  /** Combo milestone — light-medium, scales slightly with tier */
  combo:    (tier = 1) => impact(tier >= 3 ? 'medium' : 'light'),
  /** Level up — celebratory success pattern */
  levelUp:  () => notification('success'),
  /** Badge unlock — success pattern, same weight as level-up */
  badge:    () => notification('success'),
  /** Streak milestone */
  streak:   () => impact('medium'),

  setEnabled(v)   { enabled = v; store.set({ hapticsEnabled: enabled }); },
  isEnabled()     { return enabled; },
  toggleEnabled() { enabled = !enabled; store.set({ hapticsEnabled: enabled }); return enabled; }
};
