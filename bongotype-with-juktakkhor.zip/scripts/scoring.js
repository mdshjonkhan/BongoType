/**
 * BongoType — Scoring
 * --------------------------------------------------------------------------
 * Pure calculation functions, no state, no DOM. Kept separate from the
 * lesson engine so the math can be unit-tested in isolation (see the test
 * runs in this phase's build log) and reused anywhere scoring is needed —
 * lessons now, a possible "speed test" mode later, without duplicating
 * formulas in two places.
 *
 * Formulas (per product spec):
 *   Accuracy (%) = correct characters / total characters * 100
 *   WPM = typed words / time in minutes
 *
 * WPM convention note: "words" for typing-speed purposes is NOT a count of
 * space-separated tokens — that breaks down for Bengali, where compound
 * words and conjuncts make character-per-word counts wildly inconsistent
 * compared to English. Instead we use the standard typing-test convention
 * (also used by MonkeyType, TypingClub, etc.): 1 "word" = 5 characters.
 * This keeps WPM numbers meaningful and comparable across lessons of very
 * different content.
 */

const CHARS_PER_WORD = 5;

/**
 * @param {number} correctChars
 * @param {number} totalChars
 * @returns {number} accuracy percentage, 0-100, rounded to 1 decimal
 */
export function calculateAccuracy(correctChars, totalChars) {
  if (totalChars <= 0) return 0;
  const pct = (correctChars / totalChars) * 100;
  return Math.round(pct * 10) / 10;
}

/**
 * @param {number} totalChars - characters typed (correct + incorrect attempts count toward speed, not just correct ones, since speed measures throughput)
 * @param {number} elapsedMs - time elapsed in milliseconds
 * @returns {number} words per minute, rounded to nearest integer
 */
export function calculateWPM(totalChars, elapsedMs) {
  if (elapsedMs <= 0) return 0;
  const minutes = elapsedMs / 60000;
  const words = totalChars / CHARS_PER_WORD;
  return Math.round(words / minutes);
}

/**
 * XP awarded for completing a lesson. Scales with accuracy so precision is
 * rewarded, not just showing up — but a floor ensures finishing a hard
 * lesson with mediocre accuracy still feels worth something (important for
 * a true beginner whose early accuracy will be rough).
 *
 * @param {number} accuracy - 0-100
 * @param {number} baseXp - base XP for this lesson's difficulty/length
 * @returns {number} XP to award, integer
 */
export function calculateLessonXp(accuracy, baseXp = 20) {
  const MIN_MULTIPLIER = 0.5; // even at 0% accuracy, completing still counts for something
  const multiplier = MIN_MULTIPLIER + (accuracy / 100) * (1 - MIN_MULTIPLIER);
  return Math.round(baseXp * multiplier);
}

/**
 * Star rating (0-3) for a finished lesson attempt. Scaled relative to the
 * lesson's own pass threshold rather than a fixed number, since drills vary
 * a lot in difficulty — a 70%-threshold key drill and a 95%-threshold
 * sentence drill shouldn't need the exact same accuracy to feel "3-starred".
 *
 * 0 stars — didn't pass
 * 1 star  — passed
 * 2 stars — solidly cleared the threshold (halfway to perfect)
 * 3 stars — near-perfect (>=97%)
 *
 * @param {number} accuracy - 0-100
 * @param {number} passThresholdAccuracy - the lesson's required accuracy (defaults to 80 for lessons without one, e.g. comprehension checks)
 * @returns {number} 0, 1, 2, or 3
 */
export function calculateStars(accuracy, passThresholdAccuracy = 80) {
  if (accuracy < passThresholdAccuracy) return 0;
  if (accuracy >= 97) return 3;
  const twoStarBar = passThresholdAccuracy + (100 - passThresholdAccuracy) * 0.5;
  if (accuracy >= twoStarBar) return 2;
  return 1;
}

/**
 * Small bonus XP for a long mistake-free run within a single lesson attempt
 * — rewards the "in the zone" feeling of a clean streak, on top of (not
 * instead of) the base accuracy-scaled XP from calculateLessonXp.
 * @param {number} maxCombo - longest run of consecutive correct keystrokes
 * @returns {number} bonus XP, integer
 */
export function calculateComboBonus(maxCombo) {
  if (maxCombo >= 40) return 15;
  if (maxCombo >= 25) return 10;
  if (maxCombo >= 15) return 5;
  return 0;
}

/**
 * Tracks live accuracy/speed during a practice session — accumulates
 * keystroke-level results and exposes a finalize() that produces the
 * lesson's score record. Created fresh per lesson attempt.
 */
export class ScoreTracker {
  constructor() {
    this.correctChars = 0;
    this.totalChars = 0;
    this.mistakesByChar = {}; // { "ক": 2, ... } — feeds weak-key tracking
    this.startedAt = null;
    this.finishedAt = null;
    this.currentCombo = 0; // consecutive correct keystrokes right now
    this.maxCombo = 0;     // longest run reached this attempt
  }

  start() {
    this.startedAt = Date.now();
  }

  /**
   * Record one keystroke result.
   * @param {boolean} isCorrect
   * @param {string} expectedChar - the character that was expected, used for weak-key tracking on mistakes
   */
  recordKeystroke(isCorrect, expectedChar) {
    this.totalChars += 1;
    if (isCorrect) {
      this.correctChars += 1;
      this.currentCombo += 1;
      if (this.currentCombo > this.maxCombo) this.maxCombo = this.currentCombo;
    } else {
      this.mistakesByChar[expectedChar] = (this.mistakesByChar[expectedChar] || 0) + 1;
      this.currentCombo = 0;
    }
  }

  finish() {
    this.finishedAt = Date.now();
    const elapsedMs = this.startedAt ? this.finishedAt - this.startedAt : 0;
    const accuracy = calculateAccuracy(this.correctChars, this.totalChars);
    const wpm = calculateWPM(this.totalChars, elapsedMs);
    return {
      accuracy,
      wpm,
      correctChars: this.correctChars,
      totalChars: this.totalChars,
      mistakesByChar: this.mistakesByChar,
      elapsedMs,
      maxCombo: this.maxCombo
    };
  }
}
