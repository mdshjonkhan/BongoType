/**
 * BongoType — Lesson Engine
 * Drives explain → comprehension → practice drills → score.
 * Reads inputMode from the store to pass tapEnabled to KeyboardEngine.
 */

import { getLayout } from '../data/layouts/index.js';
import { KeyboardEngine } from './keyboard-engine.js';
import { HandVisualization } from './hand-visualization.js';
import { ScoreTracker, calculateLessonXp, calculateStars, calculateComboBonus } from './scoring.js';
import { sound } from './sound.js';
import { haptics } from './haptics.js';
import { store } from './store.js';

function resolveDrills(lesson) {
  if (lesson.drills) return lesson.drills;
  if (lesson.practiceMode) {
    return [{ practiceMode: lesson.practiceMode, keyPool: lesson.keyPool, words: lesson.words, sentences: lesson.sentences, repsRequired: lesson.repsRequired, label: null }];
  }
  return [];
}

function drillToKeySequence(drill) {
  if (drill.practiceMode === 'keys') {
    const reps = drill.repsRequired || drill.keyPool.length;
    const seq = [];
    for (let i = 0; i < reps; i++) seq.push(drill.keyPool[Math.floor(Math.random() * drill.keyPool.length)]);
    return seq;
  }
  if (drill.practiceMode === 'shifted') {
    // Each rep is two sequence steps: hold Shift, then the letter — this is
    // what teaches the physical "shift, then reach" motion instead of just
    // presenting the shifted character on its own. 'ShiftEither' matches
    // either physical Shift key; see keyboard-engine.js.
    const reps = drill.repsRequired || drill.keyPool.length;
    const seq = [];
    for (let i = 0; i < reps; i++) {
      seq.push('ShiftEither', drill.keyPool[Math.floor(Math.random() * drill.keyPool.length)]);
    }
    return seq;
  }
  if (drill.practiceMode === 'words') {
    const seq = [];
    drill.words.forEach((w, i) => { if (i > 0) seq.push('Space'); seq.push(...w); });
    return seq;
  }
  if (drill.practiceMode === 'sentences') {
    const seq = [];
    drill.sentences.forEach((s, i) => { if (i > 0) seq.push('Space'); seq.push(...s); });
    return seq;
  }
  return [];
}

export class LessonEngine {
  constructor(lesson, options) {
    this.lesson = lesson;
    this.opts = options;
    this.layout = getLayout(options.layoutId);
    this.tracker = new ScoreTracker();
    this.drills = resolveDrills(lesson);
    this.currentDrillIndex = -1;
    this.currentSequence = [];
    this.sequencePos = 0;
    this.keyboardEngine = null;
    this.hands = null;
  }

  start() {
    if (this.lesson.type === 'concept') {
      this._runExplainSteps(() => this._runComprehensionCheck());
    } else {
      this._runExplainSteps(() => this._startDrills());
    }
  }

  stop() {
    if (this.keyboardEngine) this.keyboardEngine.stop();
  }

  _runExplainSteps(onDone) {
    const steps = this.lesson.steps || [];
    let i = 0;
    const show = () => {
      if (i >= steps.length) { onDone(); return; }
      this.opts.onStepChange({ phase: 'explain', step: steps[i], stepIndex: i, totalSteps: steps.length });
      i++;
    };
    this.advanceExplain = show;
    show();
  }

  _startDrills() {
    this.tracker.start();
    this.currentDrillIndex = -1;
    this._startNextDrill();
  }

  _startNextDrill() {
    this.currentDrillIndex++;
    if (this.currentDrillIndex >= this.drills.length) { this._finishLesson(); return; }
    const drill = this.drills[this.currentDrillIndex];
    this.currentSequence = drillToKeySequence(drill);
    this.sequencePos = 0;
    this.opts.onStepChange({ phase: 'drill', drill, drillIndex: this.currentDrillIndex, totalDrills: this.drills.length });
    this._ensureEngines();
    this._presentCurrentTarget();
  }

  _ensureEngines() {
    if (this.keyboardEngine) return;
    const isVirtual = store.get().inputMode === 'virtual';
    this.keyboardEngine = new KeyboardEngine(this.layout, this.opts.keyboardMount, { tapEnabled: isVirtual });
    this.keyboardEngine.render();
    this.keyboardEngine.start();
    this.keyboardEngine.onResult = (isCorrect, { code }) => this._handleKeystroke(isCorrect, code);
    this.hands = new HandVisualization(this.opts.handsMount);
    this.hands.render();
  }

  /** True when the PREVIOUS sequence step was the Shift step of a shift+key pair, meaning the current step's character should be read from the layout's `shifted` field instead of `unshifted`. */
  _isShiftedStep(pos) {
    return pos > 0 && this.currentSequence[pos - 1] === 'ShiftEither';
  }

  _charForStep(code, pos) {
    if (code === 'ShiftEither') return '⇧';
    if (code === 'Space') return ' ';
    return this._isShiftedStep(pos)
      ? (this.layout.keys[code]?.shifted ?? '?')
      : (this.layout.keys[code]?.unshifted ?? '?');
  }

  _presentCurrentTarget() {
    const code = this.currentSequence[this.sequencePos];
    if (!code) { this._startNextDrill(); return; }
    this.keyboardEngine.setExpectedKey(code);
    this.hands.setActiveFinger(this.keyboardEngine.getExpectedFinger());
    const char = this._charForStep(code, this.sequencePos);
    this.opts.onStepChange({
      phase: 'drill-target', char,
      drillIndex: this.currentDrillIndex, totalDrills: this.drills.length,
      sequencePos: this.sequencePos, sequenceLength: this.currentSequence.length
    });
  }

  _handleKeystroke(isCorrect, code) {
    const expectedCode = this.currentSequence[this.sequencePos];
    const expectedChar = this._charForStep(expectedCode, this.sequencePos);
    this.tracker.recordKeystroke(isCorrect, expectedChar);
    if (this.opts.onCombo) this.opts.onCombo(this.tracker.currentCombo, isCorrect);
    if (isCorrect) {
      this.hands.pulseActiveFinger();
      this.sequencePos++;
      if (this.sequencePos >= this.currentSequence.length) {
        setTimeout(() => this._startNextDrill(), 220);
      } else {
        setTimeout(() => this._presentCurrentTarget(), 120);
      }
    }
  }

  _finishLesson() {
    if (this.keyboardEngine) this.keyboardEngine.stop();
    const score = this.tracker.finish();
    // Concept lessons (comprehension check only, no drill) have nothing
    // resembling real typing performance behind them — a single instant
    // keystroke produces meaningless 100%/3-star/absurd-WPM numbers. Treat
    // them as pass/fail + XP only, and keep them out of performance-based
    // scoring so they don't cascade into unrelated badges (Flawless,
    // Triple Star, speed badges) on top of the completion badges.
    const isPerformance = this.lesson.type !== 'concept';
    const passThresholdAccuracy = this.lesson.passThreshold?.accuracy ?? 80;
    const baseXp = calculateLessonXp(score.accuracy, this.lesson.baseXp || 15);
    const comboBonus = isPerformance ? calculateComboBonus(score.maxCombo) : 0;
    const xp = baseXp + comboBonus;
    const passed = !this.lesson.passThreshold || score.accuracy >= this.lesson.passThreshold.accuracy;
    const stars = (isPerformance && passed) ? calculateStars(score.accuracy, passThresholdAccuracy) : 0;
    const wpm = isPerformance ? score.wpm : 0;
    const scoreOut = { ...score, wpm };
    this.opts.onStepChange({ phase: 'score', score: scoreOut, xp, comboBonus, stars, passed, isPerformance });
    sound.tap();
    haptics.tap();
    if (this.opts.onComplete) this.opts.onComplete({ ...scoreOut, xp, comboBonus, stars, passed, isPerformance, lessonId: this.lesson.id });
  }

  _runComprehensionCheck() {
    const check = this.lesson.comprehensionCheck;
    if (!check) { this._finishLesson(); return; }
    this.opts.onStepChange({ phase: 'comprehension', check });
  }

  submitComprehensionAnswer(isCorrect) {
    this.tracker.start();
    this.tracker.recordKeystroke(isCorrect, 'comprehension');
    this._finishLesson();
  }
}
