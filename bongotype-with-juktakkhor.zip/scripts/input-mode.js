/**
 * BongoType — Input Mode Detection
 * --------------------------------------------------------------------------
 * Guesses whether the device likely has a physical keyboard attached, to
 * pick a sensible DEFAULT input mode before the user explicitly chooses.
 * This is a heuristic, not a certainty — a Bluetooth keyboard paired to a
 * phone would defeat it, for instance — which is exactly why the app
 * always lets the user override the guess rather than locking to it.
 *
 * Detection signal: the CSS media features `pointer` and `hover`.
 *   - `pointer: fine` + `hover: hover`  -> a mouse/trackpad is the primary
 *     pointing device, which correlates strongly with "this is a laptop
 *     or desktop, which has a physical keyboard."
 *   - `pointer: coarse` (touch is primary) -> phone or tablet, where a
 *     physical keyboard is the exception, not the default.
 * This is the same signal browsers themselves use to distinguish "this is
 * probably a touch device" from "this is probably a desktop," and is far
 * more reliable than user-agent sniffing.
 */

export function detectLikelyInputMode() {
  if (typeof window === 'undefined' || !window.matchMedia) {
    return 'physical'; // safe fallback if matchMedia is unavailable for any reason
  }
  const hasFinePointer = window.matchMedia('(pointer: fine)').matches;
  const hasHover = window.matchMedia('(hover: hover)').matches;
  return (hasFinePointer && hasHover) ? 'physical' : 'virtual';
}
