/**
 * BongoType — Sound Engine
 * All sounds synthesized via Web Audio API — zero asset files.
 * Lazy AudioContext: created on first user gesture.
 *
 * Mute state is persisted in the store (store.soundMuted) so it's shared
 * across every screen that has a mute control (Practice, Lesson) and
 * survives reloads, instead of living as a page-local variable that reset
 * every time the app opened.
 */

import { store } from './store.js';
import { icon as iconFn } from './icons.js';

let ctx = null;
let muted = store.get().soundMuted || false;
let masterGain = null;

function getContext() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    ctx = new AC();
    masterGain = ctx.createGain();
    masterGain.gain.value = 0.8;
    masterGain.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

function dest() { return masterGain || getContext().destination; }

function createNoiseBuffer(c, dur) {
  const n = Math.floor(c.sampleRate * dur);
  const buf = c.createBuffer(1, n, c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  return buf;
}

function osc(c, type, freq, startGain, endGain, startT, endT) {
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(startGain, startT);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0001, endGain), endT);
  o.connect(g); g.connect(dest());
  o.start(startT); o.stop(endT + 0.01);
}

function noise(c, freq, q, startGain, endGain, startT, endT) {
  const src = c.createBufferSource();
  src.buffer = createNoiseBuffer(c, endT - startT + 0.01);
  const f = c.createBiquadFilter();
  f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
  const g = c.createGain();
  g.gain.setValueAtTime(startGain, startT);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0001, endGain), endT);
  src.connect(f); f.connect(g); g.connect(dest());
  src.start(startT); src.stop(endT + 0.01);
}

/* ── Key click: layered noise burst + brief sine tick ─────────────────── */
function playClick(variant = 'down') {
  if (muted) return;
  const c = getContext();
  const t = c.currentTime;
  const f = variant === 'down' ? 2400 : 1600;
  noise(c, f, 1.4, 0.28, 0.001, t, t + 0.025);
  noise(c, f * 0.4, 3, 0.12, 0.001, t, t + 0.04);
  osc(c, 'sine', variant === 'down' ? 1200 : 900, 0.06, 0.001, t, t + 0.012);
}

/* ── Correct: ascending two-tone chime ────────────────────────────────── */
function playCorrect() {
  if (muted) return;
  const c = getContext();
  const t = c.currentTime;
  [[880, 0], [1320, 0.05], [1760, 0.1]].forEach(([freq, delay]) => {
    osc(c, 'sine', freq, 0.14, 0.001, t + delay, t + delay + 0.12);
  });
}

/* ── Wrong: short descending buzz ────────────────────────────────────── */
function playWrong() {
  if (muted) return;
  const c = getContext();
  const t = c.currentTime;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = 'sawtooth';
  o.frequency.setValueAtTime(200, t);
  o.frequency.exponentialRampToValueAtTime(100, t + 0.15);
  g.gain.setValueAtTime(0.07, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
  o.connect(g); g.connect(dest());
  o.start(t); o.stop(t + 0.16);
}

/* ── UI tap ──────────────────────────────────────────────────────────── */
function playTap() {
  if (muted) return;
  const c = getContext();
  const t = c.currentTime;
  osc(c, 'sine', 680, 0.07, 0.001, t, t + 0.045);
}

/* ── Level-up fanfare ────────────────────────────────────────────────── */
function playLevelUp() {
  if (muted) return;
  const c = getContext();
  const t = c.currentTime;
  const notes = [523, 659, 784, 1047]; // C5 E5 G5 C6
  notes.forEach((freq, i) => {
    const d = i * 0.09;
    osc(c, 'triangle', freq, 0.18, 0.001, t + d, t + d + 0.15);
    osc(c, 'sine', freq * 2, 0.05, 0.001, t + d, t + d + 0.12);
  });
  // final held chord
  [523, 784, 1047].forEach(freq => {
    osc(c, 'sine', freq, 0.12, 0.001, t + 0.4, t + 0.9);
  });
}

/* ── Streak milestone ────────────────────────────────────────────────── */
function playStreak() {
  if (muted) return;
  const c = getContext();
  const t = c.currentTime;
  [440, 554, 659, 880].forEach((freq, i) => {
    osc(c, 'sine', freq, 0.12, 0.001, t + i * 0.07, t + i * 0.07 + 0.1);
  });
}

/* ── Badge unlock: bright bell-like pop ──────────────────────────────── */
function playBadge() {
  if (muted) return;
  const c = getContext();
  const t = c.currentTime;
  [1046, 1568].forEach((freq, i) => {
    const d = i * 0.06;
    osc(c, 'triangle', freq, 0.15, 0.001, t + d, t + d + 0.22);
    osc(c, 'sine', freq * 2, 0.05, 0.001, t + d, t + d + 0.15);
  });
}

/* ── Combo tick: rising pitch per combo tier, for live feedback ───────── */
function playCombo(tier) {
  if (muted) return;
  const c = getContext();
  const t = c.currentTime;
  const freq = 660 + Math.min(tier, 8) * 60;
  osc(c, 'sine', freq, 0.09, 0.001, t, t + 0.08);
}

export const sound = {
  keyDown:  () => playClick('down'),
  keyUp:    () => playClick('up'),
  correct:  playCorrect,
  wrong:    playWrong,
  tap:      playTap,
  levelUp:  playLevelUp,
  streak:   playStreak,
  badge:    playBadge,
  combo:    playCombo,
  setMuted(v)   { muted = v; store.set({ soundMuted: muted }); },
  isMuted()     { return muted; },
  toggleMuted() { muted = !muted; store.set({ soundMuted: muted }); return muted; },

  /**
   * Shared mute-button markup, used by both Practice and Lesson screens so
   * the control looks and behaves identically everywhere sound plays,
   * rather than each screen re-implementing (and drifting from) its own
   * copy. Returns an HTML string; call sound.wireMuteButton(el) after
   * inserting it into the DOM to attach the click handler.
   * @param {{size?: number}} [opts]
   */
  muteButtonHtml(opts = {}) {
    const size = opts.size || 16;
    return `<button class="mute-toggle" id="mute-btn" type="button" aria-label="${muted ? 'Unmute sound' : 'Mute sound'}" aria-pressed="${muted}">${iconFn(muted ? 'muteOff' : 'muteOn', { size })}</button>`;
  },

  /** Wire up a mute button previously inserted via muteButtonHtml(). */
  wireMuteButton(btnEl, { size = 16 } = {}) {
    if (!btnEl) return;
    btnEl.addEventListener('click', () => {
      const m = this.toggleMuted();
      if (!m) playTap(); // only unmuting gives audible confirmation — muting should be silent immediately
      btnEl.innerHTML = iconFn(m ? 'muteOff' : 'muteOn', { size });
      btnEl.setAttribute('aria-label', m ? 'Unmute sound' : 'Mute sound');
      btnEl.setAttribute('aria-pressed', String(m));
    });
  }
};
