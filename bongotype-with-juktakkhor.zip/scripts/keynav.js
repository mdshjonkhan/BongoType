/**
 * BongoType — Keyboard Navigation (Arrow-key roving focus)
 * --------------------------------------------------------------------------
 * Every screen in this app needs to be fully operable from a physical
 * keyboard — expected for a typing app — WITHOUT relying on the browser's
 * native Tab order the way a generic web page would. Tab-order navigation
 * is one-dimensional and forces the browser's own focus ring through every
 * focusable node in DOM order; it says nothing about which button is
 * visually "next" on a winding world-map path or a two-column menu, and it
 * fights with elements (like a virtual keyboard mount) that shouldn't be
 * Tab stops at all.
 *
 * Instead, each screen owns a small array of "targets" — element + a 2D
 * (col,row) position — and this module moves a single roving highlight
 * between them using the arrow keys, activating the highlighted one with
 * Enter/Space. This mirrors how TypingLand and similar level-select screens
 * behave: the d-pad/arrow keys walk the path, one button confirms.
 *
 * Usage:
 *   import { initArrowNav } from './keynav.js';
 *   const nav = initArrowNav(items, {
 *     onActivate: (item, index) => { ... },
 *     initialIndex: 2,
 *     wrap: true,       // arrow past the last item wraps to the first
 *     axis: 'both'       // 'x' | 'y' | 'both' — which arrow keys move focus
 *   });
 *   ...
 *   nav.destroy(); // on screen teardown
 *
 * Each item is { el: HTMLElement, x: number, y: number, disabled?: boolean }.
 * x/y don't need to be pixel-accurate — just relative order/lane, e.g. the
 * item's index for a simple list, or (column, row) for a grid/menu.
 */

function nearest(items, from, dx, dy) {
  // Prefer the closest item roughly in the requested direction; falls back
  // to plain index order (dx>0 = next, dx<0 = prev) for single-axis lists
  // where every item shares the same row/column.
  const candidates = items
    .map((item, i) => ({ item, i }))
    .filter(({ item, i }) => i !== from && !item.disabled);
  if (!candidates.length) return -1;

  const originItem = items[from];
  if (dy === 0 && dx !== 0) {
    // Horizontal move: same row preferred, else nearest row — but ONLY
    // among candidates that are actually forward in the requested
    // direction. Falling back to "closest overall" here (rather than
    // returning -1) would silently teleport backward at the last item
    // instead of letting the caller treat this as an end-of-axis and wrap.
    const sameRow = candidates.filter(({ item }) => item.y === originItem.y);
    const pool = sameRow.length ? sameRow : candidates;
    const forward = pool.filter(({ item }) => (dx > 0 ? item.x > originItem.x : item.x < originItem.x));
    if (!forward.length) return -1;
    forward.sort((a, b) => Math.abs(a.item.x - originItem.x) - Math.abs(b.item.x - originItem.x));
    return forward[0].i;
  }
  if (dx === 0 && dy !== 0) {
    const sameCol = candidates.filter(({ item }) => item.x === originItem.x);
    const pool = sameCol.length ? sameCol : candidates;
    const forward = pool.filter(({ item }) => (dy > 0 ? item.y > originItem.y : item.y < originItem.y));
    if (!forward.length) return -1;
    forward.sort((a, b) => Math.abs(a.item.y - originItem.y) - Math.abs(b.item.y - originItem.y));
    return forward[0].i;
  }
  return -1;
}

/**
 * @param {Array<{el:HTMLElement, x:number, y:number, disabled?:boolean}>} items
 * @param {object} opts
 * @param {(item:object, index:number) => void} [opts.onActivate] — called on Enter/Space
 * @param {(item:object, index:number) => void} [opts.onMove] — called whenever the highlight moves
 * @param {number} [opts.initialIndex] — which item starts highlighted (first non-disabled by default)
 * @param {boolean} [opts.wrap=false] — whether moving past either end wraps around
 * @param {'x'|'y'|'both'} [opts.axis='both'] — which arrow keys are active
 * @param {HTMLElement} [opts.scope=window] — element to attach the keydown listener to
 * @returns {{ destroy: () => void, setIndex: (i:number) => void, getIndex: () => number }}
 */
export function initArrowNav(items, opts = {}) {
  const { onActivate, onMove, wrap = false, axis = 'both', scope = window } = opts;
  let index = opts.initialIndex != null
    ? opts.initialIndex
    : items.findIndex((it) => !it.disabled);
  if (index < 0) index = 0;

  function highlight(i) {
    items.forEach((it, n) => it.el && it.el.classList.toggle('is-kbfocus', n === i));
    const el = items[i] && items[i].el;
    if (el && el.scrollIntoView) {
      el.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
    }
  }

  function move(dx, dy) {
    if (!items.length) return;
    let next = nearest(items, index, dx, dy);
    if (next === -1 && wrap) {
      // Wrap: jump to the far end along the same axis.
      const enabled = items.map((it, i) => ({ it, i })).filter(({ it }) => !it.disabled);
      if (!enabled.length) return;
      next = dx > 0 || dy > 0 ? enabled[0].i : enabled[enabled.length - 1].i;
    }
    if (next === -1) return;
    index = next;
    highlight(index);
    if (onMove) onMove(items[index], index);
  }

  function activate() {
    const item = items[index];
    if (!item || item.disabled) return;
    if (onActivate) onActivate(item, index);
  }

  function handleKey(e) {
    if (!items.length) return;
    switch (e.key) {
      case 'ArrowRight':
        if (axis === 'x' || axis === 'both') { e.preventDefault(); move(1, 0); }
        break;
      case 'ArrowLeft':
        if (axis === 'x' || axis === 'both') { e.preventDefault(); move(-1, 0); }
        break;
      case 'ArrowDown':
        if (axis === 'y' || axis === 'both') { e.preventDefault(); move(0, 1); }
        break;
      case 'ArrowUp':
        if (axis === 'y' || axis === 'both') { e.preventDefault(); move(0, -1); }
        break;
      case 'Enter':
      case ' ':
        e.preventDefault();
        activate();
        break;
      default:
        break;
    }
  }

  scope.addEventListener('keydown', handleKey);
  highlight(index);

  return {
    destroy() {
      scope.removeEventListener('keydown', handleKey);
      items.forEach((it) => it.el && it.el.classList.remove('is-kbfocus'));
    },
    setIndex(i) { index = i; highlight(index); },
    getIndex() { return index; }
  };
}

/**
 * Convenience wrapper for the common case: a flat row/list of buttons that
 * should map to number keys 1-9 as direct jumps, IN ADDITION to arrow nav.
 * Used by short menus (layout picker, sidebar) where "press 2" is faster
 * than arrowing over.
 *
 * @param {Array<HTMLElement>} elements
 * @param {(el:HTMLElement, index:number) => void} onActivate
 * @param {HTMLElement} [scope=window]
 * @returns {() => void} cleanup
 */
export function bindNumberShortcuts(elements, onActivate, scope = window) {
  function handleKey(e) {
    const n = parseInt(e.key, 10);
    if (Number.isNaN(n) || n < 1 || n > elements.length) return;
    const el = elements[n - 1];
    if (!el || el.disabled) return;
    e.preventDefault();
    onActivate(el, n - 1);
  }
  scope.addEventListener('keydown', handleKey);
  return () => scope.removeEventListener('keydown', handleKey);
}
