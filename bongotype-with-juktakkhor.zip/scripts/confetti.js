/**
 * BongoType — Confetti
 * --------------------------------------------------------------------------
 * Deliberately NOT a canvas/physics system — this is a celebratory garnish
 * for level-ups, badge unlocks, and 3-star lessons, not a game engine
 * feature. A handful of absolutely-positioned divs with a CSS fall+spin
 * animation (see .confetti-piece in styles/lesson.css) gets the same
 * felt effect at a fraction of the code and with zero per-frame JS.
 * Pieces remove themselves after their animation ends.
 */

const PALETTE = ['#C9A227', '#E0392F', '#00543C', '#8B7355', '#FBF7EE'];
const SHAPES = ['is-petal', 'is-dot', 'is-diamond'];

/**
 * @param {HTMLElement} container - positioned ancestor (position: relative/absolute) confetti falls within
 * @param {number} count - how many pieces to spawn
 */
export function spawnConfetti(container, count = 24) {
  if (!container || document.hidden) return;
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  for (let i = 0; i < count; i++) {
    const piece = document.createElement('div');
    piece.className = `confetti-piece ${SHAPES[i % SHAPES.length]}`;
    const left = Math.random() * 100;
    const delay = Math.random() * 0.15;
    const duration = 0.9 + Math.random() * 0.6;
    const drift = (Math.random() - 0.5) * 60;
    const color = PALETTE[Math.floor(Math.random() * PALETTE.length)];
    const size = 6 + Math.random() * 5;
    piece.style.left = `${left}%`;
    piece.style.background = color;
    piece.style.width = `${size}px`;
    piece.style.height = `${size * 0.85}px`;
    piece.style.animationDelay = `${delay}s`;
    piece.style.animationDuration = `${duration}s`;
    piece.style.setProperty('--drift', `${drift}px`);
    container.appendChild(piece);
    piece.addEventListener('animationend', () => piece.remove(), { once: true });
  }
}
