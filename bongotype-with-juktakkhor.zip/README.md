# BongoType

A Bengali touch-typing learning platform. Runs as a plain web app in any
browser, or packaged as a native Android app via Capacitor.

## Project structure

```
index.html                Entry point (source — edit this)
build-fallback.js         Regenerates scripts/bundle.js from the ES module source
build-www.js               Assembles www/ (Capacitor's webDir) from the real source
components/                Screen-level UI (home, lesson, practice, badges, etc.)
scripts/                   Core engines (router, store, keyboard engine, lesson engine,
                            achievements, confetti, haptics, ...)
scripts/bundle.js          AUTO-GENERATED fallback bundle — do not edit by hand
data/layouts/               Bijoy / National(Jatiya) / Probhat keyboard layouts
data/lessons/                Module 0-2 curriculum content
data/achievements.js        Badge/achievement definitions
styles/                     CSS
resources/                  Icon + splash SOURCE images for native asset generation
assets/icons/                Icon also linked from index.html/manifest (PWA/browser case)
capacitor.config.json        Native app config (see "Packaging as a native Android app")
package.json                 Capacitor deps + build/run scripts
www/                         AUTO-GENERATED — copy of source assembled by build-www.js,
                              this is what actually ships inside the native app
```

## Gamification layer

On top of the original XP/level/streak system, BongoType now has (inspired
by TypingLand-style typing games):

- **Star ratings** — every practice lesson earns 0-3 stars based on
  accuracy relative to its own pass threshold. Stars persist as each
  lesson's best attempt (`store.bestScores`) and show up in the module
  ledger instead of a plain checkmark.
- **Live combo meter** — a streak counter appears during drills once you
  hit 3 mistake-free keystrokes in a row, pulses and chimes at every 5th
  hit, and a long combo (15+/40+) grants bonus XP on top of the lesson's
  base reward.
- **Badges** — 19 achievements (`data/achievements.js`) covering first
  lesson, lesson-count milestones, module completions, perfect accuracy,
  star ratings, combo streaks, WPM milestones, practice streaks, and level
  milestones. A dedicated **Badges** tab (🏅 in the bottom nav) shows the
  full collection, locked ones included as goals to chase. The home screen
  also shows a quick shelf of recent/next badges.
- **Celebrations** — level-ups, badge unlocks, and 3-star lessons now
  trigger a lightweight confetti burst (`scripts/confetti.js`) alongside
  the existing banners and sound cues.

## Full keyboard control (no Tab required)

Every screen is completely operable from a physical keyboard, without ever
relying on the browser's native Tab order — matching TypingLand's own
keyboard-first, D-pad-style level select rather than a generic webpage's
tab-through behavior:

- **`scripts/keynav.js`** — shared roving-focus helper used everywhere a
  screen has more than one actionable target. Every nav-managed button is
  `tabindex="-1"` (removed from the native Tab order on purpose); arrow
  keys move a single highlight (`.is-kbfocus`) between targets based on
  their declared 2D position, Enter/Space activates whichever one is
  highlighted. `bindNumberShortcuts()` layers direct number-key jumps
  (`1`-`9`) on top for short lists, so "press 2" beats arrowing over.
- **World map (`scripts/world-map.js`)** — Left/Right walk the trail in
  stop order, Up/Down hop to the nearest higher/lower rung, Enter opens
  the highlighted stop. Locked nodes are skipped automatically. Used by
  both the home screen's world-of-modules map and each module's
  world-of-lessons map, so every level (see "Level/lesson coverage"
  below) is keyboard-reachable the same way.
- **Home screen (`components/home.js`)** — Up/Down cycle the menu button,
  layout chip, and "Continue your journey" CTA; Enter activates. Opening
  the menu switches focus to its four destinations (also Up/Down + Enter,
  plus number keys `1`-`4` for a direct jump); Escape closes the menu
  without leaving the home screen. A number badge next to each sidebar
  item mirrors this.
- **Layout picker (`components/layout-select.js`)** — Up/Down + Enter, or
  press `1`/`2`/`3` to pick Bijoy/National/Probhat directly.
- **Lesson runner (`components/lesson.js`)** — unchanged from before this
  pass, already keyboard-first: Enter/Space advances explain steps and the
  post-lesson score screen, number keys answer comprehension checks, and
  the drill itself is typed on a real/virtual keyboard via
  `scripts/keyboard-engine.js`.
- **Global Escape** (`scripts/app.js`) backs out one screen from anywhere
  except home, backed by real browser history so the Android hardware/
  gesture back button does the same thing for free.

Every nav scope is torn down (`hashchange`) and rebuilt on each screen
visit, the same lifecycle the rest of the app already follows for its own
event listeners — so there's nothing extra to wire up when adding a new
screen beyond declaring its targets to `initArrowNav`.

## Level/lesson coverage

The full curriculum is 4 modules / 10 lessons, all registered in
`data/lessons/index.js` and reachable from the world map:

| Module | Lessons |
| --- | --- |
| `m0` — Introduction | `m0-l1` Touch typing basics |
| `m1` — Base Row | `m1-l1` Home anchor keys (F, J), `m1-l2` Full home row |
| `m2` — Beyond the Home Row | `m2-l1` Top row, `m2-l2` Bottom row, `m2-l3` Shifted values |
| `m3` — Juktakkhor (conjunct consonants) | `m3-l1` Building blocks (হসন্ত/রেফ-ফলা/য-ফলা), `m3-l2` Juktakkhor words, `m3-l3` Full sentences, `m3-l4` Harder sentences |

Module 3 is the one place the curriculum teaches typing consonant
*clusters* (যুক্তাক্ষর) rather than individual keys, and its own internal
progression graduates in three strict steps: building-block clusters →
real juktakkhor words → full sentences at the same difficulty → longer
sentences with denser/rarer conjuncts (`m3-l4`). See the file-level
comment in `data/lessons/module-3.js` for the exact hasant/ra-phala/
ya-phala key mechanics.

Every lesson ID is unique, `getLessonState()` correctly locks/unlocks each
one based on curriculum order and `completedLessons`, and both world-map
layers (home → modules, module → lessons) render every entry — nothing is
orphaned or missing from either map.

## Running it in a browser (no native wrap needed)

Any static file server works, from the project root — this uses the
source files directly, not `www/`:

```
npx serve .
# or
python3 -m http.server 8080
```

Then open the served URL in a browser (not `file://` — ES modules require
`http://`). This is the fastest loop for day-to-day development; the
Capacitor/Android path below is for producing an installable app.

## The fallback mechanism

The app normally boots via `<script type="module" src="./scripts/app.js">`
in `index.html`. ES modules can fail to load for environment reasons that
have nothing to do with the app's logic — a stale cache serving an old
file, a server returning the wrong MIME type for `.js` files, `file://`
protocol restrictions, etc.

`index.html` detects this automatically: if the modular script doesn't
finish loading within ~800ms (or fires a load error), it injects
`scripts/bundle.js` instead — a single plain `<script>` with **no**
`import`/`export` statements at all, so it cannot suffer that class of
failure. Functionally it's the same app; everything is just concatenated
into one file and the module syntax is mechanically stripped out.

### Regenerating the bundle

`scripts/bundle.js` is **generated**, not hand-maintained — editing it
directly will be overwritten the next time someone runs the build. If you
change any file under `components/`, `scripts/`, or `data/`, regenerate
the fallback afterward:

```
node build-fallback.js
```

This reads the real import graph from the source files, computes the
correct dependency order automatically (so you never have to maintain an
ordering list by hand), and writes a fresh `scripts/bundle.js`.

## Native-feel polish (this pass)

The app was functionally complete but read as "a website in an app
frame." This pass closes that gap on the web-app side, ahead of the
actual Capacitor/native wrap:

- **`scripts/haptics.js`** — new module, mirrors `sound.js`'s API
  (`tap`/`correct`/`wrong`/`levelUp`/`badge`/`combo`/`streak`) so every
  existing sound cue now has a matching vibration. Tries the Capacitor
  Haptics plugin first (once wrapped), falls back to the Web Vibration
  API in a plain browser tab. Wired into every `sound.*` call site in
  `keyboard-engine.js`, `lesson.js`, `lesson-engine.js`, `home.js`,
  `module.js`, and `app.js`.
- **Touch-target hygiene (`styles/base.css`)** — removed the gray
  tap-highlight flash, long-press text-selection callout, and double-tap
  zoom app-wide (previously only handled on the virtual keyboard).
  Inputs/textareas opt back into text selection.
- **Hover-state leakage** — every `:hover` rule across `components.css`,
  `world-map.css`, and `illustrations.css` is now gated behind
  `@media (hover: hover) and (pointer: fine)`, so touch taps can't leave a
  control visually "stuck" in its hover state the way bare `:hover` does
  on touch browsers/WebViews.
- **Safe-area insets** — `#app` now pads all four edges with
  `env(safe-area-inset-*)`, not just the floating back button, so content
  clears the notch/status bar/gesture-nav capsule on every edge (matters
  more than usual here since the app is landscape-first).
- **Screen transitions (`router.js` / `base.css`)** — navigation now has a
  short fade/settle instead of an instant hard cut. Purely presentational
  — `render()` still runs synchronously, so no screen's timer/listener
  setup changes timing.
- **Scroll feel** — `overscroll-behavior` on `body`/`main#screen` so
  scrolling past the end doesn't rubber-band into browser chrome or
  trigger pull-to-refresh.
- **`manifest.webmanifest` + `assets/icons/icon.svg`** — installable as a
  standalone PWA in the meantime (no browser chrome when added to home
  screen), and doubles as the source Capacitor will read for its own
  icon/name config when the native wrap happens.

## Packaging as a native Android app (Capacitor)

The project is now scaffolded for [Capacitor](https://capacitorjs.com/):

```
capacitor.config.json    App id/name, webDir, native plugin config
package.json             Capacitor deps + build/run scripts
build-www.js             Assembles www/ (the webDir) from the real source
resources/               Icon + splash SOURCE images (@capacitor/assets reads these)
assets/icons/icon.svg    Same icon, also linked from index.html/manifest for
                          the PWA/browser case
```

**Why `android/` isn't in this zip:** `npx cap add android` needs network
access to download the Capacitor Android platform template and Gradle
dependencies — generating that by hand instead risks a subtly-broken
Gradle project (wrong AGP/SDK version pins, a non-functional Gradle
wrapper jar, etc.) that looks complete but fails to build. Safer to let
Capacitor's own generator do it; everything it needs is already in place
below.

### First-time setup (run locally, needs network)

```
npm install
npm run build              # regenerates bundle.js + assembles www/
npx cap add android        # generates android/ — the actual native project
npm run assets:generate    # generates all icon/splash densities into android/
                            # from resources/icon.svg + resources/splash.svg
npx cap sync android
```

**Before that `assets:generate` step**, make sure Noto Sans/Serif Bengali
is installed on whatever machine runs it — `resources/icon.svg` and
`resources/splash.svg` both render the ব glyph as an SVG `<text>` element
for editability, which means it depends on that font being available to
whatever rasterizes it. If the font isn't installed, the glyph can
silently drop to a fallback serif or render as a missing-glyph box. Either
install the font first, or open the SVG in a vector editor (e.g. Inkscape:
Path → Object to Path) and convert the glyph to a path before generating
assets — the rest of both files (rosette, rim, background) is already
plain vector paths with no such dependency.

### Building the APK

```
npx cap open android       # opens the generated project in Android Studio
```

From Android Studio: Build → Build Bundle(s)/APK(s) → Build APK(s), or
run directly on a connected device/emulator with the Run button. Command-
line equivalent once `android/` exists: `cd android && ./gradlew
assembleDebug` (output lands in `android/app/build/outputs/apk/debug/`).

### After any source change

```
npm run android:sync       # rebuild bundle.js + www/, then cap sync
```

`npx cap sync` copies the fresh `www/` into the native project and
updates native plugin registrations — run it after editing anything
under `components/`, `scripts/`, `data/`, `styles/`, or `index.html`, the
same way `build-fallback.js` already needed a re-run after any source
edit.

### What's already wired up for the native shell

- **`scripts/haptics.js`** checks for `window.Capacitor.Plugins.Haptics`
  first and only falls back to the Web Vibration API if that's absent —
  no changes needed once the native wrap exists, it upgrades itself.
- **`scripts/app.js`**'s `initNativeChrome()` sets the status bar style
  and hides the splash screen once the first screen has actually
  rendered (not a fixed timer), both as no-ops in a plain browser tab.
- **`capacitor.config.json`**'s `StatusBar.overlaysWebView: true` matches
  the `env(safe-area-inset-*)` padding already in `base.css`'s `#app`
  rule — the WebView draws edge-to-edge and the app's own CSS keeps
  content clear of the notch/status bar/gesture-nav capsule, rather than
  reserving a separate OS-drawn bar on top of the app's UI.

