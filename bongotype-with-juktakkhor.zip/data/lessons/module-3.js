/**
 * BongoType — Module 3: Juktakkhor (যুক্তাক্ষর / Conjunct Consonants)
 * --------------------------------------------------------------------------
 * Nothing in the previous curriculum ever asked a learner to JOIN two
 * consonants together — Module 2 finishes with every physical key taught,
 * but "physical keys" and "how Bengali actually clusters consonants" are
 * different skills. Real Bengali text is full of juktakkhor (গ্র, স্ক, ক্ষ,
 * ন্দ, ...), so a curriculum that stops at "every key individually" leaves
 * a learner unable to type most real words. This module closes that gap.
 *
 * Same step pattern the rest of the curriculum already uses (explain ->
 * practice), but the internal progression is the one requested for this
 * module specifically, three strictly increasing stages:
 *   1. Building blocks — the keys that JOIN consonants (হসন্ত, ্র রেফ-ফলা,
 *      ্য য-ফলা) practiced in isolation, on short 2-3 key clusters.
 *   2. Juktakkhor words — real, common Bengali words built from those
 *      clusters, practiced as whole words (not just the cluster alone).
 *   3. Full sentences — those words strung into normal sentences, at the
 *      SAME conjunct density as stage 2.
 *   4. Harder sentences — longer sentences, denser/rarer conjuncts
 *      (triple clusters like স্ট্র, ষ্ট্র), higher rep count.
 *
 * Exactly like Module 2's file-level note: words/sentences below are
 * ARRAYS OF PHYSICAL KEY CODES, not literal Bengali text, so they stay
 * layout-agnostic — resolved through whichever layout (bijoy/probhat/
 * jatiya) is currently active. See lesson-engine.js's `_charForStep` for
 * how a 'ShiftEither' code immediately followed by a letter code resolves
 * to that letter's SHIFTED character — used here for শ/ষ/ী and for the
 * shifted ্য (ya-phala) that Bijoy puts on KeyZ's shift layer.
 *
 * Juktakkhor formation used throughout (Bijoy key positions):
 *   KeyG          -> ্  (হসন্ত / hasant) — generic joiner: consonant + KeyG + consonant
 *   KeyZ          -> ্র (রেফ-ফলা / ra-phala)  — pre-built "+ র" subjoin, e.g. ক + KeyZ = ক্র
 *   Shift+KeyZ    -> ্য (য-ফলা / ya-phala)    — pre-built "+ য" subjoin, e.g. ব + Shift+KeyZ = ব্য
 * This module deliberately only uses these three joiners — every other
 * "rare" conjunct form (well below the reph/repha-vowel forms noted as
 * out-of-scope in data/layouts/bijoy.js) is left for a future module, same
 * "don't overload the learner" principle the layout files already state.
 */

function withSpaces(...wordArrays) {
  const result = [];
  wordArrays.forEach((word, i) => {
    if (i > 0) result.push('Space');
    result.push(...word);
  });
  return result;
}

// ---- Stage 1 building blocks: bare consonant clusters, no vowel needed ----
// Each "word" here is really just a cluster, kept in the words drill format
// so it reuses the exact same practice UI as real words one lesson later.
const CLUSTER_KKA   = ['KeyJ', 'KeyG', 'KeyJ'];              // ক্ক  (ka + hasant + ka)
const CLUSTER_STA   = ['KeyN', 'KeyG', 'KeyT'];              // স্ট  (sa + hasant + ta)
const CLUSTER_KRA   = ['KeyJ', 'KeyZ'];                      // ক্র  (ka + ra-phala)
const CLUSTER_BYA   = ['KeyH', 'ShiftEither', 'KeyZ'];       // ব্য  (ba + ya-phala)
const CLUSTER_NDA   = ['KeyB', 'KeyG', 'KeyL'];              // ন্দ  (na + hasant + da)
const CLUSTER_KSHA  = ['KeyJ', 'KeyG', 'ShiftEither', 'KeyN']; // ক্ষ (ka + hasant + sha)

// ---- Stage 2 words: common juktakkhor words, taught keys only ----
const WORD_SKUL    = ['KeyN', 'KeyG', 'KeyJ', 'KeyS', 'ShiftEither', 'KeyV'];              // স্কুল  (school)
const WORD_JONMO   = ['KeyU', 'KeyB', 'KeyG', 'KeyM'];                                     // জন্ম   (birth)
const WORD_PODDO   = ['KeyR', 'KeyL', 'KeyG', 'KeyM'];                                     // পদ্ম   (lotus)
const WORD_SHOTTO  = ['KeyN', 'KeyK', 'ShiftEither', 'KeyZ'];                              // সত্য   (truth)
const WORD_BISSHO  = ['KeyH', 'KeyD', 'ShiftEither', 'KeyM', 'KeyG', 'KeyH'];              // বিশ্ব  (world)
const WORD_SHOPNO  = ['KeyN', 'KeyG', 'KeyH', 'KeyR', 'KeyG', 'KeyB'];                     // স্বপ্ন  (dream)

// ---- Stage 4 harder words: denser/rarer conjuncts, longer chains ----
const WORD_RASHTRO = ['KeyV', 'KeyF', 'ShiftEither', 'KeyN', 'KeyG', 'KeyT', 'KeyZ'];      // রাষ্ট্র (state/nation) — triple cluster ষ্ট্র
const WORD_SHASTHO = ['KeyN', 'KeyG', 'KeyH', 'KeyF', 'KeyN', 'KeyG', 'ShiftEither', 'KeyK', 'ShiftEither', 'KeyZ']; // স্বাস্থ্য (health)
const WORD_BIDDA   = ['KeyH', 'KeyD', 'KeyL', 'ShiftEither', 'KeyZ', 'KeyF'];              // বিদ্যা  (education/learning)
const WORD_SONGEET = ['KeyN', 'KeyQ', 'KeyG', 'KeyO', 'ShiftEither', 'KeyD', 'KeyK'];      // সঙ্গীত (music)

export const module3 = {
  id: 'm3',
  title: 'Juktakkhor',
  description: 'Joining consonants: words, then sentences, then harder ones',
  glyph: 'mountain',
  lessons: [
    {
      id: 'm3-l1',
      title: 'Lesson 1: Building blocks',
      type: 'practice',
      baseXp: 22,
      handFocus: 'both',
      steps: [
        {
          kind: 'explain',
          heading: 'Consonants can join together',
          body: 'A juktakkhor (যুক্তাক্ষর) is two or more consonants fused into one cluster with no vowel between them, like the স্ক in স্কুল. Hold হসন্ত (্) between two consonants to fuse them — G is হসন্ত on this layout.'
        },
        {
          kind: 'explain',
          heading: 'Two shortcuts: রেফ-ফলা and য-ফলা',
          body: 'Two joins are common enough to get their own key: KeyZ adds ্র (a subjoined র, as in ক্র), and Shift+KeyZ adds ্য (a subjoined য, as in ব্য) — both skip the separate হসন্ত step.'
        }
      ],
      drills: [
        { practiceMode: 'keys', keyPool: ['KeyG'], repsRequired: 10, label: 'Practice হসন্ত (্) alone' },
        {
          practiceMode: 'words',
          words: [CLUSTER_KKA, CLUSTER_STA, CLUSTER_NDA],
          label: 'Practice হসন্ত-joined clusters'
        },
        {
          practiceMode: 'words',
          words: [CLUSTER_KRA, CLUSTER_BYA],
          label: 'Practice রেফ-ফলা and য-ফলা shortcuts'
        },
        {
          practiceMode: 'words',
          words: [CLUSTER_KSHA],
          label: 'Practice a three-key cluster'
        }
      ],
      passThreshold: { accuracy: 70 }
    },
    {
      id: 'm3-l2',
      title: 'Lesson 2: Juktakkhor words',
      type: 'practice',
      baseXp: 26,
      handFocus: 'both',
      steps: [
        {
          kind: 'explain',
          heading: 'From cluster to whole word',
          body: 'Same joins as last lesson, now inside real words — স্কুল, জন্ম, সত্য. The cluster is only ever part of the word, so keep typing straight through it instead of pausing before or after.'
        }
      ],
      drills: [
        {
          practiceMode: 'words',
          words: [WORD_SKUL, WORD_JONMO, WORD_PODDO],
          label: 'Practice juktakkhor words, part 1'
        },
        {
          practiceMode: 'words',
          words: [WORD_SHOTTO, WORD_BISSHO, WORD_SHOPNO],
          label: 'Practice juktakkhor words, part 2'
        }
      ],
      passThreshold: { accuracy: 70 }
    },
    {
      id: 'm3-l3',
      title: 'Lesson 3: Full sentences',
      type: 'practice',
      baseXp: 30,
      handFocus: 'both',
      steps: [
        {
          kind: 'explain',
          heading: 'Juktakkhor at sentence speed',
          body: 'The real test isn\u2019t typing স্কুল on its own \u2014 it\u2019s not slowing down for it in the middle of a sentence. Same words as last lesson, now strung together.'
        }
      ],
      drills: [
        {
          practiceMode: 'sentences',
          sentences: [
            withSpaces(WORD_SKUL, WORD_JONMO, WORD_SHOTTO),
            withSpaces(WORD_PODDO, WORD_BISSHO, WORD_SHOPNO)
          ],
          label: 'Practice full sentences'
        }
      ],
      passThreshold: { accuracy: 70 }
    },
    {
      id: 'm3-l4',
      title: 'Lesson 4: Harder sentences',
      type: 'practice',
      baseXp: 36,
      handFocus: 'both',
      steps: [
        {
          kind: 'explain',
          heading: 'Denser clusters, longer lines',
          body: 'These words stack more than one join in a row \u2014 রাষ্ট্র has three consonants fused together, স্বাস্থ্য has two separate joins back to back. Longer sentences too, so there\u2019s more distance to keep your rhythm over.'
        }
      ],
      drills: [
        {
          practiceMode: 'sentences',
          sentences: [
            withSpaces(WORD_RASHTRO, WORD_SHASTHO),
            withSpaces(WORD_BIDDA, WORD_SONGEET, WORD_RASHTRO)
          ],
          label: 'Practice harder sentences'
        }
      ],
      passThreshold: { accuracy: 65 }
    }
  ]
};
