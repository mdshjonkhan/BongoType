/**
 * BongoType — Module 2: Beyond the Home Row
 * --------------------------------------------------------------------------
 * Continues the curriculum's step pattern exactly:
 *   1. Introduce new keys      -> 'explain' steps
 *   2. Show correct finger     -> handFocus + the existing hand viz
 *   3. Practice single/new keys -> practiceMode 'keys'
 *   4. Practice combinations   -> practiceMode 'keys' with a larger pool
 *   5. Practice words          -> practiceMode 'words'
 *   6. Practice sentences      -> practiceMode 'sentences'
 *
 * Curriculum order for this module is: top row -> bottom row -> shifted
 * values. Home row (2 keys, then the full row) is already covered by
 * Module 1, so this module builds outward from it one row at a time,
 * finishing with the Shift layer once every physical key position has
 * been taught.
 *
 * CRITICAL DESIGN POINT: words/sentences are defined as ARRAYS OF PHYSICAL
 * KEY CODES, not literal Bengali text. This is what makes lesson content
 * layout-agnostic — the lesson engine resolves each code through whichever
 * layout is currently active (bijoy.js / probhat.js / jatiya.js) to get the
 * actual character to display and check against. If lessons stored literal
 * Bengali characters instead, switching layout would silently break every
 * word/sentence lesson, since the SAME PHYSICAL KEYS produce DIFFERENT
 * characters in Bijoy vs Probhat.
 *
 * Words/sentences at each stage use ONLY keys taught so far (home row +
 * whatever row that lesson just introduced) so they are reachable with the
 * limited key set a learner has actually been taught by this point —
 * introducing untaught keys in a "practice word" would defeat the whole
 * point of incremental teaching.
 */

// Helper: a "word" or "sentence" is an array of physical key codes.
// Word boundaries use 'Space' explicitly so multi-word sentences are just
// concatenated word arrays with 'Space' inserted between them.
function withSpaces(...wordArrays) {
  const result = [];
  wordArrays.forEach((word, i) => {
    if (i > 0) result.push('Space');
    result.push(...word);
  });
  return result;
}

const HOME_ROW = ['KeyA', 'KeyS', 'KeyD', 'KeyF', 'KeyJ', 'KeyK', 'KeyL', 'Semicolon'];
const TOP_ROW = ['KeyE', 'KeyR', 'KeyU', 'KeyI'];
const BOTTOM_ROW = ['KeyC', 'KeyV', 'KeyN', 'KeyM'];

export const module2 = {
  id: 'm2',
  title: 'Beyond the Home Row',
  description: 'Top row, bottom row, then shifted values',
  glyph: 'bolt',
  lessons: [
    {
      id: 'm2-l1',
      title: 'Lesson 1: Top row',
      type: 'practice',
      baseXp: 20,
      handFocus: 'both',
      steps: [
        {
          kind: 'explain',
          heading: 'Reaching up from home',
          body: 'Now your fingers will reach UP one row, then return home. R and U are reached by your index fingers; the others follow the same column as their home-row key.'
        }
      ],
      drills: [
        { practiceMode: 'keys', keyPool: TOP_ROW, repsRequired: 16, label: 'Practice top row keys' },
        { practiceMode: 'keys', keyPool: [...HOME_ROW, ...TOP_ROW], repsRequired: 24, label: 'Combine with home row' },
        {
          practiceMode: 'words',
          words: [['KeyR', 'KeyF'], ['KeyU', 'KeyJ'], ['KeyE', 'KeyD', 'KeyK']],
          label: 'Practice words with top row'
        },
        {
          practiceMode: 'sentences',
          sentences: [withSpaces(['KeyF', 'KeyR'], ['KeyJ', 'KeyU'], ['KeyD', 'KeyE', 'KeyK'])],
          label: 'Practice a full sentence'
        }
      ],
      passThreshold: { accuracy: 70 }
    },
    {
      id: 'm2-l2',
      title: 'Lesson 2: Bottom row',
      type: 'practice',
      baseXp: 20,
      handFocus: 'both',
      steps: [
        {
          kind: 'explain',
          heading: 'Reaching down from home',
          body: 'Last row, your fingers reach DOWN one row. C and N are reached by your index fingers; the rest follow their home-row finger\u2019s column.'
        }
      ],
      drills: [
        { practiceMode: 'keys', keyPool: BOTTOM_ROW, repsRequired: 16, label: 'Practice bottom row keys' },
        {
          practiceMode: 'keys',
          keyPool: [...HOME_ROW, ...TOP_ROW, ...BOTTOM_ROW],
          repsRequired: 28,
          label: 'Full combination practice'
        },
        {
          practiceMode: 'sentences',
          sentences: [
            withSpaces(['KeyF', 'KeyV'], ['KeyJ', 'KeyN'], ['KeyD', 'KeyC', 'KeyK']),
            withSpaces(['KeyR', 'KeyE'], ['KeyU', 'KeyI'], ['KeyM', 'KeyN'])
          ],
          label: 'Practice full sentences'
        }
      ],
      passThreshold: { accuracy: 70 }
    },
    {
      id: 'm2-l3',
      title: 'Lesson 3: Shifted values',
      type: 'practice',
      baseXp: 24,
      handFocus: 'both',
      steps: [
        {
          kind: 'explain',
          heading: 'A second character on every key',
          body: 'Every key you\u2019ve learned actually holds two characters. Hold Shift with either pinky, then tap the key, to type the one shown in the corner.'
        }
      ],
      drills: [
        { practiceMode: 'shifted', keyPool: ['KeyF', 'KeyJ'], repsRequired: 10, label: 'Shift + home anchor keys' },
        { practiceMode: 'shifted', keyPool: HOME_ROW, repsRequired: 16, label: 'Shift + home row' },
        { practiceMode: 'shifted', keyPool: [...TOP_ROW, ...BOTTOM_ROW], repsRequired: 16, label: 'Shift + top and bottom row' }
      ],
      passThreshold: { accuracy: 65 }
    }
  ]
};
