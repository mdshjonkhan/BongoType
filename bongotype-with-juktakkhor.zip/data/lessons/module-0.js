/**
 * BongoType — Module 0: Introduction
 * --------------------------------------------------------------------------
 * Condensed to a single concept lesson. Previously this module held two
 * separate no-typing lessons (what-is-touch-typing, finger-positioning
 * basics) — both pure reading with no hands-on component. Merged into one
 * short lesson so a learner reaches real typing practice by lesson 2
 * instead of lesson 5.
 */

export const module0 = {
  id: 'm0',
  title: 'Introduction',
  description: 'The basics, fast',
  glyph: 'sprout',
  lessons: [
    {
      id: 'm0-l1',
      title: 'Touch typing basics',
      type: 'concept',
      baseXp: 10,
      steps: [
        {
          kind: 'explain',
          heading: 'Typing without looking',
          body: 'Touch typing means typing without looking at the keyboard. Every glance down breaks your rhythm and slows you down \u2014 keeping your eyes on the screen is the real source of speed.'
        },
        {
          kind: 'explain',
          heading: 'The home row is your anchor',
          body: 'Your fingers rest on one row of keys \u2014 the home row \u2014 and return there after every reach. You\u2019ll start practicing on it in the very next lesson.'
        }
      ],
      comprehensionCheck: {
        question: 'Why does looking at the keyboard slow typing down?',
        options: [
          { text: 'It breaks your reading rhythm and you lose your place on screen', correct: true },
          { text: 'It makes the keyboard wear out faster', correct: false },
          { text: 'It has no effect on speed', correct: false }
        ]
      }
    }
  ]
};
