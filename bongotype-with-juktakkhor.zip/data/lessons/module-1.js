/**
 * BongoType — Module 1: Base Row
 * --------------------------------------------------------------------------
 * Progression inside this module is deliberately gradual:
 *   Lesson 1: the two home-position anchor keys only (F, J)
 *   Lesson 2: the rest of the home row, added around that anchor
 * Splitting these (rather than dropping all 8 home-row keys on a learner
 * at once) mirrors how the rest of the curriculum ramps up — small key
 * set first, proven, then widened — so Module 1 itself models the same
 * "2 keys -> full row" shape that Module 2 later repeats for the top and
 * bottom rows.
 */

export const module1 = {
  id: 'm1',
  title: 'Base Row',
  description: 'Home position, then straight to typing',
  glyph: 'compass',
  lessons: [
    {
      id: 'm1-l1',
      title: 'Lesson 1: Home anchor keys (F, J)',
      type: 'practice',
      baseXp: 12,
      handFocus: 'both',
      steps: [
        {
          kind: 'explain',
          heading: 'Find home position',
          body: 'Left index on F, right index on J \u2014 most keyboards have a raised bump on both so you can feel them without looking. These two keys are where your hands always return to.'
        }
      ],
      drills: [
        { practiceMode: 'keys', keyPool: ['KeyF'], repsRequired: 8, label: 'Practice F alone' },
        { practiceMode: 'keys', keyPool: ['KeyJ'], repsRequired: 8, label: 'Practice J alone' },
        { practiceMode: 'keys', keyPool: ['KeyF', 'KeyJ'], repsRequired: 16, label: 'Practice F and J together' }
      ],
      passThreshold: { accuracy: 75 }
    },
    {
      id: 'm1-l2',
      title: 'Lesson 2: Full home row',
      type: 'practice',
      baseXp: 18,
      handFocus: 'both',
      practiceMode: 'keys',
      steps: [
        {
          kind: 'explain',
          heading: 'The rest of home position',
          body: 'Your other six fingers fall naturally on A, S, D and K, L, ; \u2014 right next to F and J. Rest all eight fingers there and reach out from this row for every key.'
        }
      ],
      // Physical key codes only — the actual character shown comes from
      // whichever layout is active, exactly like Phase 2/3's free-practice
      // pool, but now scoped to a real lesson with a pass threshold.
      keyPool: ['KeyA', 'KeyS', 'KeyD', 'KeyF', 'KeyJ', 'KeyK', 'KeyL', 'Semicolon'],
      repsRequired: 20,
      passThreshold: { accuracy: 70 }
    }
  ]
};
