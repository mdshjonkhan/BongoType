/**
 * BongoType — Lesson Registry
 * --------------------------------------------------------------------------
 * Single place that knows the full module/lesson curriculum order. Mirrors
 * data/layouts/index.js's pattern deliberately — same "one registry, many
 * data files" shape, so the codebase has one consistent way of organizing
 * "a list of things plus lookup helpers," not a different pattern per
 * feature area.
 */

import { module0 } from './module-0.js';
import { module1 } from './module-1.js';
import { module2 } from './module-2.js';
import { module3 } from './module-3.js';

export const MODULES = [module0, module1, module2, module3];

/** Flat list of all lessons across all modules, in curriculum order. */
export function getAllLessons() {
  return MODULES.flatMap((mod) => mod.lessons.map((lesson) => ({ ...lesson, moduleId: mod.id })));
}

export function getModule(moduleId) {
  return MODULES.find((m) => m.id === moduleId) || null;
}

export function getLesson(lessonId) {
  for (const mod of MODULES) {
    const lesson = mod.lessons.find((l) => l.id === lessonId);
    if (lesson) return { ...lesson, moduleId: mod.id };
  }
  return null;
}

/**
 * Given a completed-lessons list, find the next lesson the learner should
 * take — first lesson, in curriculum order, not yet in completedLessons.
 * Returns null if everything is complete.
 */
export function getNextLesson(completedLessonIds) {
  const all = getAllLessons();
  return all.find((lesson) => !completedLessonIds.includes(lesson.id)) || null;
}

/**
 * Lock state for a given lesson: a lesson is unlocked if every lesson
 * before it (in curriculum order) is already completed. This is what
 * drives the home screen ledger's locked/current/done states.
 */
export function getLessonState(lessonId, completedLessonIds) {
  const all = getAllLessons();
  const index = all.findIndex((l) => l.id === lessonId);
  if (index === -1) return 'locked';
  if (completedLessonIds.includes(lessonId)) return 'done';
  const allPriorComplete = all.slice(0, index).every((l) => completedLessonIds.includes(l.id));
  return allPriorComplete ? 'current' : 'locked';
}
