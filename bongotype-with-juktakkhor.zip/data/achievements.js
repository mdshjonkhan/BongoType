/**
 * BongoType — Achievements
 * --------------------------------------------------------------------------
 * A badge is a name + icon + a pure `check(state, ctx)` predicate. Keeping
 * checks as data (not scattered `if` statements in lesson.js) means the
 * full badge list can be rendered on the Badges screen — locked ones show
 * their description as a hint of what to aim for — without a second,
 * hand-maintained list of "what badges exist" living somewhere else.
 *
 * `ctx` (built fresh in scripts/achievements.js on every check) carries the
 * things a raw state snapshot can't answer on its own: whether a specific
 * module is fully done, and the score record from the attempt that just
 * finished (so "3 stars" or "40+ combo" badges can react to the moment
 * they actually happened, not just persisted state).
 */

export const ACHIEVEMENTS = [
  {
    id: 'first_lesson',
    icon: 'sprout',
    title: 'First Steps',
    description: 'Complete your first lesson',
    check: (state) => state.completedLessons.length >= 1
  },
  {
    id: 'ten_lessons',
    icon: 'bookStack',
    title: 'Bookworm',
    description: 'Complete 10 lessons',
    check: (state) => state.completedLessons.length >= 10
  },
  {
    id: 'twenty_five_lessons',
    icon: 'folder',
    title: 'Curriculum Crusher',
    description: 'Complete 25 lessons',
    check: (state) => state.completedLessons.length >= 25
  },
  {
    id: 'module_0_done',
    icon: 'target',
    title: 'Grounded',
    description: 'Finish the Introduction module',
    check: (state, ctx) => ctx.moduleDone('m0')
  },
  {
    id: 'module_1_done',
    icon: 'handOpen',
    title: 'Home Row Hero',
    description: 'Finish the Base Row module',
    check: (state, ctx) => ctx.moduleDone('m1')
  },
  {
    id: 'module_2_done',
    icon: 'rocket',
    title: 'Momentum',
    description: 'Finish Module 3',
    check: (state, ctx) => ctx.moduleDone('m2')
  },
  {
    id: 'module_3_done',
    icon: 'mountain',
    title: 'Juktakkhor Master',
    description: 'Finish the Juktakkhor module',
    check: (state, ctx) => ctx.moduleDone('m3')
  },
  {
    id: 'all_modules_done',
    icon: 'crown',
    title: 'Bongo Champion',
    description: 'Complete every module in the curriculum',
    check: (state, ctx) => ctx.allModulesDone
  },
  {
    id: 'perfect_lesson',
    icon: 'percentBadge',
    title: 'Flawless',
    description: 'Finish a lesson with 100% accuracy',
    check: (state, ctx) => !!ctx.lastResult && ctx.lastResult.accuracy === 100
  },
  {
    id: 'three_star_lesson',
    icon: 'star',
    title: 'Triple Star',
    description: 'Earn all 3 stars on a lesson',
    check: (state, ctx) => !!ctx.lastResult && ctx.lastResult.stars === 3
  },
  {
    id: 'combo_15',
    icon: 'bolt',
    title: 'On a Roll',
    description: 'Hit a 15-keystroke streak without a mistake',
    check: (state, ctx) => !!ctx.lastResult && ctx.lastResult.maxCombo >= 15
  },
  {
    id: 'combo_40',
    icon: 'flame',
    title: 'Combo Master',
    description: 'Hit a 40-keystroke streak without a mistake',
    check: (state, ctx) => !!ctx.lastResult && ctx.lastResult.maxCombo >= 40
  },
  {
    id: 'speed_20',
    icon: 'wind',
    title: 'Picking Up Speed',
    description: 'Reach 20 WPM in a lesson',
    check: (state, ctx) => !!ctx.lastResult && ctx.lastResult.wpm >= 20
  },
  {
    id: 'speed_40',
    icon: 'meteor',
    title: 'Speedster',
    description: 'Reach 40 WPM in a lesson',
    check: (state, ctx) => !!ctx.lastResult && ctx.lastResult.wpm >= 40
  },
  {
    id: 'streak_3',
    icon: 'flame',
    title: 'Warming Up',
    description: 'Practice 3 days in a row',
    check: (state) => state.streakCount >= 3
  },
  {
    id: 'streak_7',
    icon: 'flame',
    title: 'Week One',
    description: 'Practice 7 days in a row',
    check: (state) => state.streakCount >= 7
  },
  {
    id: 'streak_30',
    icon: 'mountain',
    title: 'Unstoppable',
    description: 'Practice 30 days in a row',
    check: (state) => state.streakCount >= 30
  },
  {
    id: 'level_10',
    icon: 'compass',
    title: 'Keyboard Explorer',
    description: 'Reach level 10',
    check: (state, ctx) => ctx.level.number >= 10
  },
  {
    id: 'level_25',
    icon: 'medal',
    title: 'Fast Typist',
    description: 'Reach level 25',
    check: (state, ctx) => ctx.level.number >= 25
  },
  {
    id: 'level_50',
    icon: 'crown',
    title: 'BongoType Master',
    description: 'Reach level 50, the max level',
    check: (state, ctx) => ctx.level.number >= 50
  }
];
