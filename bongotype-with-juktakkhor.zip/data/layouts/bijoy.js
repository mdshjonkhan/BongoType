/**
 * BongoType — Bijoy Layout
 * --------------------------------------------------------------------------
 * Source of truth note: this mapping was transcribed from a published
 * Bijoy key-mapping table (Unshifted + Shifted layers) and cross-checked
 * against the structural facts confirmed by multiple independent sources:
 * consonants on lowercase/unshifted keys, vowel signs (kars) and vowels on
 * shifted/uppercase keys, 'g' -> দাড়ি (Bengali full stop), v/w/x family for
 * common kars. Alt-Right layer (rare conjuncts like ঈ, ঊ, ঐ) is NOT included
 * in Phase 2 — those are out of scope until a later "rare characters" module,
 * since teaching them in lesson 1 would contradict the product's own
 * "don't overload a beginner" principle.
 *
 * Shape: each entry is keyed by the PHYSICAL key (the actual e.key value a
 * browser reports for a US QWERTY key, ignoring what it currently types).
 * unshifted = character typed with no modifier.
 * shifted   = character typed while holding Shift.
 * finger    = which finger is responsible for this physical key position
 *             (independent of which layout is active — finger assignment
 *             follows physical key position, not the Bengali character).
 *
 * row/col are physical keyboard geometry, used by the virtual keyboard
 * renderer (Phase 2) to lay keys out correctly without guessing positions.
 */

export const bijoyLayout = {
  id: 'bijoy',
  name: 'Bijoy',

  // Finger responsibility is a property of PHYSICAL key position, shared by
  // every layout. Defined once here and reused — see finger-map.js.
  keys: {
    // ---- Number row ----
    'Digit1': { unshifted: '১', shifted: '!', row: 0, col: 1 },
    'Digit2': { unshifted: '২', shifted: '@', row: 0, col: 2 },
    'Digit3': { unshifted: '৩', shifted: '#', row: 0, col: 3 },
    'Digit4': { unshifted: '৪', shifted: '৳', row: 0, col: 4 },
    'Digit5': { unshifted: '৫', shifted: '%', row: 0, col: 5 },
    'Digit6': { unshifted: '৬', shifted: '÷', row: 0, col: 6 },
    'Digit7': { unshifted: '৭', shifted: 'ঁ', row: 0, col: 7 },
    'Digit8': { unshifted: '৮', shifted: '×', row: 0, col: 8 },
    'Digit9': { unshifted: '৯', shifted: '(', row: 0, col: 9 },
    'Digit0': { unshifted: '০', shifted: ')', row: 0, col: 10 },
    'Minus':  { unshifted: '-', shifted: '_', row: 0, col: 11 },
    'Equal':  { unshifted: '=', shifted: '+', row: 0, col: 12 },

    // ---- Top row (QWERTY) ----
    'KeyQ': { unshifted: 'ঙ', shifted: 'ং', row: 1, col: 1 },
    'KeyW': { unshifted: 'য', shifted: 'য়', row: 1, col: 2 },
    'KeyE': { unshifted: 'ড', shifted: 'ঢ', row: 1, col: 3 },
    'KeyR': { unshifted: 'প', shifted: 'ফ', row: 1, col: 4 },
    'KeyT': { unshifted: 'ট', shifted: 'ঠ', row: 1, col: 5 },
    'KeyY': { unshifted: 'চ', shifted: 'ছ', row: 1, col: 6 },
    'KeyU': { unshifted: 'জ', shifted: 'ঝ', row: 1, col: 7 },
    'KeyI': { unshifted: 'হ', shifted: 'ঞ', row: 1, col: 8 },
    'KeyO': { unshifted: 'গ', shifted: 'ঘ', row: 1, col: 9 },
    'KeyP': { unshifted: 'ড়', shifted: 'ঢ়', row: 1, col: 10 },
    'BracketLeft':  { unshifted: '[', shifted: '{', row: 1, col: 11 },
    'BracketRight': { unshifted: ']', shifted: '}', row: 1, col: 12 },
    'Backslash':    { unshifted: 'ঃ', shifted: 'ৎ', row: 1, col: 13 },

    // ---- Home row (ASDF) ----
    'KeyA': { unshifted: 'ৃ', shifted: 'র্', row: 2, col: 1 },
    'KeyS': { unshifted: 'ু', shifted: 'ূ', row: 2, col: 2 },
    'KeyD': { unshifted: 'ি', shifted: 'ী', row: 2, col: 3 },
    'KeyF': { unshifted: 'া', shifted: 'অ', row: 2, col: 4 },
    'KeyG': { unshifted: '্', shifted: '।', row: 2, col: 5 },
    'KeyH': { unshifted: 'ব', shifted: 'ভ', row: 2, col: 6 },
    'KeyJ': { unshifted: 'ক', shifted: 'খ', row: 2, col: 7 },
    'KeyK': { unshifted: 'ত', shifted: 'থ', row: 2, col: 8 },
    'KeyL': { unshifted: 'দ', shifted: 'ধ', row: 2, col: 9 },
    'Semicolon':  { unshifted: ';', shifted: ':', row: 2, col: 10 },
    'Quote':      { unshifted: "'", shifted: '"', row: 2, col: 11 },

    // ---- Bottom row (ZXCV) ----
    'KeyZ': { unshifted: '্র', shifted: '্য', row: 3, col: 1 },
    'KeyX': { unshifted: 'ো', shifted: 'ৌ', row: 3, col: 2 },
    'KeyC': { unshifted: 'ে', shifted: 'ৈ', row: 3, col: 3 },
    'KeyV': { unshifted: 'র', shifted: 'ল', row: 3, col: 4 },
    'KeyB': { unshifted: 'ন', shifted: 'ণ', row: 3, col: 5 },
    'KeyN': { unshifted: 'স', shifted: 'ষ', row: 3, col: 6 },
    'KeyM': { unshifted: 'ম', shifted: 'শ', row: 3, col: 7 },
    'Comma':  { unshifted: ',', shifted: '<', row: 3, col: 8 },
    'Period': { unshifted: '.', shifted: '>', row: 3, col: 9 },
    'Slash':  { unshifted: '/', shifted: '?', row: 3, col: 10 },

    'Space': { unshifted: ' ', shifted: ' ', row: 4, col: 1 },

    // ---- Special / modifier keys ----
    // These don't type a Bengali character, so they use a distinct shape
    // (special: true + an English label) instead of unshifted/shifted —
    // forcing a fake glyph into those fields would be wrong, and the
    // lesson/practice engines already treat `.unshifted` as "the character
    // to type," so keeping these visually and structurally separate avoids
    // accidentally teaching that Enter "produces a character."
    'Tab':        { special: true, label: 'Tab', row: 1, col: 0 },
    'CapsLock':   { special: true, label: 'Caps Lock', row: 2, col: 0 },
    'ShiftLeft':  { special: true, label: 'Shift', row: 3, col: 0 },
    'ShiftRight': { special: true, label: 'Shift', row: 3, col: 11 },
    'Enter':      { special: true, label: 'Enter', row: 2, col: 12 },
    'Backspace':  { special: true, label: 'Backspace', row: 0, col: 13 }
  }
};
