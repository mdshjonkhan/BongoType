/**
 * BongoType — National (Jatiya) Layout
 * --------------------------------------------------------------------------
 * IMPORTANT ACCURACY NOTE, read before changing this file:
 *
 * The original 2004 national standard (BDS 1738:2004) had its own distinct
 * key mapping. However, in 2017 the Bangladesh Computer Council revised the
 * national standard (now BDS 1738:2018), and that revision adopted the
 * Bijoy key layout itself as the official national standard. As of this
 * writing, "National/Jatiya" and "Bijoy" use the SAME physical key
 * positions for the SAME Bengali characters.
 *
 * Rather than fabricate a fictional distinct mapping (which would actively
 * teach incorrect muscle memory in a touch-typing trainer), this file
 * re-exports the Bijoy key map under the National identity, with its own
 * id/name for the UI. If a verified copy of the historical 2004-only
 * mapping is needed later (e.g. for a "legacy layouts" section), it should
 * be added as a clearly separate, explicitly-labeled file — not merged in
 * here under the current "National" label.
 */

import { bijoyLayout } from './bijoy.js';

export const jatiyaLayout = {
  id: 'jatiya',
  name: 'National (Jatiya)',
  keys: bijoyLayout.keys
};
