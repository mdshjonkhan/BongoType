/**
 * BongoType — Probhat Layout
 * --------------------------------------------------------------------------
 * Transcribed from a published Probhat key-mapping table (Unshifted +
 * Shifted layers only — Alt-Right rare conjuncts out of scope for Phase 2,
 * same reasoning as bijoy.js). Probhat uses a phonetic-ish arrangement but
 * is a fully fixed layout (no transliteration) — consistent with the
 * product's "no phonetic systems" rule.
 */

export const probhatLayout = {
  id: 'probhat',
  name: 'Probhat',

  keys: {
    // ---- Number row ----
    'Digit1': { unshifted: '১', shifted: '!', row: 0, col: 1 },
    'Digit2': { unshifted: '২', shifted: '@', row: 0, col: 2 },
    'Digit3': { unshifted: '৩', shifted: '#', row: 0, col: 3 },
    'Digit4': { unshifted: '৪', shifted: '৳', row: 0, col: 4 },
    'Digit5': { unshifted: '৫', shifted: '%', row: 0, col: 5 },
    'Digit6': { unshifted: '৬', shifted: '^', row: 0, col: 6 },
    'Digit7': { unshifted: '৭', shifted: 'ঞ', row: 0, col: 7 },
    'Digit8': { unshifted: '৮', shifted: 'ৎ', row: 0, col: 8 },
    'Digit9': { unshifted: '৯', shifted: '(', row: 0, col: 9 },
    'Digit0': { unshifted: '০', shifted: ')', row: 0, col: 10 },
    'Minus':  { unshifted: '-', shifted: '_', row: 0, col: 11 },
    'Equal':  { unshifted: '=', shifted: '+', row: 0, col: 12 },

    // ---- Top row (QWERTY) ----
    'KeyQ': { unshifted: 'দ', shifted: 'ধ', row: 1, col: 1 },
    'KeyW': { unshifted: 'ূ', shifted: 'ঊ', row: 1, col: 2 },
    'KeyE': { unshifted: 'ী', shifted: 'ঈ', row: 1, col: 3 },
    'KeyR': { unshifted: 'র', shifted: 'ড়', row: 1, col: 4 },
    'KeyT': { unshifted: 'ট', shifted: 'ঠ', row: 1, col: 5 },
    'KeyY': { unshifted: 'এ', shifted: 'ঐ', row: 1, col: 6 },
    'KeyU': { unshifted: 'ু', shifted: 'উ', row: 1, col: 7 },
    'KeyI': { unshifted: 'ি', shifted: 'ই', row: 1, col: 8 },
    'KeyO': { unshifted: 'ও', shifted: 'ঔ', row: 1, col: 9 },
    'KeyP': { unshifted: 'প', shifted: 'ফ', row: 1, col: 10 },
    'BracketLeft':  { unshifted: 'ে', shifted: 'ৈ', row: 1, col: 11 },
    'BracketRight': { unshifted: 'ো', shifted: 'ৌ', row: 1, col: 12 },
    'Backslash':    { unshifted: '\u200C', shifted: '॥', row: 1, col: 13 }, // ZWNJ unshifted

    // ---- Home row (ASDF) ----
    'KeyA': { unshifted: 'া', shifted: 'অ', row: 2, col: 1 },
    'KeyS': { unshifted: 'স', shifted: 'ষ', row: 2, col: 2 },
    'KeyD': { unshifted: 'ড', shifted: 'ঢ', row: 2, col: 3 },
    'KeyF': { unshifted: 'ত', shifted: 'থ', row: 2, col: 4 },
    'KeyG': { unshifted: 'গ', shifted: 'ঘ', row: 2, col: 5 },
    'KeyH': { unshifted: 'হ', shifted: 'ঃ', row: 2, col: 6 },
    'KeyJ': { unshifted: 'জ', shifted: 'ঝ', row: 2, col: 7 },
    'KeyK': { unshifted: 'ক', shifted: 'খ', row: 2, col: 8 },
    'KeyL': { unshifted: 'ল', shifted: 'ং', row: 2, col: 9 },
    'Semicolon':  { unshifted: ';', shifted: ':', row: 2, col: 10 },
    'Quote':      { unshifted: "'", shifted: '"', row: 2, col: 11 },

    // ---- Bottom row (ZXCV) ----
    'KeyZ': { unshifted: 'য়', shifted: 'য', row: 3, col: 1 },
    'KeyX': { unshifted: 'শ', shifted: 'ঢ়', row: 3, col: 2 },
    'KeyC': { unshifted: 'চ', shifted: 'ছ', row: 3, col: 3 },
    'KeyV': { unshifted: 'আ', shifted: 'ঋ', row: 3, col: 4 },
    'KeyB': { unshifted: 'ব', shifted: 'ভ', row: 3, col: 5 },
    'KeyN': { unshifted: 'ন', shifted: 'ণ', row: 3, col: 6 },
    'KeyM': { unshifted: 'ম', shifted: 'ঙ', row: 3, col: 7 },
    'Comma':  { unshifted: ',', shifted: 'ৃ', row: 3, col: 8 },
    'Period': { unshifted: '।', shifted: 'ঁ', row: 3, col: 9 },
    'Slash':  { unshifted: '্', shifted: '?', row: 3, col: 10 },

    'Space': { unshifted: ' ', shifted: ' ', row: 4, col: 1 },

    // ---- Special / modifier keys (same convention as bijoy.js) ----
    'Tab':        { special: true, label: 'Tab', row: 1, col: 0 },
    'CapsLock':   { special: true, label: 'Caps Lock', row: 2, col: 0 },
    'ShiftLeft':  { special: true, label: 'Shift', row: 3, col: 0 },
    'ShiftRight': { special: true, label: 'Shift', row: 3, col: 11 },
    'Enter':      { special: true, label: 'Enter', row: 2, col: 12 },
    'Backspace':  { special: true, label: 'Backspace', row: 0, col: 13 }
  }
};
