/**
 * BongoType — Layout Registry
 * --------------------------------------------------------------------------
 * Single place that knows "which layouts exist." Adding a 4th layout later
 * means: create its data file, add one line here. Nothing else in the app
 * (keyboard engine, lesson engine, layout picker) needs to change.
 */

import { bijoyLayout } from './bijoy.js';
import { jatiyaLayout } from './jatiya.js';
import { probhatLayout } from './probhat.js';

const REGISTRY = {
  bijoy: bijoyLayout,
  jatiya: jatiyaLayout,
  probhat: probhatLayout
};

export function getLayout(id) {
  const layout = REGISTRY[id];
  if (!layout) {
    console.error(`BongoType: unknown layout id "${id}", falling back to bijoy.`);
    return REGISTRY.bijoy;
  }
  return layout;
}

export function listLayouts() {
  return Object.values(REGISTRY).map((l) => ({ id: l.id, name: l.name }));
}
