/**
 * BongoType — Finger Map
 * --------------------------------------------------------------------------
 * Standard touch-typing finger responsibility by physical key position.
 * This is layout-agnostic: whichever Bengali character lives on KeyF,
 * the LEFT INDEX finger is responsible for it, in every layout. This is
 * what makes "switch layout, finger guidance still correct" work — finger
 * assignment is a property of physical key geometry, not of the active
 * layout's character set.
 *
 * hand: 'L' | 'R'
 * finger: 'pinky' | 'ring' | 'middle' | 'index' | 'thumb'
 * homeKey: true if this is the resting/home position for that finger
 *          (used to draw the "return to home row" guidance)
 */

export const fingerMap = {
  // ---- Number row ----
  'Digit1': { hand: 'L', finger: 'pinky' },
  'Digit2': { hand: 'L', finger: 'ring' },
  'Digit3': { hand: 'L', finger: 'middle' },
  'Digit4': { hand: 'L', finger: 'index' },
  'Digit5': { hand: 'L', finger: 'index' },
  'Digit6': { hand: 'R', finger: 'index' },
  'Digit7': { hand: 'R', finger: 'index' },
  'Digit8': { hand: 'R', finger: 'middle' },
  'Digit9': { hand: 'R', finger: 'ring' },
  'Digit0': { hand: 'R', finger: 'pinky' },
  'Minus':  { hand: 'R', finger: 'pinky' },
  'Equal':  { hand: 'R', finger: 'pinky' },

  // ---- Top row ----
  'KeyQ': { hand: 'L', finger: 'pinky' },
  'KeyW': { hand: 'L', finger: 'ring' },
  'KeyE': { hand: 'L', finger: 'middle' },
  'KeyR': { hand: 'L', finger: 'index' },
  'KeyT': { hand: 'L', finger: 'index' },
  'KeyY': { hand: 'R', finger: 'index' },
  'KeyU': { hand: 'R', finger: 'index' },
  'KeyI': { hand: 'R', finger: 'middle' },
  'KeyO': { hand: 'R', finger: 'ring' },
  'KeyP': { hand: 'R', finger: 'pinky' },
  'BracketLeft':  { hand: 'R', finger: 'pinky' },
  'BracketRight': { hand: 'R', finger: 'pinky' },
  'Backslash':    { hand: 'R', finger: 'pinky' },

  // ---- Home row — these are the resting positions ----
  'KeyA': { hand: 'L', finger: 'pinky', homeKey: true },
  'KeyS': { hand: 'L', finger: 'ring', homeKey: true },
  'KeyD': { hand: 'L', finger: 'middle', homeKey: true },
  'KeyF': { hand: 'L', finger: 'index', homeKey: true },
  'KeyG': { hand: 'L', finger: 'index' },
  'KeyH': { hand: 'R', finger: 'index' },
  'KeyJ': { hand: 'R', finger: 'index', homeKey: true },
  'KeyK': { hand: 'R', finger: 'middle', homeKey: true },
  'KeyL': { hand: 'R', finger: 'ring', homeKey: true },
  'Semicolon': { hand: 'R', finger: 'pinky', homeKey: true },
  'Quote':     { hand: 'R', finger: 'pinky' },

  // ---- Bottom row ----
  'KeyZ': { hand: 'L', finger: 'pinky' },
  'KeyX': { hand: 'L', finger: 'ring' },
  'KeyC': { hand: 'L', finger: 'middle' },
  'KeyV': { hand: 'L', finger: 'index' },
  'KeyB': { hand: 'L', finger: 'index' },
  'KeyN': { hand: 'R', finger: 'index' },
  'KeyM': { hand: 'R', finger: 'index' },
  'Comma':  { hand: 'R', finger: 'middle' },
  'Period': { hand: 'R', finger: 'ring' },
  'Slash':  { hand: 'R', finger: 'pinky' },

  'Space': { hand: 'L', finger: 'thumb' }, // either thumb in practice; default L for guidance

  // ---- Modifier / special keys ----
  // Standard touch-typing convention, not specific to Bengali layouts:
  'Tab':        { hand: 'L', finger: 'pinky' },
  'CapsLock':   { hand: 'L', finger: 'pinky' },
  'ShiftLeft':  { hand: 'L', finger: 'pinky' },
  'ShiftRight': { hand: 'R', finger: 'pinky' },
  'Enter':      { hand: 'R', finger: 'pinky' },
  'Backspace':  { hand: 'R', finger: 'pinky' }
};

/** Convenience: look up finger info for a physical key code. */
export function fingerForKey(keyCode) {
  return fingerMap[keyCode] || null;
}
