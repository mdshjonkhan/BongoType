/**
 * BongoType — Practice Screen
 * Free practice loop — adapts to physical (landscape) or virtual tap (portrait) mode.
 */

import { store } from '../scripts/store.js';
import { getLayout } from '../data/layouts/index.js';
import { KeyboardEngine } from '../scripts/keyboard-engine.js';
import { sound } from '../scripts/sound.js';
import { HandVisualization } from '../scripts/hand-visualization.js';

const PRACTICE_POOL = ['KeyF','KeyJ','KeyD','KeyK','KeyS','KeyL','KeyA','Semicolon','KeyH','KeyG'];
const STREAK_GOAL = 10; // dots shown in virtual mode

export const practiceScreen = {
  render(container) {
    const state = store.get();
    const isVirtual = state.inputMode === 'virtual';

    if (!state.selectedLayout) {
      container.innerHTML = `
        <div class="empty-state">
          <h2 style="margin-bottom:var(--space-3);">Choose a layout first</h2>
          <p>Pick a keyboard layout before practicing.</p>
          <button class="btn btn--primary" id="goto-layout" style="margin-top:var(--space-4);">Choose layout</button>
        </div>`;
      container.querySelector('#goto-layout').addEventListener('click', () => { window.location.hash = '/layout-select'; });
      container.querySelector('#goto-layout').focus();
      return;
    }

    const layout = getLayout(state.selectedLayout);
    const wrapper = document.createElement('div');
    wrapper.className = 'practice-screen';

    if (isVirtual) {
      // ── Portrait / virtual-tap layout ────────────────────────────────
      wrapper.innerHTML = `
        <div class="virtual-content-area">
          <div class="virtual-target-display">
            <p class="virtual-target-display__label">Tap this key</p>
            <div class="virtual-target-display__char" id="target-char">·</div>
          </div>
          <div id="hands-mount"></div>
          <div class="virtual-streak-bar" id="streak-dots">
            ${Array.from({length: STREAK_GOAL}, () => `<div class="virtual-streak-dot"></div>`).join('')}
          </div>
          <p class="text-muted" style="font-size:var(--text-sm);text-align:center;" id="feedback-line"></p>
        </div>
        <div class="keyboard-stage">
          <div class="practice-readout">
            <span style="font-size:var(--text-xs);color:var(--muted-clay);">Tap keyboard below</span>
            ${sound.muteButtonHtml({ size: 18 })}
          </div>
          <div id="vkeyboard-mount"></div>
        </div>`;
    } else {
      // ── Landscape / physical layout ───────────────────────────────────
      wrapper.innerHTML = `
        <div class="keyboard-stage">
          <div class="practice-readout">
            <p class="text-muted">Press this key</p>
            <div class="practice-readout__char" id="target-char">·</div>
            ${sound.muteButtonHtml({ size: 16 })}

          </div>
          <div id="hands-mount"></div>
          <div id="vkeyboard-mount"></div>
          <p class="text-muted" style="text-align:center;font-size:var(--text-xs);" id="feedback-line">
            Type the highlighted key on your physical keyboard.
          </p>
        </div>`;
    }

    container.appendChild(wrapper);

    const engine = new KeyboardEngine(layout, wrapper.querySelector('#vkeyboard-mount'), { tapEnabled: isVirtual });
    engine.render();
    engine.start();

    const hands = new HandVisualization(wrapper.querySelector('#hands-mount'));
    hands.render();

    const targetCharEl  = wrapper.querySelector('#target-char');
    const feedbackEl    = wrapper.querySelector('#feedback-line');
    const muteBtn       = wrapper.querySelector('#mute-btn');
    const dots          = wrapper.querySelectorAll('.virtual-streak-dot');
    let correctStreak   = 0;

    function updateDots() {
      dots.forEach((d, i) => d.classList.toggle('is-hit', i < correctStreak));
    }

    function pickNextTarget() {
      const code = PRACTICE_POOL[Math.floor(Math.random() * PRACTICE_POOL.length)];
      engine.setExpectedKey(code);
      const char = layout.keys[code]?.unshifted ?? '?';
      if (targetCharEl) {
        targetCharEl.textContent = char;
        // Re-trigger animation
        targetCharEl.style.animation = 'none';
        void targetCharEl.offsetWidth;
        targetCharEl.style.animation = '';
      }
      hands.setActiveFinger(engine.getExpectedFinger());
    }

    engine.onResult = (isCorrect) => {
      if (isCorrect) {
        correctStreak = Math.min(correctStreak + 1, STREAK_GOAL);
        if (feedbackEl) feedbackEl.textContent = correctStreak === STREAK_GOAL ? 'Perfect streak!' : `${correctStreak} in a row!`;
        updateDots();
        hands.pulseActiveFinger();
        if (correctStreak === STREAK_GOAL) { sound.streak(); correctStreak = 0; setTimeout(updateDots, 600); }
        setTimeout(pickNextTarget, 220);
      } else {
        if (correctStreak > 0) { correctStreak = 0; updateDots(); }
        if (feedbackEl) feedbackEl.textContent = 'Not quite — try again.';
      }
    };

    sound.wireMuteButton(muteBtn, { size: isVirtual ? 18 : 16 });

    pickNextTarget();

    const cleanup = () => engine.stop();
    window.addEventListener('hashchange', cleanup, { once: true });
  }
};
