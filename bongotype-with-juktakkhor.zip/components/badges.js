/**
 * BongoType — Badges Screen
 * --------------------------------------------------------------------------
 * Full collection view of every achievement in data/achievements.js.
 * Locked badges still show their title + description as a goal to chase
 * (TypingLand-style "150 badges to collect" framing) — only their icon is
 * withheld, replaced with a lock, so nothing here is a total mystery.
 */

import { store } from '../scripts/store.js';
import { ACHIEVEMENTS } from '../data/achievements.js';
import { medallion, alponaDivider } from '../scripts/icons.js';

export const badgesScreen = {
  render(container) {
    const state = store.get();
    const unlockedCount = state.unlockedBadges.length;

    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
      <h1 style="margin-bottom: var(--space-2); margin-top: var(--space-4);">Badges</h1>
      <p class="text-muted" style="margin-bottom: var(--space-3);">
        ${unlockedCount} of ${ACHIEVEMENTS.length} earned
      </p>
      ${alponaDivider(320)}
      <div class="badges-grid" id="badges-grid"></div>
    `;
    container.appendChild(wrapper);

    const grid = wrapper.querySelector('#badges-grid');
    grid.innerHTML = ACHIEVEMENTS.map((badge) => {
      const isUnlocked = state.unlockedBadges.includes(badge.id);
      return `
        <div class="badge-tile ${isUnlocked ? 'is-unlocked' : 'is-locked'}">
          <div class="badge-tile__icon">${medallion(badge.icon, { state: isUnlocked ? 'done' : 'locked', size: 48 })}</div>
          <div class="badge-tile__title">${badge.title}</div>
          <div class="badge-tile__desc">${badge.description}</div>
        </div>`;
    }).join('');
  }
};
