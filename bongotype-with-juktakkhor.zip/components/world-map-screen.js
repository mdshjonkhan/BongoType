/**
 * BongoType — World Map Screen
 * --------------------------------------------------------------------------
 * The world map's own full-screen page rather than a widget squeezed into
 * the home screen's fixed-height layout. Giving it the whole screen means
 * it can breathe — bigger scenery, room to scroll, and a stop-by-stop
 * entrance animation (see world-map.js's `animateIn` option) each time the
 * learner opens it, rather than a static grid that just appears.
 */

import { store } from '../scripts/store.js';
import { MODULES, getLessonState } from '../data/lessons/index.js';
import { alponaDivider } from '../scripts/icons.js';
import { renderWorldMap } from '../scripts/world-map.js';
import { sound } from '../scripts/sound.js';
import { haptics } from '../scripts/haptics.js';

function computeModuleOutline(completedLessons) {
  let priorModulesDone = true;
  return MODULES.map((mod) => {
    const lessonStates = mod.lessons.map((l) => getLessonState(l.id, completedLessons));
    const allDone = lessonStates.every((s) => s === 'done');
    const doneCount = lessonStates.filter((s) => s === 'done').length;
    let state;
    if (allDone) {
      state = 'done';
    } else if (priorModulesDone) {
      state = 'current';
    } else {
      state = 'locked';
    }
    if (!allDone) priorModulesDone = false;
    return {
      id: mod.id,
      title: mod.title,
      sub: `${doneCount}/${mod.lessons.length} levels`,
      state,
      glyph: mod.glyph || 'sprout'
    };
  });
}

export const worldMapScreen = {
  render(container) {
    const state = store.get();

    const wrapper = document.createElement('div');
    wrapper.className = 'map-page';
    wrapper.innerHTML = `
      <div class="section-heading map-page__heading">
        <h1>Your world map</h1>
        ${alponaDivider(320)}
      </div>
      <div id="world-map" class="map-page__map"></div>
    `;
    container.appendChild(wrapper);

    const moduleOutline = computeModuleOutline(state.completedLessons);
    const cleanupMap = renderWorldMap(wrapper.querySelector('#world-map'), moduleOutline, {
      animateIn: true,
      onSelect: (node) => {
        sound.tap();
        haptics.tap();
        window.location.hash = `/module?id=${node.id}`;
      }
    });
    window.addEventListener('hashchange', cleanupMap, { once: true });
  }
};
