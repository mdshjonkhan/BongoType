/**
 * BongoType — Type Flappy Bird Screen
 * --------------------------------------------------------------------------
 * Wraps scripts/type-flappy.js (pure simulation) with a canvas render loop,
 * physical-keyboard input wiring, a pre-game countdown, and a post-game
 * summary that awards XP through the same store the lesson screen uses —
 * so a good round of flappy contributes to the same level/streak progress
 * as lessons, rather than being a disconnected side activity.
 *
 * Unlock gate: requires at least GAMES_UNLOCK_LESSON_COUNT completed
 * lessons, mirroring the threshold for the app's very first badge — the
 * idea being "you've learned enough keys to make this fun, not frustrating"
 * rather than an arbitrary paywall-style lock.
 *
 * Canvas, not DOM elements-per-pipe: at 300px/s pipe speed and up to
 * several pipes on screen at once, animating that many elements via CSS
 * transforms/DOM writes every frame is exactly the kind of workload canvas
 * exists for — one drawImage-equivalent pass, not N style recalcs.
 */

import { store } from '../scripts/store.js';
import { getLayout } from '../data/layouts/index.js';
import { TypeFlappyGame } from '../scripts/type-flappy.js';
import { sound } from '../scripts/sound.js';
import { haptics } from '../scripts/haptics.js';
import { icon, alponaDivider } from '../scripts/icons.js';
import { levelForXp } from '../scripts/levels.js';

export const GAMES_UNLOCK_LESSON_COUNT = 3;

// XP conversion: modest relative to a full lesson (15-30 XP per scoring.js)
// so games feel like a fun bonus loop, not a faster grind than actually
// learning — 2 XP per pipe cleared, +1 per 5 best-combo, capped sanely by
// run length naturally (no explicit cap needed; a run ends on collision).
function xpForRun(state_) {
  return state_.score * 2 + Math.floor(state_.bestCombo / 5);
}

function paperColor(varName) {
  return getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
}

export const gameFlappyScreen = {
  render(container) {
    const state = store.get();

    // ── Unlock gate ──────────────────────────────────────────────────
    if (state.completedLessons.length < GAMES_UNLOCK_LESSON_COUNT) {
      const remaining = GAMES_UNLOCK_LESSON_COUNT - state.completedLessons.length;
      container.innerHTML = `
        <div class="empty-state">
          ${icon('lock', { size: 34 })}
          <h2 style="margin-top:var(--space-3);margin-bottom:var(--space-2);">Locked for now</h2>
          <p class="text-muted">
            Finish ${remaining} more lesson${remaining === 1 ? '' : 's'} to unlock Type Flappy —
            it needs a few keys under your fingers first.
          </p>
          <button class="btn btn--primary" id="goto-map" style="margin-top:var(--space-4);">Continue lessons</button>
        </div>`;
      const btn = container.querySelector('#goto-map');
      btn.addEventListener('click', () => { window.location.hash = '/map'; });
      btn.focus();
      return;
    }

    if (!state.selectedLayout) {
      container.innerHTML = `
        <div class="empty-state">
          <h2 style="margin-bottom:var(--space-3);">Choose a layout first</h2>
          <p>Pick a keyboard layout before playing.</p>
          <button class="btn btn--primary" id="goto-layout" style="margin-top:var(--space-4);">Choose layout</button>
        </div>`;
      const btn = container.querySelector('#goto-layout');
      btn.addEventListener('click', () => { window.location.hash = '/layout-select'; });
      btn.focus();
      return;
    }

    const layout = getLayout(state.selectedLayout);

    const wrapper = document.createElement('div');
    wrapper.className = 'flappy-screen';
    wrapper.innerHTML = `
      <div class="flappy-hud">
        <div class="flappy-hud__stat">
          <span class="flappy-hud__label">Score</span>
          <span class="flappy-hud__value text-mono" id="flappy-score">0</span>
        </div>
        <div class="flappy-hud__stat">
          <span class="flappy-hud__label">Combo</span>
          <span class="flappy-hud__value text-mono" id="flappy-combo">0</span>
        </div>
        <div class="flappy-hud__target" id="flappy-target-wrap">
          <span class="flappy-hud__target-label">Type</span>
          <span class="flappy-hud__target-char text-bengali" id="flappy-target-char">—</span>
        </div>
        ${sound.muteButtonHtml({ size: 15 })}
      </div>
      <div class="flappy-canvas-wrap">
        <canvas id="flappy-canvas"></canvas>
        <div class="flappy-overlay" id="flappy-overlay"></div>
      </div>
    `;
    container.appendChild(wrapper);

    sound.wireMuteButton(wrapper.querySelector('#mute-btn'), { size: 15 });

    const canvas = wrapper.querySelector('#flappy-canvas');
    const ctx2d = canvas.getContext('2d');
    const overlay = wrapper.querySelector('#flappy-overlay');
    const scoreEl = wrapper.querySelector('#flappy-score');
    const comboEl = wrapper.querySelector('#flappy-combo');
    const targetCharEl = wrapper.querySelector('#flappy-target-char');

    let game = null;
    let rafId = null;
    let lastFrameT = null;
    let keyHandler = null;
    let flashUntil = 0;
    let flashCorrect = true;

    // ── Sizing: canvas backing store matches CSS box * devicePixelRatio,
    // so pipes/bird render crisp rather than blurry-upscaled on high-DPI
    // Android panels — same reasoning as any canvas game on mobile.
    function sizeCanvas() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
      canvas.style.width = rect.width + 'px';
      canvas.style.height = rect.height + 'px';
      ctx2d.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (game) {
        game.width = rect.width;
        game.height = rect.height;
      }
      return { width: rect.width, height: rect.height };
    }

    function draw() {
      const s = game.getState();
      const ink = paperColor('--ink');
      const green = paperColor('--deep-green');
      const gold = paperColor('--gold');
      const red = paperColor('--signal-red');
      const paperRaised = paperColor('--paper-raised');
      const line = paperColor('--line');

      ctx2d.clearRect(0, 0, s.width, s.height);

      // Sky-ish backdrop wash, subtle — matches paper tone rather than a
      // blue "sky" that would clash with the app's terracotta palette.
      ctx2d.fillStyle = paperColor('--paper');
      ctx2d.fillRect(0, 0, s.width, s.height);

      // Pipes
      s.pipes.forEach((pipe) => {
        ctx2d.fillStyle = pipe === s.activeTarget ? green : line;
        // top pipe
        ctx2d.fillRect(pipe.x, 0, s.pipeWidth, pipe.gapY);
        // bottom pipe
        ctx2d.fillRect(pipe.x, pipe.gapY + pipe.gapHeight, s.pipeWidth, s.height - (pipe.gapY + pipe.gapHeight));

        // Character label on the gap's leading edge, big and legible —
        // this IS the instruction, not decoration.
        ctx2d.save();
        ctx2d.fillStyle = pipe === s.activeTarget ? gold : ink;
        ctx2d.font = `600 30px "Noto Sans Bengali", sans-serif`;
        ctx2d.textAlign = 'center';
        ctx2d.textBaseline = 'middle';
        ctx2d.fillText(pipe.char, pipe.x + s.pipeWidth / 2, pipe.gapY + pipe.gapHeight / 2);
        ctx2d.restore();
      });

      // Bird
      ctx2d.save();
      ctx2d.translate(s.birdX, s.birdY);
      ctx2d.rotate(s.birdRotation);
      ctx2d.fillStyle = red;
      ctx2d.beginPath();
      ctx2d.arc(0, 0, 16, 0, Math.PI * 2);
      ctx2d.fill();
      // simple beak
      ctx2d.fillStyle = gold;
      ctx2d.beginPath();
      ctx2d.moveTo(14, -3);
      ctx2d.lineTo(24, 0);
      ctx2d.lineTo(14, 5);
      ctx2d.closePath();
      ctx2d.fill();
      ctx2d.restore();

      // Flash ring around bird on last keystroke result
      if (performance.now() < flashUntil) {
        ctx2d.save();
        ctx2d.strokeStyle = flashCorrect ? green : red;
        ctx2d.lineWidth = 3;
        ctx2d.beginPath();
        ctx2d.arc(s.birdX, s.birdY, 24, 0, Math.PI * 2);
        ctx2d.stroke();
        ctx2d.restore();
      }

      // HUD text sync
      scoreEl.textContent = s.score;
      comboEl.textContent = s.combo;
      if (s.activeTarget) {
        targetCharEl.textContent = s.activeTarget.char;
      }
    }

    function loop(t) {
      if (lastFrameT === null) lastFrameT = t;
      const dt = Math.min(48, t - lastFrameT); // clamp so a tab-switch stall doesn't cause a physics jump
      lastFrameT = t;
      game.step(dt);
      draw();
      if (game.getState().gameOver) {
        endRun();
        return;
      }
      rafId = requestAnimationFrame(loop);
    }

    function onKeyDown(e) {
      if (e.repeat) return;
      const before = game.getState().lastResult;
      game.handleKey(e.code);
      const after = game.getState().lastResult;
      if (after && after !== before) {
        flashUntil = performance.now() + 140;
        flashCorrect = after.correct;
        if (after.correct) { sound.correct(); haptics.correct(); }
        else { sound.wrong(); haptics.wrong(); }
      }
    }

    function startCountdown() {
      overlay.innerHTML = `<div class="flappy-countdown" id="flappy-countdown">3</div>`;
      overlay.classList.add('is-visible');
      const countdownEl = overlay.querySelector('#flappy-countdown');
      let n = 3;
      const tick = () => {
        n -= 1;
        if (n > 0) {
          countdownEl.textContent = n;
          sound.tap();
          setTimeout(tick, 700);
        } else {
          countdownEl.textContent = 'Go!';
          sound.correct();
          setTimeout(() => {
            overlay.classList.remove('is-visible');
            overlay.innerHTML = '';
            beginRun();
          }, 450);
        }
      };
      setTimeout(tick, 700);
    }

    function beginRun() {
      const { width, height } = sizeCanvas();
      game = new TypeFlappyGame(layout, { width, height });
      game.start();
      keyHandler = onKeyDown;
      window.addEventListener('keydown', keyHandler);
      lastFrameT = null;
      rafId = requestAnimationFrame(loop);
    }

    function endRun() {
      if (keyHandler) { window.removeEventListener('keydown', keyHandler); keyHandler = null; }
      if (rafId) { cancelAnimationFrame(rafId); rafId = null; }

      const s = game.getState();
      const xpEarned = xpForRun(s);
      const freshState = store.get();
      const levelBefore = levelForXp(freshState.xp);
      const newXp = freshState.xp + xpEarned;
      const levelAfter = levelForXp(newXp);
      store.set({ xp: newXp });

      sound.wrong();
      haptics.wrong();
      if (levelAfter.number > levelBefore.number) {
        setTimeout(() => { sound.levelUp(); haptics.levelUp(); }, 350);
      }

      overlay.innerHTML = `
        <div class="flappy-gameover">
          <h2>Round over</h2>
          ${alponaDivider(200)}
          <div class="score-summary__grid" style="margin:var(--space-4) 0;">
            <div class="score-summary__stat">
              <div class="score-summary__stat-value">${s.score}</div>
              <div class="score-summary__stat-label">Gaps cleared</div>
            </div>
            <div class="score-summary__stat">
              <div class="score-summary__stat-value">${s.bestCombo}</div>
              <div class="score-summary__stat-label">Best combo</div>
            </div>
            <div class="score-summary__stat">
              <div class="score-summary__stat-value">${s.accuracy}%</div>
              <div class="score-summary__stat-label">Accuracy</div>
            </div>
          </div>
          <div class="score-summary__xp">+${xpEarned} XP</div>
          ${levelAfter.number > levelBefore.number ? `<p class="text-muted" style="margin-top:var(--space-2);">Level up! Now level ${levelAfter.number} · ${levelAfter.name}</p>` : ''}
          <div style="display:flex;gap:var(--space-3);margin-top:var(--space-5);justify-content:center;">
            <button class="btn btn--ghost" id="flappy-exit" type="button">Exit</button>
            <button class="btn btn--primary" id="flappy-retry" type="button">Play again</button>
          </div>
        </div>`;
      overlay.classList.add('is-visible');
      overlay.querySelector('#flappy-exit').addEventListener('click', () => { window.location.hash = '/'; });
      overlay.querySelector('#flappy-retry').addEventListener('click', () => {
        overlay.classList.remove('is-visible');
        overlay.innerHTML = '';
        startCountdown();
      });
    }

    // Resize handling: only matters while a run isn't actively deep in
    // flight in a way that would matter for a short arcade round, but
    // keep the canvas crisp if the layout reflows (e.g. orientation).
    const onResize = () => { if (!game || !game.running) sizeCanvas(); };
    window.addEventListener('resize', onResize);

    sizeCanvas();
    startCountdown();

    const cleanup = () => {
      if (keyHandler) window.removeEventListener('keydown', keyHandler);
      if (rafId) cancelAnimationFrame(rafId);
      window.removeEventListener('resize', onResize);
    };
    window.addEventListener('hashchange', cleanup, { once: true });
  }
};
