/**
 * BongoType — Lesson Screen
 * Wires LessonEngine to the DOM. Writes XP/progress back to the store on
 * completion. Calls sound.levelUp() and sound.streak() at the right moments.
 */

import { store } from '../scripts/store.js';
import { getLesson, getNextLesson } from '../data/lessons/index.js';
import { LessonEngine } from '../scripts/lesson-engine.js';
import { levelForXp } from '../scripts/levels.js';
import { sound } from '../scripts/sound.js';
import { haptics } from '../scripts/haptics.js';
import { checkNewlyUnlocked } from '../scripts/achievements.js';
import { spawnConfetti } from '../scripts/confetti.js';
import { icon, medallion, starGlyph, rickshawStrip } from '../scripts/icons.js';

function todayIso() { return new Date().toISOString().slice(0, 10); }

function updateStreak(state) {
  const today = todayIso();
  if (state.lastPracticeDate === today) return { patch: {}, status: 'same-day' };
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const cont = state.lastPracticeDate === yesterday;
  const wasReset = state.lastPracticeDate !== null && !cont;
  return {
    patch: { streakCount: cont ? state.streakCount + 1 : 1, lastPracticeDate: today },
    status: cont ? 'continued' : (wasReset ? 'reset' : 'first-ever')
  };
}

export const lessonScreen = {
  render(container, params) {
    const lesson = getLesson(params.id);
    const state = store.get();

    if (!lesson) {
      container.innerHTML = `<div class="empty-state"><h2>Lesson not found</h2>
        <button class="btn btn--primary" id="back-home" style="margin-top:var(--space-4);">Back home</button></div>`;
      container.querySelector('#back-home').addEventListener('click', () => { window.location.hash = '/'; });
      container.querySelector('#back-home').focus();
      return;
    }
    if (!state.selectedLayout) { window.location.hash = '/layout-select'; return; }

    const wrapper = document.createElement('div');
    wrapper.className = 'lesson-screen';
    wrapper.innerHTML = `<div id="lesson-body"></div>`;
    container.appendChild(wrapper);

    const body = wrapper.querySelector('#lesson-body');

    const engine = new LessonEngine(lesson, {
      layoutId: state.selectedLayout,
      handsMount: null,
      keyboardMount: null,
      onStepChange: (event) => this._renderPhase(body, event, engine, lesson),
      onCombo: (combo, isCorrect) => this._updateComboMeter(body, combo, isCorrect),
      onComplete: (result) => this._handleComplete(result, lesson, body)
    });

    const cleanup = () => engine.stop();
    window.addEventListener('hashchange', cleanup, { once: true });

    engine.start();
  },

  _renderPhase(body, event, engine, lesson) {
    if (event.phase === 'explain')         this._renderExplain(body, event, engine);
    else if (event.phase === 'comprehension') this._renderComprehension(body, event, engine);
    else if (event.phase === 'drill')      this._renderDrillShell(body, event, engine);
    else if (event.phase === 'drill-target') this._updateDrillTarget(body, event);
    // 'score' rendered by _handleComplete after store is updated
  },

  _renderExplain(body, event, engine) {
    const { step, stepIndex, totalSteps } = event;
    body.innerHTML = `
      <div class="explain-card">
        <div class="explain-card__heading">${step.heading}</div>
        <p class="explain-card__body">${step.body}</p>
      </div>
      <div class="lesson-progress-dots" style="justify-content:center;margin:var(--space-3) 0;">
        ${Array.from({length: totalSteps}, (_, i) =>
          `<div class="lesson-progress-dots__dot ${i <= stepIndex ? 'is-done' : ''}"></div>`).join('')}
      </div>
      <button class="btn btn--primary btn--block" id="next-btn">
        ${stepIndex + 1 >= totalSteps ? 'Continue →' : 'Next →'}
      </button>`;
    const advance = () => {
      sound.tap();
      haptics.tap();
      window.removeEventListener('keydown', onKey);
      engine.advanceExplain();
    };
    const onKey = (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); advance(); }
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('hashchange', () => window.removeEventListener('keydown', onKey), { once: true });
    body.querySelector('#next-btn').addEventListener('click', advance);
  },

  _renderComprehension(body, event, engine) {
    const { check } = event;
    body.innerHTML = `
      <div class="comprehension-card">
        <div class="comprehension-card__question">${check.question}</div>
        ${check.options.map((opt, i) =>
          `<button class="comprehension-option" data-correct="${opt.correct}" data-index="${i}">
            <span class="comprehension-option__key">${i + 1}</span>${opt.text}
          </button>`
        ).join('')}
      </div>`;
    let answered = false;
    const choose = (btn) => {
      if (answered) return;
      answered = true;
      window.removeEventListener('keydown', onKey);
      const isCorrect = btn.dataset.correct === 'true';
      body.querySelectorAll('.comprehension-option').forEach(b => { b.disabled = true; });
      btn.classList.add(isCorrect ? 'is-correct' : 'is-wrong');
      if (!isCorrect) {
        const correctBtn = Array.from(body.querySelectorAll('.comprehension-option')).find(b => b.dataset.correct === 'true');
        if (correctBtn) correctBtn.classList.add('is-correct');
      }
      isCorrect ? sound.correct() : sound.wrong();
      isCorrect ? haptics.correct() : haptics.wrong();
      setTimeout(() => engine.submitComprehensionAnswer(isCorrect), 700);
    };
    // Number keys (1-based) pick an option directly — no reaching for a mouse.
    const onKey = (e) => {
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= check.options.length) {
        e.preventDefault();
        choose(body.querySelector(`.comprehension-option[data-index="${n - 1}"]`));
      }
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('hashchange', () => window.removeEventListener('keydown', onKey), { once: true });
    body.querySelectorAll('.comprehension-option').forEach(btn => {
      btn.addEventListener('click', () => choose(btn));
    });
  },

  _renderDrillShell(body, event, engine) {
    const { drill, drillIndex, totalDrills } = event;
    if (!body.querySelector('#drill-shell')) {
      body.innerHTML = `
        <div id="drill-shell">
          <div class="drill-progress">
            <div class="drill-progress__label" id="drill-label"></div>
            <div class="combo-meter is-hidden" id="combo-meter">
              <span class="combo-meter__icon">${icon('flame', { size: 16 })}</span>
              <span class="combo-meter__count" id="combo-count">0</span>
            </div>
            <div class="drill-progress__bar">
              <div class="drill-progress__bar-fill" id="drill-bar-fill" style="width:0%"></div>
            </div>
          </div>
          <div class="practice-readout">
            <p class="text-muted">Type this</p>
            <div class="practice-readout__char" id="target-char">·</div>
            ${sound.muteButtonHtml({ size: 16 })}
          </div>
          <div id="hands-mount"></div>
          <div id="vkeyboard-mount"></div>
        </div>`;
      engine.opts.handsMount = body.querySelector('#hands-mount');
      engine.opts.keyboardMount = body.querySelector('#vkeyboard-mount');
      sound.wireMuteButton(body.querySelector('#mute-btn'), { size: 16 });
    }
    const labelEl = body.querySelector('#drill-label');
    if (labelEl) labelEl.textContent = `${drill.label || 'Practice'} (${drillIndex + 1}/${totalDrills})`;
    const fillEl = body.querySelector('#drill-bar-fill');
    if (fillEl) fillEl.style.width = '0%';
  },

  _updateDrillTarget(body, event) {
    const charEl = body.querySelector('#target-char');
    const fillEl = body.querySelector('#drill-bar-fill');
    if (charEl) {
      charEl.textContent = event.char;
      charEl.style.animation = 'none';
      void charEl.offsetWidth;
      charEl.style.animation = '';
    }
    if (fillEl && event.sequenceLength > 0) {
      fillEl.style.width = `${(event.sequencePos / event.sequenceLength) * 100}%`;
    }
  },

  _updateComboMeter(body, combo, isCorrect) {
    const meter = body.querySelector('#combo-meter');
    const countEl = body.querySelector('#combo-count');
    if (!meter || !countEl) return;
    const COMBO_SHOW_THRESHOLD = 3; // stay out of the way until it's actually a streak
    countEl.textContent = combo;
    meter.classList.toggle('is-hidden', combo < COMBO_SHOW_THRESHOLD);
    if (isCorrect && combo >= COMBO_SHOW_THRESHOLD) {
      meter.classList.remove('is-pulse');
      void meter.offsetWidth;
      meter.classList.add('is-pulse');
      if (combo % 5 === 0) { sound.combo(Math.floor(combo / 5)); haptics.combo(Math.floor(combo / 5)); }
    }
  },

  _handleComplete(result, lesson, body) {
    const state = store.get();
    const levelBefore = levelForXp(state.xp);
    const alreadyCompleted = state.completedLessons.includes(lesson.id);
    const priorBest = state.bestScores[lesson.id] || null;

    let streakStatus = 'same-day';
    let streakPatch = {};
    if (result.passed) {
      const sr = updateStreak(state);
      streakStatus = sr.status;
      streakPatch = sr.patch;
    }

    const patch = { ...streakPatch };
    if (result.passed) {
      patch.xp = state.xp + result.xp;
      if (!alreadyCompleted) patch.completedLessons = [...state.completedLessons, lesson.id];
      if (!priorBest || result.stars > priorBest.stars || (result.stars === priorBest.stars && result.accuracy > priorBest.accuracy)) {
        patch.bestScores = { ...state.bestScores, [lesson.id]: { stars: result.stars, accuracy: result.accuracy, wpm: result.wpm } };
      }
    }
    store.set(patch);
    store.setStats({
      totalCharsTyped: state.stats.totalCharsTyped + result.totalChars,
      totalCorrectChars: state.stats.totalCorrectChars + result.correctChars,
      mistakesByKey: this._mergeMistakes(state.stats.mistakesByKey, result.mistakesByChar),
      lessonHistory: [...state.stats.lessonHistory, { lessonId: lesson.id, wpm: result.wpm, accuracy: result.accuracy, date: todayIso() }]
    });

    let newState = store.get();
    const levelAfter = levelForXp(newState.xp);
    const leveledUp = result.passed && levelAfter.number > levelBefore.number;

    // Badges: check against the fully-updated state, using this attempt's
    // result as context for "in the moment" badges (perfect, stars, combo).
    let newBadges = [];
    if (result.passed) {
      // Only pass this attempt as "lastResult" context when it was a real
      // performance attempt — otherwise a comprehension-check click can
      // spuriously qualify for accuracy/star/speed badges it has nothing
      // to do with. Milestone badges (first lesson, module done, etc.)
      // don't depend on lastResult, so they're unaffected.
      newBadges = checkNewlyUnlocked(newState, result.isPerformance ? result : null);
      if (newBadges.length) {
        store.set({ unlockedBadges: [...newState.unlockedBadges, ...newBadges.map((b) => b.id)] });
        newState = store.get();
      }
    }

    // Play appropriate sounds — priority: level-up > badge > streak > correct
    if (leveledUp) {
      sound.levelUp();
      haptics.levelUp();
    } else if (newBadges.length) {
      sound.badge();
      haptics.badge();
    } else if (result.passed && ['first-ever', 'continued'].includes(streakStatus) && [3,7,14,30,50,100,200,365].includes(newState.streakCount)) {
      sound.streak();
      haptics.streak();
    } else if (result.passed) {
      sound.correct();
      haptics.correct();
    }

    this._renderScore(body, {
      score: { accuracy: result.accuracy, wpm: result.wpm },
      xp: result.xp, comboBonus: result.comboBonus, stars: result.stars,
      passed: result.passed, leveledUp, newLevel: levelAfter,
      streakStatus, streakCount: newState.streakCount, newBadges,
      nextLesson: result.passed ? getNextLesson(newState.completedLessons) : null,
      isPerformance: result.isPerformance
    }, lesson);
  },

  _renderScore(body, event, lesson) {
    const { score, xp, comboBonus, stars, passed, leveledUp, newLevel, streakStatus, streakCount, newBadges, nextLesson, isPerformance } = event;
    const streakLine = this._buildStreakLine(streakStatus, streakCount);
    const celebratory = passed && (leveledUp || stars === 3 || newBadges.length > 0);
    // Give a real celebration a moment to land before flowing onward;
    // a plain pass barely pauses — this is meant to feel continuous.
    const AUTO_ADVANCE_MS = celebratory ? 2200 : 900;

    const continueLabel = !passed ? 'Back to lessons' : nextLesson ? 'Next lesson' : 'See your badges';

    body.innerHTML = `
      <div class="score-summary-wrap" id="score-wrap">
        ${leveledUp ? this._buildLevelUpBanner(newLevel) : ''}
        ${newBadges.map((b) => this._buildBadgeBanner(b)).join('')}
        <div class="score-summary">
          <div class="score-summary__badge">${passed ? (leveledUp ? medallion('trophy', { state: 'done', size: 60, spin: true }) : medallion('star', { state: 'done', size: 60, spin: true })) : medallion('handOpen', { state: 'current', size: 60 })}</div>
          <h2>${passed ? 'Lesson complete!' : 'Good effort!'}</h2>
          ${passed && isPerformance ? `<div class="score-summary__stars">${this._buildStarsHtml(stars)}</div>` : ''}
          <div class="score-summary__xp">+${xp} XP${comboBonus ? ` <span class="score-summary__combo-bonus">(+${comboBonus} combo)</span>` : ''}</div>
          ${isPerformance ? `<div class="score-summary__grid">
            <div class="score-summary__stat">
              <div class="score-summary__stat-value">${score.accuracy}%</div>
              <div class="score-summary__stat-label">Accuracy</div>
            </div>
            <div class="score-summary__stat">
              <div class="score-summary__stat-value">${score.wpm}</div>
              <div class="score-summary__stat-label">WPM</div>
            </div>
          </div>` : ''}
          ${streakLine ? `<div class="score-summary__streak">${streakLine}</div>` : ''}
          ${passed && nextLesson ? `<div class="score-summary__auto-bar"><div class="score-summary__auto-bar-fill" id="auto-bar-fill"></div></div>` : ''}
          <button class="btn btn--primary btn--block" id="continue-btn">${continueLabel}</button>
          ${!passed ? `<button class="btn btn--ghost btn--block" id="retry-btn" style="margin-top:var(--space-2);">Try again</button>` : ''}
        </div>
      </div>`;

    if (celebratory) {
      spawnConfetti(body.querySelector('#score-wrap'));
    }

    let advanced = false;
    const goNext = () => {
      if (advanced) return;
      advanced = true;
      clearTimeout(timer);
      window.removeEventListener('keydown', onKey);
      sound.tap();
      haptics.tap();
      window.location.hash = nextLesson ? `/lesson?id=${nextLesson.id}` : '/badges';
    };

    // Keyboard-first control, in the spirit of a typing app: Enter/Space
    // continues immediately without needing to tap a button.
    const onKey = (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); goNext(); }
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('hashchange', () => window.removeEventListener('keydown', onKey), { once: true });

    let timer = null;
    if (passed && nextLesson) {
      const fillEl = body.querySelector('#auto-bar-fill');
      if (fillEl) {
        fillEl.style.transitionDuration = `${AUTO_ADVANCE_MS}ms`;
        requestAnimationFrame(() => { fillEl.style.width = '100%'; });
      }
      timer = setTimeout(goNext, AUTO_ADVANCE_MS);
      window.addEventListener('hashchange', () => clearTimeout(timer), { once: true });
    }

    body.querySelector('#continue-btn').addEventListener('click', goNext);
    const retryBtn = body.querySelector('#retry-btn');
    if (retryBtn) retryBtn.addEventListener('click', () => {
      clearTimeout(timer);
      window.removeEventListener('keydown', onKey);
      window.location.hash = `/lesson?id=${lesson.id}&r=${Date.now()}`;
    });
  },

  _buildStarsHtml(stars) {
    return Array.from({ length: 3 }, (_, i) =>
      `<span class="star ${i < stars ? 'is-filled' : ''}">${starGlyph(24)}</span>`
    ).join('');
  },

  _buildBadgeBanner(badge) {
    return `
      <div class="badge-unlock-banner">
        ${rickshawStrip('badge')}
        <span class="badge-unlock-banner__icon">${medallion(badge.icon, { state: 'done', size: 44, spin: true })}</span>
        <div class="badge-unlock-banner__label">Badge unlocked</div>
        <div class="badge-unlock-banner__title">${badge.title}</div>
      </div>`;
  },

  _buildStreakLine(status, count) {
    const MILESTONES = [3, 7, 14, 30, 50, 100, 200, 365];
    if (status === 'first-ever') return `${icon('flame', { size: 14 })} Day 1 — your streak starts today!`;
    if (status === 'reset') return 'Streak reset — starting fresh at day 1.';
    if (status === 'continued' && MILESTONES.includes(count)) return `${icon('flame', { size: 14 })} ${count}-day streak! Keep it going.`;
    return null;
  },

  _buildLevelUpBanner(level) {
    return `
      <div class="level-up-banner">
        ${rickshawStrip('levelup')}
        <span class="level-up-banner__icon">${medallion('crown', { state: 'current', size: 48, spin: true })}</span>
        <div class="level-up-banner__title">Level ${level.number}</div>
        <div class="level-up-banner__name">${level.name}</div>
      </div>`;
  },

  _mergeMistakes(existing, incoming) {
    const merged = { ...existing };
    Object.entries(incoming || {}).forEach(([char, count]) => { merged[char] = (merged[char] || 0) + count; });
    return merged;
  }
};
