/**
 * BongoType — Module Screen
 * --------------------------------------------------------------------------
 * Shows the lessons within one module as a world map (same visual language
 * as the home screen's world map, scoped down one level: a "world" full of
 * "levels" instead of a plain list) — with each lesson's lock/current/done
 * state computed from the store's completedLessons against curriculum order.
 */

import { store } from '../scripts/store.js';
import { getModule, getLessonState } from '../data/lessons/index.js';
import { renderWorldMap } from '../scripts/world-map.js';
import { sound } from '../scripts/sound.js';
import { haptics } from '../scripts/haptics.js';

// Cycles a set of themed glyphs across a world's levels so each stop looks
// distinct at a glance instead of every node reusing one icon — a small
// echo of TypingLand's per-level scenery without needing real artwork.
const LEVEL_GLYPHS_BY_TYPE = {
  concept: ['bookStack', 'compass', 'target'],
  practice: ['bolt', 'wind', 'meteor', 'rocket', 'sprout']
};
function glyphForLesson(lesson, i) {
  const pool = LEVEL_GLYPHS_BY_TYPE[lesson.type] || LEVEL_GLYPHS_BY_TYPE.practice;
  return pool[i % pool.length];
}

export const moduleScreen = {
  render(container, params) {
    const mod = getModule(params.id);
    const state = store.get();

    if (!mod) {
      container.innerHTML = `
        <div class="empty-state">
          <h2 style="margin-bottom: var(--space-3);">Module not found</h2>
          <button class="btn btn--primary" id="back-btn">Back home</button>
        </div>
      `;
      container.querySelector('#back-btn').addEventListener('click', () => {
        window.location.hash = '/';
      });
      container.querySelector('#back-btn').focus();
      return;
    }

    // A module's own map only ever shows that module's handful of lessons —
    // unlike the full curriculum map, it isn't meant to be a wide scrolling
    // path. Below a threshold, let the panel hug its content instead of
    // stretching full-bleed and leaving a slab of empty green behind a
    // single node (see module-0, which has just one lesson).
    const isCompact = mod.lessons.length <= 2;

    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
      <h1 style="margin-bottom: var(--space-2); margin-top: var(--space-4);">${mod.title}</h1>
      <p class="text-muted" style="margin-bottom: var(--space-5);">${mod.description}</p>
      <div id="world-map" class="${isCompact ? 'world-map--compact' : ''}"></div>
    `;
    container.appendChild(wrapper);

    const statesForLessons = mod.lessons.map((l) => getLessonState(l.id, state.completedLessons));
    const nodes = mod.lessons.map((lesson, i) => {
      const lessonState = statesForLessons[i];
      const best = state.bestScores[lesson.id];
      return {
        id: lesson.id,
        title: lesson.title.replace(/^Lesson \d+:\s*/i, ''),
        sub: lesson.type === 'concept' ? 'Read & learn' : 'Practice',
        state: lessonState,
        glyph: glyphForLesson(lesson, i),
        stars: lessonState === 'done' ? (best ? best.stars : 3) : null
      };
    });

    const cleanupMap = renderWorldMap(wrapper.querySelector('#world-map'), nodes, {
      onSelect: (node) => {
        sound.tap();
        haptics.tap();
        window.location.hash = `/lesson?id=${node.id}`;
      }
    });
    window.addEventListener('hashchange', cleanupMap, { once: true });
  }
};
