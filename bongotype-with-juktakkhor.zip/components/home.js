/**
 * BongoType — Home Screen
 * --------------------------------------------------------------------------
 * Home's job: tell the learner exactly where they are (level, XP, streak)
 * and give them one clear way into everything else. The world map now
 * lives on its own full-screen page (see world-map-screen.js) rather than
 * being squeezed into a fixed-height half of home — it's the product's
 * centerpiece and deserves the whole screen, with its own entrance
 * animation each time it's opened.
 *
 * Practice / World map / Badges / Profile no longer sit as inline cards —
 * they're collected into a single slide-out menu (a lightweight settings
 * sidebar), opened from a menu button, so home itself stays to the point:
 * greeting, progress, and a way in.
 */

import { store } from '../scripts/store.js';
import { LEVELS, levelForXp, xpProgressInLevel } from '../scripts/levels.js';
import { ACHIEVEMENTS } from '../data/achievements.js';
import { icon, alponaDivider, brandMedallion } from '../scripts/icons.js';
import { sound } from '../scripts/sound.js';
import { haptics } from '../scripts/haptics.js';
import { initArrowNav } from '../scripts/keynav.js';
import { GAMES_UNLOCK_LESSON_COUNT } from './game-flappy.js';

const MENU_ITEMS = [
  { id: 'map',      hash: '/map',         glyph: 'compass', label: 'World map',  desc: 'See your journey' },
  { id: 'practice', hash: '/practice',    glyph: 'keys',     label: 'Practice',   desc: 'Free typing drills' },
  { id: 'games',    hash: '/game/flappy', glyph: 'wind',     label: 'Games',      desc: 'Type Flappy Bird' },
  { id: 'badges',   hash: '/badges',      glyph: 'medal',    label: 'Badges',     desc: 'Your achievements' },
  { id: 'profile',  hash: '/profile',     glyph: 'person',   label: 'Profile',    desc: 'Stats & settings' }
];

export const homeScreen = {
  render(container) {
    const state = store.get();
    const level = levelForXp(state.xp);
    const progress = xpProgressInLevel(state.xp);

    const layoutLabel = state.selectedLayout
      ? state.selectedLayout.charAt(0).toUpperCase() + state.selectedLayout.slice(1)
      : 'Not selected';

    const wrapper = document.createElement('div');
    wrapper.className = 'home-simple';
    wrapper.innerHTML = `
      <section class="home-greeting">
        ${brandMedallion(52)}
        <div style="flex:1;">
          <h1>স্বাগতম</h1>
          <p class="text-muted">Welcome back. Let's build your Bengali typing muscle memory.</p>
        </div>
        <div class="home-hero-stats">
          <span class="streak">${icon('flame', { size: 15 })} ${state.streakCount}</span>
          <span>Lv ${level.number}</span>
        </div>
        <button class="menu-toggle" id="menu-toggle" type="button" aria-label="Open menu" tabindex="-1">
          <span class="menu-toggle__bar"></span>
          <span class="menu-toggle__bar"></span>
          <span class="menu-toggle__bar"></span>
        </button>
      </section>
      ${alponaDivider(320)}

      <section class="card card--ornamented home-progress-card">
        <div class="home-progress-card__head">
          <span class="home-progress-card__level">
            Level ${level.number} · ${level.name}
          </span>
          <span class="text-mono text-muted home-progress-card__xp">
            ${state.xp} XP
          </span>
        </div>
        <div class="xp-bar">
          <div class="xp-bar__fill" style="width: ${progress.percent}%;"></div>
        </div>
        <div class="home-progress-card__foot">
          <span class="text-muted">${progress.remaining} XP to ${level.nextName || 'max level'}</span>
          <button class="home-layout-chip" id="change-layout-btn" type="button" tabindex="-1">${icon('keys', { size: 12 })} ${layoutLabel}</button>
        </div>
      </section>

      <button class="home-map-cta" id="open-map-btn" type="button" tabindex="-1">
        <span class="home-map-cta__icon">${icon('compass', { size: 26 })}</span>
        <span class="home-map-cta__text">
          <span class="home-map-cta__title">Continue your journey</span>
          <span class="home-map-cta__sub">Open the world map</span>
        </span>
        <span class="home-map-cta__arrow">${icon('arrowRight', { size: 18 })}</span>
      </button>

      <div class="menu-overlay" id="menu-overlay"></div>
      <aside class="menu-sidebar" id="menu-sidebar" aria-hidden="true">
        <div class="menu-sidebar__head">
          <span class="menu-sidebar__title">Menu</span>
          <button class="menu-sidebar__close" id="menu-close" type="button" aria-label="Close menu" tabindex="-1">
            ${icon('close', { size: 18 })}
          </button>
        </div>
        <nav class="menu-sidebar__list">
          ${MENU_ITEMS.map((item, i) => `
            <button class="menu-sidebar__item" data-hash="${item.hash}" type="button" tabindex="-1">
              <span class="menu-sidebar__item-key">${i + 1}</span>
              <span class="menu-sidebar__item-icon">${icon(item.glyph, { size: 19 })}</span>
              <span class="menu-sidebar__item-text">
                <span class="menu-sidebar__item-label">${item.label}</span>
                <span class="menu-sidebar__item-desc">${item.desc}</span>
              </span>
              ${item.id === 'badges' ? `<span class="menu-sidebar__item-count text-mono">${state.unlockedBadges.length}/${ACHIEVEMENTS.length}</span>` : ''}
              ${item.id === 'games' && state.completedLessons.length < GAMES_UNLOCK_LESSON_COUNT ? `<span class="menu-sidebar__item-count is-lock">${icon('lock', { size: 14 })}</span>` : ''}
            </button>
          `).join('')}
        </nav>
      </aside>
    `;

    container.appendChild(wrapper);

    const sidebar = wrapper.querySelector('#menu-sidebar');
    const overlay = wrapper.querySelector('#menu-overlay');
    const menuToggleBtn = wrapper.querySelector('#menu-toggle');
    const layoutChipBtn = wrapper.querySelector('#change-layout-btn');
    const mapCtaBtn = wrapper.querySelector('#open-map-btn');
    const menuItemEls = Array.from(wrapper.querySelectorAll('.menu-sidebar__item'));

    // ── Keyboard navigation ────────────────────────────────────────────
    // Two independent arrow-nav scopes, only one active at a time: the
    // three top-level controls while the menu is closed, the sidebar's
    // items once it's open. Neither relies on native Tab order (every
    // button above is tabindex="-1") — arrow keys move a roving highlight,
    // Enter/Space activates, matching the rest of the app's keyboard-first
    // model instead of a generic webpage's Tab-through behavior.
    let mainNav = null;
    let menuNav = null;
    let escHandler = null;

    function destroyMainNav() { if (mainNav) { mainNav.destroy(); mainNav = null; } }
    function destroyMenuNav() { if (menuNav) { menuNav.destroy(); menuNav = null; } }

    function startMainNav() {
      destroyMenuNav();
      mainNav = initArrowNav(
        [
          { el: menuToggleBtn, x: 0, y: 0 },
          { el: layoutChipBtn, x: 0, y: 1 },
          { el: mapCtaBtn, x: 0, y: 2 }
        ],
        {
          axis: 'y',
          wrap: true,
          onActivate: (item) => item.el.click()
        }
      );
    }

    function startMenuNav() {
      destroyMainNav();
      menuNav = initArrowNav(
        menuItemEls.map((el, i) => ({ el, x: 0, y: i })),
        {
          axis: 'y',
          wrap: true,
          onActivate: (item) => item.el.click()
        }
      );
    }

    const openMenu = () => {
      sound.tap();
      haptics.tap();
      sidebar.classList.add('is-open');
      overlay.classList.add('is-open');
      sidebar.setAttribute('aria-hidden', 'false');
      startMenuNav();
      escHandler = (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); sound.tap(); haptics.tap(); closeMenu(); } };
      // Capture phase so this runs (and can stopPropagation) before the
      // global "Escape = go back" handler registered in app.js — on the
      // home screen that global handler is a no-op anyway (Escape only
      // backs out on non-home routes), but capturing keeps this correct
      // even if that changes later.
      window.addEventListener('keydown', escHandler, true);
    };
    const closeMenu = () => {
      sidebar.classList.remove('is-open');
      overlay.classList.remove('is-open');
      sidebar.setAttribute('aria-hidden', 'true');
      destroyMenuNav();
      if (escHandler) { window.removeEventListener('keydown', escHandler, true); escHandler = null; }
      startMainNav();
    };

    menuToggleBtn.addEventListener('click', openMenu);
    wrapper.querySelector('#menu-close').addEventListener('click', () => { sound.tap(); haptics.tap(); closeMenu(); });
    overlay.addEventListener('click', closeMenu);

    // Number keys jump straight to a sidebar item while the menu is open —
    // faster than arrowing over for a short list, same pattern as the
    // lesson screen's comprehension-check number shortcuts.
    const numberHandler = (e) => {
      if (!sidebar.classList.contains('is-open')) return;
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= menuItemEls.length) { e.preventDefault(); menuItemEls[n - 1].click(); }
    };
    window.addEventListener('keydown', numberHandler);

    menuItemEls.forEach((btn) => {
      btn.addEventListener('click', () => {
        sound.tap();
        haptics.tap();
        window.location.hash = btn.dataset.hash;
      });
    });

    layoutChipBtn.addEventListener('click', () => {
      window.location.hash = '/layout-select';
    });
    mapCtaBtn.addEventListener('click', () => {
      sound.tap();
      haptics.tap();
      window.location.hash = '/map';
    });

    startMainNav();

    const cleanup = () => {
      destroyMainNav();
      destroyMenuNav();
      window.removeEventListener('keydown', numberHandler);
      if (escHandler) window.removeEventListener('keydown', escHandler, true);
    };
    window.addEventListener('hashchange', cleanup, { once: true });
  }
};
