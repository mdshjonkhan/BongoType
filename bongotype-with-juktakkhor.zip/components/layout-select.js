/**
 * BongoType — Layout Select Screen
 * --------------------------------------------------------------------------
 * Phase 1 scope: just the picker UI and writing the choice to the store.
 * Phase 2 will load the actual key-mapping JSON for whichever layout is
 * selected here. Keeping this screen dumb on purpose — it has one job,
 * pick a layout id and save it.
 */

import { store } from '../scripts/store.js';
import { icon } from '../scripts/icons.js';
import { initArrowNav, bindNumberShortcuts } from '../scripts/keynav.js';

const LAYOUTS = [
  { id: 'bijoy', name: 'Bijoy', desc: 'The most widely used traditional layout in Bangladesh.' },
  { id: 'jatiya', name: 'National (Jatiya)', desc: 'The government-standardized national layout.' },
  { id: 'probhat', name: 'Probhat', desc: 'A layout designed for linguistic/ergonomic logic.' }
];

export const layoutSelectScreen = {
  render(container) {
    const state = store.get();

    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
      <h1 style="margin-bottom: var(--space-2);">Choose your keyboard</h1>
      <p class="text-muted" style="margin-bottom: var(--space-5);">
        All lessons and the virtual keyboard will match the layout you pick.
        You can change this later by tapping the layout chip on your home screen.
      </p>
      <div id="layout-list" style="display:flex; flex-direction:column; gap: var(--space-3);"></div>
    `;
    container.appendChild(wrapper);

    const list = wrapper.querySelector('#layout-list');
    const items = [];
    LAYOUTS.forEach((layout, i) => {
      const isSelected = state.selectedLayout === layout.id;
      const item = document.createElement('button');
      item.className = 'card';
      item.type = 'button';
      item.tabIndex = -1; // reachable via arrow-key roving focus + number shortcuts, not native Tab order
      item.style.cssText = `
        display:flex; justify-content:space-between; align-items:center;
        text-align:left; width:100%; border: 2px solid ${isSelected ? 'var(--deep-green)' : 'transparent'};
      `;
      item.innerHTML = `
        <div style="display:flex; align-items:center; gap: var(--space-3);">
          <span class="layout-select__key">${i + 1}</span>
          <div>
            <div style="font-family: var(--font-display); font-weight:600; font-size: var(--text-lg);">
              ${layout.name}
            </div>
            <div class="text-muted" style="font-size: var(--text-sm); margin-top: 2px;">
              ${layout.desc}
            </div>
          </div>
        </div>
        <span style="font-size: var(--text-xl); color: var(--deep-green);">
          ${isSelected ? icon('check', { size: 20 }) : ''}
        </span>
      `;
      const choose = () => {
        store.set({ selectedLayout: layout.id });
        window.location.hash = '/';
      };
      item.addEventListener('click', choose);
      list.appendChild(item);
      items.push({ el: item, x: 0, y: i, choose });
    });

    const nav = initArrowNav(
      items.map(({ el, x, y }) => ({ el, x, y })),
      {
        axis: 'y',
        wrap: true,
        initialIndex: Math.max(0, LAYOUTS.findIndex((l) => l.id === state.selectedLayout)),
        onActivate: (_item, i) => items[i].choose()
      }
    );
    const unbindNumbers = bindNumberShortcuts(
      items.map((it) => it.el),
      (_el, i) => items[i].choose()
    );

    const cleanup = () => { nav.destroy(); unbindNumbers(); };
    window.addEventListener('hashchange', cleanup, { once: true });
  }
};
